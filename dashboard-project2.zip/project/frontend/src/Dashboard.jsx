import { useState, useRef, useMemo, useEffect, useCallback } from "react";

/* ═══ API Layer ═══ */
const API = "/api";
async function req(path, opts = {}) {
  try {
    const r = await fetch(`${API}${path}`, { headers: { "Content-Type": "application/json" }, ...opts });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } catch (e) { console.warn("API error:", e.message); return null; }
}
const api = {
  getTasks:    () => req("/tasks"),
  createTask:  (t) => req("/tasks", { method: "POST", body: JSON.stringify(t) }),
  updateTask:  (id, t) => req(`/tasks/${id}`, { method: "PUT", body: JSON.stringify(t) }),
  moveTask:    (id, col) => req(`/tasks/${id}/column`, { method: "PATCH", body: JSON.stringify({ column: col }) }),
  deleteTask:  (id) => req(`/tasks/${id}`, { method: "DELETE" }),
  getOrgGoals:       () => req("/goals/org"),
  createOrgGoal:     (g) => req("/goals/org", { method: "POST", body: JSON.stringify(g) }),
  updateOrgGoal:     (id, g) => req(`/goals/org/${id}`, { method: "PUT", body: JSON.stringify(g) }),
  deleteOrgGoal:     (id) => req(`/goals/org/${id}`, { method: "DELETE" }),
  getPersonalGoals:  () => req("/goals/personal"),
  createPersonalGoal:(g) => req("/goals/personal", { method: "POST", body: JSON.stringify(g) }),
  updatePersonalGoal:(id, g) => req(`/goals/personal/${id}`, { method: "PUT", body: JSON.stringify(g) }),
  deletePersonalGoal:(id) => req(`/goals/personal/${id}`, { method: "DELETE" }),
};

/* ═══ JIRA palette ═══ */
const C = {
  bg: "#f4f5f7", surface: "#ffffff",
  sidebarBg: "#0c2340", sidebarHover: "#153052", sidebarActive: "#1d3f6e",
  sidebarText: "rgba(255,255,255,0.72)", sidebarTextActive: "#fff", sidebarAccent: "#579dff",
  colBg: "#f0f1f4", card: "#ffffff", cardHover: "#f8f9fb",
  border: "#dfe1e6", borderFocus: "#4c9aff",
  text: "#172b4d", textMid: "#44546f", textLight: "#626f86", textVLight: "#8993a4",
  accent: "#0052cc", accentLight: "#deebff",
  danger: "#de350b", dangerBg: "#ffebe6",
  success: "#00875a", successBg: "#e3fcef",
  warning: "#ff8b00", warningBg: "#fffae6",
  purple: "#6554c0", purpleBg: "#eae6ff",
  teal: "#00b8d9", tealBg: "#e6fcff",
};

const PRIORITY = {
  high:   { color: C.danger,  bg: C.dangerBg,  icon: "↑", label: "High" },
  medium: { color: C.warning, bg: C.warningBg, icon: "→", label: "Medium" },
  low:    { color: C.success, bg: C.successBg, icon: "↓", label: "Low" },
};

const MEMBERS = [
  { id: "m1", name: "Yuki T.",   initials: "YT", color: "#0052cc" },
  { id: "m2", name: "Kenji S.",  initials: "KS", color: "#ff8b00" },
  { id: "m3", name: "Sakura M.", initials: "SM", color: "#6554c0" },
  { id: "m4", name: "Taro H.",   initials: "TH", color: "#00875a" },
];

const COLUMNS = [
  { id: "backlog", title: "BACKLOG" }, { id: "todo", title: "TO DO" },
  { id: "inprogress", title: "IN PROGRESS" }, { id: "review", title: "IN REVIEW" },
  { id: "done", title: "DONE" },
];
const COL_COLORS = { backlog: "#8993a4", todo: "#0052cc", inprogress: "#ff8b00", review: "#6554c0", done: "#00875a" };

/* ═══ Fallback data (used when API is unavailable) ═══ */
const FALLBACK_TASKS = [
  { id: "DASH-1", column: "todo",       title: "UIデザインの作成",       desc: "ダッシュボードのワイヤーフレーム作成", priority: "high",   assignees: ["m1","m3"], tags: ["デザイン"],     created: "2026-05-10" },
  { id: "DASH-2", column: "inprogress", title: "APIエンドポイント設計",   desc: "RESTful API仕様書のドラフト",       priority: "medium", assignees: ["m2"],     tags: ["バックエンド"], created: "2026-05-09" },
  { id: "DASH-3", column: "review",     title: "認証フローの実装",       desc: "OAuth2.0ベースの認証機能",          priority: "high",   assignees: ["m4","m2"], tags: ["セキュリティ"], created: "2026-05-08" },
  { id: "DASH-4", column: "done",       title: "プロジェクト初期設定",    desc: "リポジトリとCI/CDの構築",           priority: "low",    assignees: ["m4"],     tags: ["インフラ"],     created: "2026-05-06" },
  { id: "DASH-5", column: "backlog",    title: "パフォーマンス最適化",    desc: "Lighthouseスコア90+を目標に",       priority: "medium", assignees: [],         tags: ["最適化"],       created: "2026-05-11" },
  { id: "DASH-6", column: "todo",       title: "通知システムの設計",      desc: "リアルタイム通知の仕組み検討",       priority: "low",    assignees: ["m1"],     tags: ["機能"],         created: "2026-05-11" },
  { id: "DASH-7", column: "inprogress", title: "データベーススキーマ設計", desc: "正規化とインデックス計画",           priority: "high",   assignees: ["m2","m4"], tags: ["バックエンド"], created: "2026-05-07" },
];
const FALLBACK_ORG_GOALS = [
  { id: "og1", level: "company",  title: "売上前年比120%達成", desc: "国内外の売上拡大と新規事業の立ち上げ", progress: 35 },
  { id: "og2", level: "company",  title: "顧客満足度NPS 50+", desc: "サポート体制強化とプロダクト品質向上", progress: 60 },
  { id: "og3", level: "division", title: "プロダクト開発スピード2倍", desc: "CI/CD導入とアジャイル推進", progress: 45 },
  { id: "og4", level: "division", title: "エンジニア採用30名", desc: "新卒・中途あわせた採用計画実行", progress: 20 },
  { id: "og5", level: "dept",     title: "フロントエンド刷新完了", desc: "React移行プロジェクトの完遂", progress: 70 },
  { id: "og6", level: "dept",     title: "テストカバレッジ80%", desc: "単体・結合テストの網羅率向上", progress: 55 },
  { id: "og7", level: "section",  title: "デザインシステムv2リリース", desc: "コンポーネントライブラリの整備", progress: 40 },
  { id: "og8", level: "group",    title: "Sprint velocity 20%改善", desc: "ボトルネック分析と改善施策の実行", progress: 30 },
];
const FALLBACK_PERSONAL_GOALS = [
  { id: "pg1", memberId: "m1", period: "annual", title: "リードデザイナーへの昇格", desc: "デザインチームのリードを担当", progress: 50, keyResults: ["デザインレビュー主導 月4回", "メンバー育成 2名"] },
  { id: "pg2", memberId: "m1", period: "q1", title: "デザインシステム基盤構築", desc: "Figmaトークン整備", progress: 80, keyResults: ["カラートークン定義完了", "タイポグラフィ定義完了"] },
  { id: "pg3", memberId: "m1", period: "q2", title: "コンポーネント50種作成", desc: "UIコンポーネントの量産", progress: 30, keyResults: ["基本コンポーネント30種", "複合コンポーネント20種"] },
  { id: "pg4", memberId: "m2", period: "annual", title: "バックエンドアーキテクト認定", desc: "システム設計力の向上", progress: 40, keyResults: ["AWS SAA取得", "設計レビュー 月2回主導"] },
  { id: "pg5", memberId: "m2", period: "q1", title: "API基盤のリファクタリング", desc: "レスポンスタイム30%改善", progress: 90, keyResults: ["N+1クエリ解消", "キャッシュ戦略導入"] },
  { id: "pg6", memberId: "m3", period: "annual", title: "プロジェクトマネジメント力強化", desc: "PMP取得とチーム運営", progress: 25, keyResults: ["PMP試験合格", "2プロジェクト同時PMを経験"] },
  { id: "pg7", memberId: "m4", period: "annual", title: "インフラ自動化率90%", desc: "IaCとCI/CDの全面展開", progress: 65, keyResults: ["Terraform化 全環境", "デプロイ自動化率90%"] },
  { id: "pg8", memberId: "m4", period: "q2", title: "Kubernetes移行完了", desc: "本番環境のK8s移行", progress: 15, keyResults: ["ステージング環境構築", "本番カナリアリリース"] },
];

const ORG_LEVELS = [
  { id: "company",  label: "会社方針",     icon: "🏢", color: "#0052cc", depth: 0 },
  { id: "division", label: "本部方針",     icon: "🏛️", color: "#6554c0", depth: 1 },
  { id: "dept",     label: "部方針",       icon: "🏗️", color: "#00b8d9", depth: 2 },
  { id: "section",  label: "室方針",       icon: "🏠", color: "#ff8b00", depth: 3 },
  { id: "group",    label: "グループ方針", icon: "👥", color: "#00875a", depth: 4 },
];
const PERIODS = [
  { id: "annual", label: "通年目標" },
  { id: "q1", label: "Q1 目標" }, { id: "q2", label: "Q2 目標" },
  { id: "q3", label: "Q3 目標" }, { id: "q4", label: "Q4 目標" },
];

let nextNum = 8;
let goalNextId = 100;

/* ── SVG Icons ── */
const I = {
  board:  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="5" height="14" rx="1"/><rect x="12" y="3" width="5" height="8" rx="1"/></svg>,
  book:   <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 3h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4a1 1 0 011-1z"/><path d="M7 3v14"/><path d="M10 7h4"/><path d="M10 10h4"/></svg>,
  target: <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="3.5"/><circle cx="10" cy="10" r="0.8" fill="currentColor"/></svg>,
  gear:   <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="10" r="2.2"/><path d="M10 3v1.5M10 15.5V17M17 10h-1.5M4.5 10H3M14.95 5.05l-1.06 1.06M6.11 13.89l-1.06 1.06M14.95 14.95l-1.06-1.06M6.11 6.11L5.05 5.05"/></svg>,
  chevL:  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 3L5 8l5 5"/></svg>,
  chevR:  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3l5 5-5 5"/></svg>,
  chevD:  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 4.5l3 3 3-3"/></svg>,
  plus:   <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M7 2v10M2 7h10"/></svg>,
  search: <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="5.8" cy="5.8" r="3.8"/><path d="M9 9l3 3"/></svg>,
  cal:    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="12" height="11" rx="1.5"/><path d="M2 6.5h12"/><path d="M5.5 1.5v3M10.5 1.5v3"/></svg>,
  kanban: <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="4" height="12" rx="1"/><rect x="10" y="2" width="4" height="7" rx="1"/></svg>,
};

const NAV_MAIN = [
  { id: "tasks", icon: I.board, label: "タスク管理" },
  { id: "goals", icon: I.target, label: "目標管理" },
  { id: "knowledge", icon: I.book, label: "ナレッジ", disabled: true },
];
const NAV_BOTTOM = [{ id: "settings", icon: I.gear, label: "設定", disabled: true }];

/* ═══ Shared ═══ */
function Avatar({ member, size = 24 }) {
  return <div title={member.name} style={{ width: size, height: size, borderRadius: "50%", background: member.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.38, fontWeight: 700, color: "#fff", flexShrink: 0 }}>{member.initials}</div>;
}
function AvatarStack({ ids, size = 22 }) {
  const m = ids.map(i => MEMBERS.find(x => x.id === i)).filter(Boolean);
  if (!m.length) return <span style={{ fontSize: 11, color: C.textVLight }}>未割当</span>;
  return <div style={{ display: "flex" }}>{m.map((x, i) => <div key={x.id} style={{ marginLeft: i ? -6 : 0, zIndex: m.length - i, border: "2px solid #fff", borderRadius: "50%" }}><Avatar member={x} size={size} /></div>)}</div>;
}
function Lbl({ children }) { return <div style={{ fontSize: 11, fontWeight: 600, color: C.textMid, marginBottom: 4, letterSpacing: 0.4 }}>{children}</div>; }
function ProgressBar({ value, color = C.accent, height = 6, width = "100%" }) {
  return <div style={{ width, height, background: C.border, borderRadius: height, overflow: "hidden" }}><div style={{ height: "100%", width: `${Math.min(100, Math.max(0, value))}%`, background: color, borderRadius: height, transition: "width .3s" }} /></div>;
}

const aBtn = { background: "none", border: "none", cursor: "pointer", fontSize: 12, padding: "1px 3px", borderRadius: 3, color: C.textLight };
const inpStyle = { width: "100%", padding: "8px 10px", borderRadius: 3, border: `2px solid ${C.border}`, background: C.surface, color: C.text, fontSize: 13, outline: "none", boxSizing: "border-box", transition: "border .15s" };
const onFocus = e => (e.target.style.borderColor = C.borderFocus);
const onBlur = e => (e.target.style.borderColor = C.border);

/* ═══ Task Card ═══ */
function TaskCard({ task, onEdit, onDelete, drag }) {
  const [hov, setHov] = useState(false);
  const p = PRIORITY[task.priority];
  return (
    <div draggable onDragStart={e => drag.start(e, task.id)} onDragEnd={drag.end}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ background: hov ? C.cardHover : C.card, borderRadius: 3, padding: "10px 12px", cursor: "grab", boxShadow: hov ? "0 1px 6px rgba(9,30,66,0.25)" : "0 1px 1px rgba(9,30,66,0.13)", border: hov ? `1px solid ${C.borderFocus}` : "1px solid transparent", transition: "box-shadow .15s, border .15s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <span style={{ fontSize: 11, color: C.accent, fontWeight: 600 }}>{task.id}</span>
        {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={() => onEdit(task)} style={aBtn}>✏️</button><button onClick={() => onDelete(task.id)} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
      </div>
      <div style={{ fontSize: 13, fontWeight: 500, color: C.text, marginBottom: 6, lineHeight: 1.45 }}>{task.title}</div>
      {task.tags.length > 0 && <div style={{ display: "flex", gap: 4, marginBottom: 8, flexWrap: "wrap" }}>{task.tags.map(t => <span key={t} style={{ fontSize: 10, padding: "1px 6px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600 }}>{t}</span>)}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span title={p.label} style={{ fontSize: 11, fontWeight: 800, color: p.color, width: 18, height: 18, display: "inline-flex", alignItems: "center", justifyContent: "center", background: p.bg, borderRadius: 3 }}>{p.icon}</span>
          <AvatarStack ids={task.assignees} />
        </div>
        <span style={{ fontSize: 10, color: C.textVLight }}>{task.created}</span>
      </div>
    </div>
  );
}

/* ═══ Board Column ═══ */
function BoardCol({ col, tasks, onAdd, onEdit, onDelete, drag, isOver }) {
  return (
    <div onDragOver={e => { e.preventDefault(); drag.over(col.id); }} onDragLeave={drag.leave} onDrop={e => drag.drop(e, col.id)}
      style={{ flex: "0 0 260px", minWidth: 240, background: isOver ? C.accentLight : C.colBg, borderRadius: 6, display: "flex", flexDirection: "column", transition: "background .15s", border: isOver ? `2px dashed ${C.borderFocus}` : "2px dashed transparent", maxHeight: "100%" }}>
      <div style={{ padding: "10px 12px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: col.id === "done" ? C.success : C.textLight }}>{col.title}</span>
          <span style={{ fontSize: 10, fontWeight: 700, color: C.textVLight, background: "#dfe1e6", borderRadius: 10, padding: "0 6px", lineHeight: "18px" }}>{tasks.length}</span>
        </div>
        <button onClick={() => onAdd(col.id)} style={{ background: "none", border: "none", cursor: "pointer", color: C.textLight, display: "flex", alignItems: "center", padding: 2 }}>{I.plus}</button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "4px 6px 8px", display: "flex", flexDirection: "column", gap: 6 }}>
        {tasks.map(t => <TaskCard key={t.id} task={t} onEdit={onEdit} onDelete={onDelete} drag={drag} />)}
      </div>
    </div>
  );
}

/* ═══ Calendar View ═══ */
const WEEKDAYS = ["月", "火", "水", "木", "金", "土", "日"];
function CalendarView({ tasks, onEdit, onDelete, onAddOnDate }) {
  const [viewDate, setViewDate] = useState(() => new Date(2026, 4, 1));
  const year = viewDate.getFullYear(), month = viewDate.getMonth();
  const calDays = useMemo(() => {
    let sd = new Date(year, month, 1).getDay(); sd = sd === 0 ? 6 : sd - 1;
    const dim = new Date(year, month + 1, 0).getDate(), pd = new Date(year, month, 0).getDate(), cells = [];
    for (let i = sd - 1; i >= 0; i--) cells.push({ day: pd - i, inMonth: false, date: null });
    for (let d = 1; d <= dim; d++) cells.push({ day: d, inMonth: true, date: `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
    const rem = 7 - (cells.length % 7); if (rem < 7) for (let i = 1; i <= rem; i++) cells.push({ day: i, inMonth: false, date: null });
    return cells;
  }, [year, month]);
  const tbd = useMemo(() => { const m = {}; tasks.forEach(t => { if (!m[t.created]) m[t.created] = []; m[t.created].push(t); }); return m; }, [tasks]);
  const todayStr = new Date().toISOString().slice(0, 10);
  const nb = { background: C.surface, border: `1px solid ${C.border}`, borderRadius: 3, cursor: "pointer", color: C.textLight, display: "flex", alignItems: "center", justifyContent: "center", width: 28, height: 28, padding: 0 };
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <div style={{ padding: "12px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", background: C.surface, borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => setViewDate(new Date(year, month - 1, 1))} style={nb}>{I.chevL}</button>
          <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: C.text, minWidth: 120, textAlign: "center" }}>{year}年{month + 1}月</h2>
          <button onClick={() => setViewDate(new Date(year, month + 1, 1))} style={nb}>{I.chevR}</button>
          <button onClick={() => setViewDate(new Date())} style={{ ...nb, fontSize: 11, fontWeight: 600, padding: "4px 10px", width: "auto" }}>今日</button>
        </div>
        <div style={{ display: "flex", gap: 10 }}>{COLUMNS.map(c => <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textLight }}><div style={{ width: 8, height: 8, borderRadius: 2, background: COL_COLORS[c.id] }} />{c.title}</div>)}</div>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: "12px 24px 24px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 1, marginBottom: 1 }}>{WEEKDAYS.map(w => <div key={w} style={{ textAlign: "center", fontSize: 11, fontWeight: 700, color: C.textLight, padding: "6px 0", background: C.surface, borderBottom: `2px solid ${C.border}` }}>{w}</div>)}</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 1 }}>
          {calDays.map((cell, idx) => { const isT = cell.date === todayStr, dt = cell.date ? (tbd[cell.date] || []) : [];
            return <div key={idx} onClick={() => cell.date && onAddOnDate(cell.date)} style={{ minHeight: 100, background: C.surface, padding: "4px 6px", opacity: cell.inMonth ? 1 : 0.35, cursor: cell.date ? "pointer" : "default", borderBottom: `1px solid ${C.border}`, borderRight: (idx + 1) % 7 !== 0 ? `1px solid ${C.border}` : "none" }} onMouseEnter={e => { if (cell.inMonth) e.currentTarget.style.background = C.colBg; }} onMouseLeave={e => { e.currentTarget.style.background = C.surface; }}>
              <div style={{ fontSize: 12, fontWeight: isT ? 700 : 500, color: isT ? "#fff" : cell.inMonth ? C.text : C.textVLight, marginBottom: 4 }}><span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 22, height: 22, borderRadius: "50%", background: isT ? C.accent : "transparent" }}>{cell.day}</span></div>
              <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>{dt.slice(0, 3).map(t => { const cc = COL_COLORS[t.column] || C.accent; return <div key={t.id} onClick={e => { e.stopPropagation(); onEdit(t); }} style={{ fontSize: 11, padding: "3px 6px", borderRadius: 3, background: `${cc}11`, borderLeft: `3px solid ${cc}`, color: C.text, fontWeight: 500, cursor: "pointer", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{t.title}</div>; })}{dt.length > 3 && <span style={{ fontSize: 10, color: C.textVLight, fontWeight: 600, paddingLeft: 4 }}>+{dt.length - 3}</span>}</div>
            </div>; })}
        </div>
      </div>
    </div>
  );
}

/* ═══ Task Modal ═══ */
function TaskModal({ task, columnId, defaultDate, onSave, onClose }) {
  const isEdit = !!task;
  const [title, setTitle] = useState(task?.title || ""), [desc, setDesc] = useState(task?.desc || ""), [priority, setPriority] = useState(task?.priority || "medium");
  const [assignees, setAssignees] = useState(task?.assignees || []), [tagIn, setTagIn] = useState(""), [tags, setTags] = useState(task?.tags || []);
  const [col, setCol] = useState(task?.column || columnId || "backlog"), [date, setDate] = useState(task?.created || defaultDate || new Date().toISOString().slice(0, 10));
  const toggle = id => setAssignees(p => p.includes(id) ? p.filter(a => a !== id) : [...p, id]);
  const addTag = () => { const t = tagIn.trim(); if (t && !tags.includes(t)) { setTags([...tags, t]); setTagIn(""); } };
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(9,30,66,0.54)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.surface, borderRadius: 8, padding: "24px 28px", width: "100%", maxWidth: 500, boxShadow: "0 8px 40px rgba(9,30,66,0.35)", maxHeight: "85vh", overflowY: "auto" }}>
        <h3 style={{ margin: "0 0 20px", color: C.text, fontSize: 18, fontWeight: 600 }}>{isEdit ? "課題を編集" : "課題を作成"}</h3>
        <Lbl>タイトル *</Lbl><input value={title} onChange={e => setTitle(e.target.value)} placeholder="課題のタイトルを入力" style={{ ...inpStyle, marginBottom: 14 }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>説明</Lbl><textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="説明（任意）" rows={3} style={{ ...inpStyle, marginBottom: 14, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />
        <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
          <div style={{ flex: 1 }}><Lbl>日付</Lbl><input type="date" value={date} onChange={e => setDate(e.target.value)} style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
          <div style={{ flex: 2 }}><Lbl>ステータス</Lbl><div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>{COLUMNS.map(c => <button key={c.id} onClick={() => setCol(c.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: col === c.id ? C.accentLight : C.colBg, color: col === c.id ? C.accent : C.textLight }}>{c.title}</button>)}</div></div>
        </div>
        <Lbl>優先度</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14 }}>{Object.entries(PRIORITY).map(([k, v]) => <button key={k} onClick={() => setPriority(k)} style={{ padding: "5px 14px", borderRadius: 3, fontSize: 12, fontWeight: 600, cursor: "pointer", border: priority === k ? `2px solid ${v.color}` : `2px solid ${C.border}`, background: priority === k ? v.bg : C.surface, color: priority === k ? v.color : C.textLight, display: "flex", alignItems: "center", gap: 4 }}><span style={{ fontWeight: 800 }}>{v.icon}</span> {v.label}</button>)}</div>
        <Lbl>担当者</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>{MEMBERS.map(m => <button key={m.id} onClick={() => toggle(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px", borderRadius: 3, cursor: "pointer", fontSize: 12, fontWeight: 500, border: assignees.includes(m.id) ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: assignees.includes(m.id) ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={20} />{m.name}</button>)}</div>
        <Lbl>ラベル</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>{tags.map(t => <span key={t} style={{ fontSize: 11, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 4 }}>{t}<span onClick={() => setTags(tags.filter(x => x !== t))} style={{ cursor: "pointer", fontSize: 14, lineHeight: 1 }}>×</span></span>)}<input value={tagIn} onChange={e => setTagIn(e.target.value)} onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addTag())} placeholder="ラベル追加 (Enter)" style={{ ...inpStyle, width: 130, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} /></div>
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
          <button onClick={onClose} style={{ padding: "8px 20px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 13, fontWeight: 500 }}>キャンセル</button>
          <button onClick={() => { if (!title.trim()) return; onSave({ id: task?.id || `DASH-${nextNum++}`, column: col, title: title.trim(), desc: desc.trim(), priority, assignees, tags, created: date }); }} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>{isEdit ? "更新" : "作成"}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══ Goal Modal ═══ */
function GoalModal({ goal, mode, onSave, onClose }) {
  const isEdit = !!goal;
  const [title, setTitle] = useState(goal?.title || "");
  const [desc, setDesc] = useState(goal?.desc || "");
  const [progress, setProgress] = useState(goal?.progress ?? 0);
  const [level, setLevel] = useState(goal?.level || "company");
  const [memberId, setMemberId] = useState(goal?.memberId || "m1");
  const [period, setPeriod] = useState(goal?.period || "annual");
  const [krText, setKrText] = useState("");
  const [keyResults, setKeyResults] = useState(goal?.keyResults || []);
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(9,30,66,0.54)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.surface, borderRadius: 8, padding: "24px 28px", width: "100%", maxWidth: 500, boxShadow: "0 8px 40px rgba(9,30,66,0.35)", maxHeight: "85vh", overflowY: "auto" }}>
        <h3 style={{ margin: "0 0 20px", color: C.text, fontSize: 18, fontWeight: 600 }}>{isEdit ? "目標を編集" : "目標を追加"}</h3>
        {mode === "org" && (<><Lbl>階層</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap" }}>{ORG_LEVELS.map(l => <button key={l.id} onClick={() => setLevel(l.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: level === l.id ? `${l.color}18` : C.colBg, color: level === l.id ? l.color : C.textLight }}>{l.icon} {l.label}</button>)}</div></>)}
        {mode === "personal" && (<>
          <Lbl>メンバー</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>{MEMBERS.map(m => <button key={m.id} onClick={() => setMemberId(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px", borderRadius: 3, cursor: "pointer", fontSize: 12, fontWeight: 500, border: memberId === m.id ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: memberId === m.id ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={20} />{m.name}</button>)}</div>
          <Lbl>期間</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap" }}>{PERIODS.map(p => <button key={p.id} onClick={() => setPeriod(p.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: period === p.id ? C.accentLight : C.colBg, color: period === p.id ? C.accent : C.textLight }}>{p.label}</button>)}</div>
        </>)}
        <Lbl>目標タイトル *</Lbl><input value={title} onChange={e => setTitle(e.target.value)} placeholder="目標を入力" style={{ ...inpStyle, marginBottom: 14 }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>説明</Lbl><textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="説明（任意）" rows={2} style={{ ...inpStyle, marginBottom: 14, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>進捗 ({progress}%)</Lbl>
        <input type="range" min={0} max={100} value={progress} onChange={e => setProgress(Number(e.target.value))} style={{ width: "100%", marginBottom: 14, accentColor: C.accent }} />
        {mode === "personal" && (<>
          <Lbl>Key Results</Lbl>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 14 }}>
            {keyResults.map((kr, i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: C.text, background: C.colBg, padding: "4px 8px", borderRadius: 3 }}><span style={{ flex: 1 }}>{kr}</span><span onClick={() => setKeyResults(keyResults.filter((_, j) => j !== i))} style={{ cursor: "pointer", color: C.danger, fontSize: 14 }}>×</span></div>)}
            <input value={krText} onChange={e => setKrText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); if (krText.trim()) { setKeyResults([...keyResults, krText.trim()]); setKrText(""); } } }} placeholder="KR を追加 (Enter)" style={{ ...inpStyle, flex: 1, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} />
          </div>
        </>)}
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
          <button onClick={onClose} style={{ padding: "8px 20px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 13, fontWeight: 500 }}>キャンセル</button>
          <button onClick={() => {
            if (!title.trim()) return;
            const base = { title: title.trim(), desc: desc.trim(), progress };
            if (mode === "org") onSave({ id: goal?.id || `og${goalNextId++}`, level, ...base });
            else onSave({ id: goal?.id || `pg${goalNextId++}`, memberId, period, keyResults, ...base });
          }} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>{isEdit ? "更新" : "追加"}</button>
        </div>
      </div>
    </div>
  );
}

/* ═══ Goals Page ═══ */
function GoalsPage({ orgGoals, personalGoals, onSaveOrgGoal, onDeleteOrgGoal, onSavePersonalGoal, onDeletePersonalGoal }) {
  const [tab, setTab] = useState("org");
  const [modal, setModal] = useState(null);
  const [expandedLevels, setExpandedLevels] = useState({ company: true, division: true, dept: true, section: true, group: true });
  const [selectedMember, setSelectedMember] = useState("m1");
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const toggleLevel = id => setExpandedLevels(p => ({ ...p, [id]: !p[id] }));

  const saveGoal = (goal) => {
    if (modal.mode === "org") onSaveOrgGoal(goal);
    else onSavePersonalGoal(goal);
    setModal(null);
  };

  const memberGoals = personalGoals.filter(g => g.memberId === selectedMember && (selectedPeriod === "all" || g.period === selectedPeriod));
  const member = MEMBERS.find(m => m.id === selectedMember);
  const levelAvg = (levelId) => { const gs = orgGoals.filter(g => g.level === levelId); return gs.length ? Math.round(gs.reduce((s, g) => s + g.progress, 0) / gs.length) : 0; };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>目標管理</h1>
          <div style={{ display: "flex", background: C.colBg, borderRadius: 4, padding: 2, border: `1px solid ${C.border}` }}>
            {[{ id: "org", label: "🏢 組織方針" }, { id: "personal", label: "👤 個人目標" }].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "4px 12px", borderRadius: 3, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600, background: tab === t.id ? C.surface : "transparent", color: tab === t.id ? C.accent : C.textLight, boxShadow: tab === t.id ? "0 1px 3px rgba(9,30,66,0.13)" : "none" }}>{t.label}</button>
            ))}
          </div>
        </div>
        <button onClick={() => setModal({ mode: tab })} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 目標を追加</button>
      </header>
      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {tab === "org" ? (
          <div style={{ maxWidth: 900 }}>
            {ORG_LEVELS.map(level => {
              const goals = orgGoals.filter(g => g.level === level.id);
              const avg = levelAvg(level.id);
              const expanded = expandedLevels[level.id];
              return (
                <div key={level.id} style={{ marginBottom: 4 }}>
                  <button onClick={() => toggleLevel(level.id)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "10px 14px", background: C.surface, border: "none", borderBottom: `1px solid ${C.border}`, borderLeft: `4px solid ${level.color}`, cursor: "pointer", borderRadius: expanded ? "6px 6px 0 0" : 6 }}>
                    <span style={{ color: level.color, display: "flex" }}>{expanded ? I.chevD : I.chevR}</span>
                    <span style={{ fontSize: 18 }}>{level.icon}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: C.text, flex: 1, textAlign: "left" }}>{level.label}</span>
                    <span style={{ fontSize: 11, color: C.textVLight, marginRight: 8 }}>{goals.length}件</span>
                    <div style={{ width: 80, marginRight: 8 }}><ProgressBar value={avg} color={level.color} height={5} /></div>
                    <span style={{ fontSize: 11, fontWeight: 600, color: level.color, minWidth: 32 }}>{avg}%</span>
                  </button>
                  {expanded && goals.length > 0 && (
                    <div style={{ background: C.surface, borderRadius: "0 0 6px 6px", borderLeft: `4px solid ${level.color}`, borderBottom: `1px solid ${C.border}` }}>
                      {goals.map(g => <OrgGoalRow key={g.id} goal={g} color={level.color} onEdit={() => setModal({ mode: "org", goal: g })} onDelete={() => onDeleteOrgGoal(g.id)} />)}
                    </div>
                  )}
                  {expanded && goals.length === 0 && <div style={{ background: C.surface, borderRadius: "0 0 6px 6px", borderLeft: `4px solid ${level.color}`, borderBottom: `1px solid ${C.border}`, padding: "12px 20px", fontSize: 12, color: C.textVLight }}>目標が設定されていません</div>}
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ maxWidth: 900 }}>
            <div style={{ display: "flex", gap: 8, marginBottom: 16, alignItems: "center", flexWrap: "wrap" }}>
              {MEMBERS.map(m => <button key={m.id} onClick={() => setSelectedMember(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontWeight: 600, border: selectedMember === m.id ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: selectedMember === m.id ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={26} />{m.name}</button>)}
            </div>
            <div style={{ display: "flex", gap: 4, marginBottom: 20 }}>
              <button onClick={() => setSelectedPeriod("all")} style={{ padding: "4px 12px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: selectedPeriod === "all" ? C.accentLight : C.colBg, color: selectedPeriod === "all" ? C.accent : C.textLight }}>すべて</button>
              {PERIODS.map(p => <button key={p.id} onClick={() => setSelectedPeriod(p.id)} style={{ padding: "4px 12px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: selectedPeriod === p.id ? C.accentLight : C.colBg, color: selectedPeriod === p.id ? C.accent : C.textLight }}>{p.label}</button>)}
            </div>
            {memberGoals.length === 0 ? (
              <div style={{ textAlign: "center", padding: 40, color: C.textVLight }}><div style={{ fontSize: 36, marginBottom: 8, opacity: 0.3 }}>🎯</div><div style={{ fontSize: 13 }}>{member?.name} の目標はありません</div></div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340, 1fr))", gap: 12 }}>
                {memberGoals.map(g => <PersonalGoalCard key={g.id} goal={g} onEdit={() => setModal({ mode: "personal", goal: g })} onDelete={() => onDeletePersonalGoal(g.id)} />)}
              </div>
            )}
          </div>
        )}
      </div>
      {modal && <GoalModal goal={modal.goal} mode={modal.mode} onSave={saveGoal} onClose={() => setModal(null)} />}
    </div>
  );
}

function OrgGoalRow({ goal, color, onEdit, onDelete }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderTop: `1px solid ${C.colBg}`, transition: "background .1s", background: hov ? C.cardHover : "transparent" }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 2 }}>{goal.title}</div>
        {goal.desc && <div style={{ fontSize: 11, color: C.textLight, lineHeight: 1.4 }}>{goal.desc}</div>}
      </div>
      <div style={{ width: 100 }}><ProgressBar value={goal.progress} color={color} height={5} /></div>
      <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 36, textAlign: "right" }}>{goal.progress}%</span>
      {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={onEdit} style={aBtn}>✏️</button><button onClick={onDelete} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
    </div>
  );
}

function PersonalGoalCard({ goal, onEdit, onDelete }) {
  const [hov, setHov] = useState(false);
  const periodLabel = PERIODS.find(p => p.id === goal.period)?.label || "";
  const pColor = goal.progress >= 80 ? C.success : goal.progress >= 40 ? C.warning : C.accent;
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ background: C.surface, borderRadius: 6, padding: "16px 18px", border: `1px solid ${hov ? C.borderFocus : C.border}`, boxShadow: hov ? "0 2px 8px rgba(9,30,66,0.15)" : "0 1px 2px rgba(9,30,66,0.08)", transition: "all .15s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent }}>{periodLabel}</span>
        {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={onEdit} style={aBtn}>✏️</button><button onClick={onDelete} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 4, lineHeight: 1.4 }}>{goal.title}</div>
      {goal.desc && <div style={{ fontSize: 12, color: C.textLight, marginBottom: 10, lineHeight: 1.4 }}>{goal.desc}</div>}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: goal.keyResults?.length ? 12 : 0 }}>
        <div style={{ flex: 1 }}><ProgressBar value={goal.progress} color={pColor} height={6} /></div>
        <span style={{ fontSize: 12, fontWeight: 700, color: pColor }}>{goal.progress}%</span>
      </div>
      {goal.keyResults && goal.keyResults.length > 0 && (
        <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 8, marginTop: 4 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textVLight, marginBottom: 4, letterSpacing: 0.5 }}>KEY RESULTS</div>
          {goal.keyResults.map((kr, i) => <div key={i} style={{ fontSize: 12, color: C.textMid, padding: "3px 0", display: "flex", alignItems: "flex-start", gap: 6 }}><span style={{ color: C.accent, fontSize: 10, marginTop: 2, flexShrink: 0 }}>●</span>{kr}</div>)}
        </div>
      )}
    </div>
  );
}

/* ═══ Sidebar ═══ */
function SidebarItem({ item, active, expanded, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 10, position: "relative", width: "100%", padding: expanded ? "8px 12px" : "8px 0", justifyContent: expanded ? "flex-start" : "center", borderRadius: 4, border: "none", cursor: item.disabled ? "default" : "pointer", background: active ? C.sidebarActive : hov && !item.disabled ? C.sidebarHover : "transparent", color: active ? C.sidebarTextActive : item.disabled ? "rgba(255,255,255,0.32)" : C.sidebarText, fontSize: 13, fontWeight: active ? 600 : 500, transition: "all .12s", marginBottom: 2, whiteSpace: "nowrap", opacity: item.disabled ? 0.7 : 1 }}>
      {active && <div style={{ position: "absolute", left: 0, top: "50%", transform: "translateY(-50%)", width: 3, height: 20, background: C.sidebarAccent, borderRadius: "0 2px 2px 0" }} />}
      <span style={{ flexShrink: 0, display: "flex", alignItems: "center" }}>{item.icon}</span>
      {expanded && <span>{item.label}</span>}
      {expanded && item.disabled && <span style={{ fontSize: 9, fontWeight: 600, marginLeft: "auto", background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.45)", padding: "1px 6px", borderRadius: 3 }}>Soon</span>}
    </button>
  );
}

function ViewToggle({ view, onChange }) {
  return (
    <div style={{ display: "flex", background: C.colBg, borderRadius: 4, padding: 2, border: `1px solid ${C.border}` }}>
      {[{ id: "board", icon: I.kanban, label: "ボード" }, { id: "calendar", icon: I.cal, label: "カレンダー" }].map(v => (
        <button key={v.id} onClick={() => onChange(v.id)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 10px", borderRadius: 3, border: "none", cursor: "pointer", background: view === v.id ? C.surface : "transparent", color: view === v.id ? C.accent : C.textLight, fontSize: 11, fontWeight: 600, boxShadow: view === v.id ? "0 1px 3px rgba(9,30,66,0.13)" : "none" }}>{v.icon}<span>{v.label}</span></button>
      ))}
    </div>
  );
}

/* ══════════════════════════════
   Main Dashboard (API-integrated)
   ══════════════════════════════ */
export default function Dashboard() {
  const [tasks, setTasks] = useState(FALLBACK_TASKS);
  const [orgGoals, setOrgGoals] = useState(FALLBACK_ORG_GOALS);
  const [personalGoals, setPersonalGoals] = useState(FALLBACK_PERSONAL_GOALS);
  const [apiAvailable, setApiAvailable] = useState(false);
  const [activeNav, setActiveNav] = useState("tasks");
  const [viewMode, setViewMode] = useState("board");
  const [modal, setModal] = useState(null);
  const [dragOverCol, setDragOverCol] = useState(null);
  const [filterMember, setFilterMember] = useState(null);
  const [search, setSearch] = useState("");
  const [sideOpen, setSideOpen] = useState(true);
  const dragRef = useRef(null);

  // ── Load from API on mount ──
  useEffect(() => {
    (async () => {
      const [t, og, pg] = await Promise.all([api.getTasks(), api.getOrgGoals(), api.getPersonalGoals()]);
      if (t) { setTasks(t); setApiAvailable(true); }
      if (og) setOrgGoals(og);
      if (pg) setPersonalGoals(pg);
    })();
  }, []);

  // ── Task CRUD with API ──
  const saveTask = useCallback(async (task) => {
    const isNew = !tasks.find(t => t.id === task.id);
    // Optimistic update
    setTasks(p => {
      const ex = p.find(t => t.id === task.id);
      return ex ? p.map(t => t.id === task.id ? task : t) : [...p, task];
    });
    setModal(null);
    // API call
    if (apiAvailable) {
      if (isNew) await api.createTask(task);
      else await api.updateTask(task.id, task);
    }
  }, [tasks, apiAvailable]);

  const deleteTask = useCallback(async (id) => {
    setTasks(p => p.filter(t => t.id !== id));
    if (apiAvailable) await api.deleteTask(id);
  }, [apiAvailable]);

  const drag = {
    start: (e, id) => { dragRef.current = id; e.dataTransfer.effectAllowed = "move"; },
    end: () => { dragRef.current = null; setDragOverCol(null); },
    over: (col) => setDragOverCol(col),
    leave: () => setDragOverCol(null),
    drop: async (e, col) => {
      e.preventDefault();
      const taskId = dragRef.current;
      if (taskId) {
        setTasks(p => p.map(t => t.id === taskId ? { ...t, column: col } : t));
        if (apiAvailable) await api.moveTask(taskId, col);
      }
      dragRef.current = null;
      setDragOverCol(null);
    },
  };

  // ── Org Goal CRUD with API ──
  const saveOrgGoal = useCallback(async (goal) => {
    const isNew = !orgGoals.find(g => g.id === goal.id);
    setOrgGoals(p => {
      const ex = p.find(g => g.id === goal.id);
      return ex ? p.map(g => g.id === goal.id ? goal : g) : [...p, goal];
    });
    if (apiAvailable) {
      if (isNew) await api.createOrgGoal(goal);
      else await api.updateOrgGoal(goal.id, goal);
    }
  }, [orgGoals, apiAvailable]);

  const deleteOrgGoal = useCallback(async (id) => {
    setOrgGoals(p => p.filter(g => g.id !== id));
    if (apiAvailable) await api.deleteOrgGoal(id);
  }, [apiAvailable]);

  // ── Personal Goal CRUD with API ──
  const savePersonalGoal = useCallback(async (goal) => {
    const isNew = !personalGoals.find(g => g.id === goal.id);
    setPersonalGoals(p => {
      const ex = p.find(g => g.id === goal.id);
      return ex ? p.map(g => g.id === goal.id ? goal : g) : [...p, goal];
    });
    if (apiAvailable) {
      if (isNew) await api.createPersonalGoal(goal);
      else await api.updatePersonalGoal(goal.id, goal);
    }
  }, [personalGoals, apiAvailable]);

  const deletePersonalGoal = useCallback(async (id) => {
    setPersonalGoals(p => p.filter(g => g.id !== id));
    if (apiAvailable) await api.deletePersonalGoal(id);
  }, [apiAvailable]);

  // ── Filters ──
  const filtered = tasks.filter(t => {
    if (filterMember && !t.assignees.includes(filterMember)) return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) && !(t.desc || "").toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const total = tasks.length, done = tasks.filter(t => t.column === "done").length;

  const Placeholder = ({ title, icon, desc }) => (
    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", background: C.bg }}>
      <div style={{ textAlign: "center", color: C.textLight }}>
        <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.25 }}>{icon}</div>
        <h2 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 600, color: C.text }}>{title}</h2>
        <p style={{ margin: 0, fontSize: 13, color: C.textVLight }}>{desc}</p>
        <span style={{ display: "inline-block", marginTop: 16, fontSize: 11, fontWeight: 600, padding: "4px 14px", borderRadius: 3, background: C.accentLight, color: C.accent }}>Coming Soon</span>
      </div>
    </div>
  );

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Noto Sans JP',sans-serif", color: C.text, overflow: "hidden", fontSize: 14 }}>
      <style>{`*::-webkit-scrollbar{width:6px;height:6px}*::-webkit-scrollbar-track{background:transparent}*::-webkit-scrollbar-thumb{background:#c1c7d0;border-radius:3px}*::-webkit-scrollbar-thumb:hover{background:#a5adba}*{box-sizing:border-box}`}</style>

      {/* Sidebar */}
      <aside style={{ width: sideOpen ? 240 : 56, background: C.sidebarBg, display: "flex", flexDirection: "column", transition: "width .2s ease", flexShrink: 0, overflow: "hidden" }}>
        <div style={{ padding: sideOpen ? "16px 16px 12px" : "16px 10px 12px", display: "flex", alignItems: "center", gap: 10, minHeight: 56 }}>
          <div style={{ width: 32, height: 32, borderRadius: 6, background: "linear-gradient(135deg,#0065ff,#4c9aff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 800, color: "#fff", flexShrink: 0 }}>D</div>
          {sideOpen && <div style={{ overflow: "hidden" }}><div style={{ fontSize: 14, fontWeight: 700, color: "#fff", whiteSpace: "nowrap" }}>Dashboard</div><div style={{ fontSize: 10, color: C.sidebarText, fontWeight: 500 }}>プロジェクト管理{apiAvailable ? "" : " (オフライン)"}</div></div>}
        </div>
        <div style={{ height: 1, background: "rgba(255,255,255,0.08)", margin: "0 12px" }} />
        <nav style={{ padding: "8px 8px 0", flex: 1 }}>{NAV_MAIN.map(item => <SidebarItem key={item.id} item={item} active={activeNav === item.id} expanded={sideOpen} onClick={() => !item.disabled && setActiveNav(item.id)} />)}</nav>
        <div style={{ height: 1, background: "rgba(255,255,255,0.08)", margin: "0 12px" }} />
        <nav style={{ padding: "8px 8px 4px" }}>{NAV_BOTTOM.map(item => <SidebarItem key={item.id} item={item} active={activeNav === item.id} expanded={sideOpen} onClick={() => !item.disabled && setActiveNav(item.id)} />)}</nav>
        <button onClick={() => setSideOpen(!sideOpen)} style={{ margin: "4px 8px 12px", padding: "6px", borderRadius: 4, border: "none", background: "rgba(255,255,255,0.06)", color: C.sidebarText, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>{sideOpen ? I.chevL : I.chevR}</button>
      </aside>

      {/* Main */}
      {activeNav === "tasks" ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
          <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}><h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>タスク管理</h1><span style={{ fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.successBg, color: C.success }}>{done}/{total} 完了</span></div>
                <div style={{ marginTop: 4, height: 3, width: 140, background: C.border, borderRadius: 2, overflow: "hidden" }}><div style={{ height: "100%", width: total > 0 ? `${(done / total) * 100}%` : "0%", background: C.accent, borderRadius: 2, transition: "width .3s" }} /></div>
              </div>
              <ViewToggle view={viewMode} onChange={setViewMode} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ position: "relative" }}><span style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: C.textVLight }}>{I.search}</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="課題を検索" style={{ padding: "6px 10px 6px 28px", borderRadius: 3, border: `2px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 12, outline: "none", width: 180 }} onFocus={e => e.target.style.borderColor = C.borderFocus} onBlur={e => e.target.style.borderColor = C.border} /></div>
              <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
                <button onClick={() => setFilterMember(null)} style={{ padding: "3px 8px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: !filterMember ? C.accentLight : "transparent", color: !filterMember ? C.accent : C.textLight }}>全員</button>
                {MEMBERS.map(m => <button key={m.id} onClick={() => setFilterMember(m.id === filterMember ? null : m.id)} style={{ padding: 2, borderRadius: "50%", border: filterMember === m.id ? `2px solid ${m.color}` : "2px solid transparent", background: "transparent", cursor: "pointer", lineHeight: 0 }}><Avatar member={m} size={24} /></button>)}
              </div>
            </div>
          </header>
          {viewMode === "board" ? (
            <div style={{ flex: 1, overflowX: "auto", overflowY: "auto", padding: "16px 20px", display: "flex", gap: 10 }}>
              {COLUMNS.map(c => <BoardCol key={c.id} col={c} tasks={filtered.filter(t => t.column === c.id)} onAdd={cid => setModal({ columnId: cid })} onEdit={t => setModal({ task: t })} onDelete={deleteTask} drag={drag} isOver={dragOverCol === c.id} />)}
            </div>
          ) : (
            <CalendarView tasks={filtered} onEdit={t => setModal({ task: t })} onDelete={deleteTask} onAddOnDate={date => setModal({ defaultDate: date })} />
          )}
        </div>
      ) : activeNav === "goals" ? (
        <GoalsPage orgGoals={orgGoals} personalGoals={personalGoals}
          onSaveOrgGoal={saveOrgGoal} onDeleteOrgGoal={deleteOrgGoal}
          onSavePersonalGoal={savePersonalGoal} onDeletePersonalGoal={deletePersonalGoal} />
      ) : activeNav === "knowledge" ? (
        <Placeholder title="ナレッジ" icon="📖" desc="チームのナレッジベースを一元管理します" />
      ) : (
        <Placeholder title="設定" icon="⚙️" desc="プロジェクトとチームの設定を管理します" />
      )}

      {modal && <TaskModal task={modal.task} columnId={modal.columnId} defaultDate={modal.defaultDate} onSave={saveTask} onClose={() => setModal(null)} />}
    </div>
  );
}
