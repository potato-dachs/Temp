const fs = require("fs");
const path = require("path");
const scrumFiles = require("./scrum-files");
const { gitea } = require("./gitea");

const API_BASE = process.env.DASHBOARD_API || "http://localhost:3001";
const CLAUDE_API = "https://api.anthropic.com/v1/messages";
const CLAUDE_KEY = process.env.ANTHROPIC_API_KEY || "";
const DEFAULT_MODEL_SMART = "claude-opus-4-20250514";
const DEFAULT_MODEL_FAST = "claude-sonnet-4-20250514";

/* ═══ Tool Definitions (Function Calling) ═══ */
const DASHBOARD_TOOLS = [
  {
    name: "api_call",
    description: "ダッシュボードAPIを呼び出す。タスク管理、スプリント、ナレッジ、ふりかえり等の操作に使用。",
    input_schema: {
      type: "object",
      properties: {
        method: { type: "string", enum: ["GET", "POST", "PUT", "PATCH", "DELETE"], description: "HTTPメソッド" },
        path: { type: "string", description: "APIパス（例: /api/tasks, /api/sprints/sp-1）" },
        body: { type: "object", description: "リクエストボディ（POST/PUT/PATCHの場合）" },
      },
      required: ["method", "path"],
    },
  },
  {
    name: "read_scrum_file",
    description: "スクラム成果物ファイルを読み取る（scrum/以下のmd, csvファイル）",
    input_schema: { type: "object", properties: { path: { type: "string", description: "scrum/以下の相対パス" } }, required: ["path"] },
  },
  {
    name: "write_scrum_file",
    description: "スクラム成果物ファイルに書き込む",
    input_schema: { type: "object", properties: { path: { type: "string" }, content: { type: "string" } }, required: ["path", "content"] },
  },
  {
    name: "append_scrum_file",
    description: "スクラム成果物ファイルに追記する",
    input_schema: { type: "object", properties: { path: { type: "string" }, content: { type: "string" } }, required: ["path", "content"] },
  },
  {
    name: "send_message",
    description: "他のエージェントにメッセージを送信する",
    input_schema: { type: "object", properties: { to: { type: "string" }, content: { type: "string" } }, required: ["to", "content"] },
  },
  {
    name: "report_to_human",
    description: "人間に報告・質問・承認依頼する",
    input_schema: { type: "object", properties: { type: { type: "string", enum: ["report", "question", "approval_request"] }, content: { type: "string" } }, required: ["type", "content"] },
  },
  // ── Git/Gitea Tools ──
  {
    name: "git_create_branch",
    description: "Giteaに新しいブランチを作成する。タスク着手時に feature/dash-N 形式で作成。",
    input_schema: { type: "object", properties: { branchName: { type: "string", description: "ブランチ名（例: feature/dash-10）" }, fromBranch: { type: "string", description: "分岐元ブランチ（デフォルト: main）" } }, required: ["branchName"] },
  },
  {
    name: "git_read_file",
    description: "Giteaリポジトリからファイルの内容を読み取る。既存コードの確認に使用。",
    input_schema: { type: "object", properties: { filePath: { type: "string", description: "ファイルパス（例: src/App.jsx）" }, ref: { type: "string", description: "ブランチ名（デフォルト: main）" } }, required: ["filePath"] },
  },
  {
    name: "git_write_file",
    description: "Giteaリポジトリにファイルを作成または更新する（自動コミット）。コード生成の主要ツール。",
    input_schema: { type: "object", properties: { filePath: { type: "string", description: "ファイルパス" }, content: { type: "string", description: "ファイル内容" }, message: { type: "string", description: "コミットメッセージ" }, branch: { type: "string", description: "対象ブランチ" } }, required: ["filePath", "content", "message", "branch"] },
  },
  {
    name: "git_list_dir",
    description: "Giteaリポジトリのディレクトリ内容を一覧取得する。プロジェクト構造の把握に使用。",
    input_schema: { type: "object", properties: { dirPath: { type: "string", description: "ディレクトリパス（空文字でルート）" }, ref: { type: "string", description: "ブランチ名" } }, required: [] },
  },
  {
    name: "git_create_pr",
    description: "Pull Requestを作成する。実装完了後にレビュー依頼として使用。",
    input_schema: { type: "object", properties: { title: { type: "string", description: "PRタイトル" }, body: { type: "string", description: "PR説明（Markdown）" }, headBranch: { type: "string", description: "マージ元ブランチ" }, baseBranch: { type: "string", description: "マージ先ブランチ（デフォルト: main）" } }, required: ["title", "headBranch"] },
  },
  {
    name: "git_get_pr_diff",
    description: "Pull Requestの差分（diff）を取得する。コードレビューに使用。",
    input_schema: { type: "object", properties: { prNumber: { type: "integer", description: "PR番号" } }, required: ["prNumber"] },
  },
  {
    name: "git_review_pr",
    description: "Pull Requestにレビューコメントを投稿する。APPROVE / REQUEST_CHANGES / COMMENT。",
    input_schema: { type: "object", properties: { prNumber: { type: "integer" }, body: { type: "string", description: "レビューコメント" }, event: { type: "string", enum: ["APPROVE", "REQUEST_CHANGES", "COMMENT"], description: "レビュー結果" } }, required: ["prNumber", "body", "event"] },
  },
  {
    name: "git_merge_pr",
    description: "Pull Requestをマージする。レビュー承認後に使用。",
    input_schema: { type: "object", properties: { prNumber: { type: "integer" }, mergeStyle: { type: "string", enum: ["merge", "rebase", "squash"], description: "マージ方式（デフォルト: squash）" } }, required: ["prNumber"] },
  },
  {
    name: "git_list_prs",
    description: "Pull Request一覧を取得する。",
    input_schema: { type: "object", properties: { state: { type: "string", enum: ["open", "closed", "all"] } }, required: [] },
  },
];

/* ═══ Agent Definitions ═══ */
const AGENTS = {
  customer: {
    id: "customer",
    name: "佐藤",
    role: "顧客代表",
    model: DEFAULT_MODEL_SMART,
    promptFile: "customer-agent.md",
  },
  po: {
    id: "po",
    name: "鈴木",
    role: "プロダクトオーナー",
    model: DEFAULT_MODEL_SMART,
    promptFile: "po-agent.md",
  },
  sm: {
    id: "sm",
    name: "高橋",
    role: "スクラムマスター",
    model: DEFAULT_MODEL_SMART,
    promptFile: "sm-agent.md",
  },
  "dev-frontend": {
    id: "dev-frontend",
    name: "伊藤",
    role: "開発者（フロントエンド）",
    model: DEFAULT_MODEL_FAST,
    promptFile: "dev-agent.md",
    extra: "あなたの専門はフロントエンド開発です。AGENT_ID=dev-frontend, SPECIALTY=React, CSS, UI/UX実装, TECH_STACK=React 18, Vite, TailwindCSS。一次情報にあたることを重視し、Web検索やドキュメント検索を駆使して設計・実装します。",
  },
  "dev-backend": {
    id: "dev-backend",
    name: "田中",
    role: "開発者（バックエンド）",
    model: DEFAULT_MODEL_FAST,
    promptFile: "dev-agent.md",
    extra: "あなたの専門はバックエンド開発です。AGENT_ID=dev-backend, SPECIALTY=API設計, DB, 認証, ビジネスロジック, TECH_STACK=Node.js, Express, SQLite。慎重派で「本当にそれ要る？」と確認してから設計する性格です。",
  },
};

/* ═══ Load System Prompt ═══ */
function loadSystemPrompt(agentId) {
  const agent = AGENTS[agentId];
  if (!agent) throw new Error(`Unknown agent: ${agentId}`);

  const promptPath = path.join(__dirname, "..", "docs", "agents", agent.promptFile);
  let prompt = "";

  if (fs.existsSync(promptPath)) {
    const raw = fs.readFileSync(promptPath, "utf8");
    // Extract the System Prompt section
    const match = raw.match(/## System Prompt\n([\s\S]*?)(?=\n## API Tools|\n---\s*$|$)/);
    prompt = match ? match[1].trim() : raw;
  }

  if (agent.extra) {
    prompt += "\n\n" + agent.extra;
  }

  prompt += `\n\nあなたの名前は${agent.name}、役割は${agent.role}です。`;
  prompt += `\n現在のプロジェクトはダッシュボードAPIの URL: ${API_BASE} で管理されています。`;

  return prompt;
}

/* ═══ Execute Tool Call ═══ */
async function executeTool(toolName, toolInput) {
  switch (toolName) {
    case "api_call": {
      const { method, path: apiPath, body } = toolInput;
      const url = `${API_BASE}${apiPath}`;
      const opts = {
        method,
        headers: { "Content-Type": "application/json" },
      };
      if (body && ["POST", "PUT", "PATCH"].includes(method)) {
        opts.body = JSON.stringify(body);
      }
      try {
        const res = await fetch(url, opts);
        const data = await res.json();
        return JSON.stringify(data, null, 2);
      } catch (e) {
        return JSON.stringify({ error: e.message });
      }
    }
    case "read_scrum_file": {
      const content = scrumFiles.readFile(toolInput.path);
      return content || `File not found: ${toolInput.path}`;
    }
    case "write_scrum_file": {
      scrumFiles.writeFile(toolInput.path, toolInput.content);
      return `Written: ${toolInput.path}`;
    }
    case "append_scrum_file": {
      scrumFiles.appendFile(toolInput.path, toolInput.content);
      return `Appended: ${toolInput.path}`;
    }
    case "send_message": {
      // Messages are collected and routed by the orchestrator
      return JSON.stringify({ status: "message_queued", to: toolInput.to, content: toolInput.content });
    }
    case "report_to_human": {
      return JSON.stringify({ status: "reported_to_human", type: toolInput.type, content: toolInput.content });
    }
    // ── Git/Gitea Tools ──
    case "git_create_branch": {
      try {
        const result = await gitea.createBranch(toolInput.branchName, toolInput.fromBranch);
        return JSON.stringify({ status: "branch_created", branch: toolInput.branchName });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_read_file": {
      try {
        const file = await gitea.getFile(toolInput.filePath, toolInput.ref);
        if (!file) return JSON.stringify({ error: "File not found" });
        return JSON.stringify({ path: file.path, content: file.content });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_write_file": {
      try {
        await gitea.upsertFile(toolInput.filePath, toolInput.content, toolInput.message, toolInput.branch);
        return JSON.stringify({ status: "committed", file: toolInput.filePath, branch: toolInput.branch, message: toolInput.message });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_list_dir": {
      try {
        const items = await gitea.listDir(toolInput.dirPath || "", toolInput.ref);
        return JSON.stringify(items.map(i => ({ name: i.name, type: i.type, path: i.path })));
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_create_pr": {
      try {
        const pr = await gitea.createPR(toolInput.title, toolInput.body || "", toolInput.headBranch, toolInput.baseBranch);
        return JSON.stringify({ status: "pr_created", number: pr.number, url: pr.html_url });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_get_pr_diff": {
      try {
        const diff = await gitea.getPRDiff(toolInput.prNumber);
        // Truncate if too large
        const maxLen = 8000;
        return diff.length > maxLen ? diff.slice(0, maxLen) + "\n... (truncated)" : diff;
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_review_pr": {
      try {
        await gitea.reviewPR(toolInput.prNumber, toolInput.body, toolInput.event);
        return JSON.stringify({ status: "review_posted", prNumber: toolInput.prNumber, event: toolInput.event });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_merge_pr": {
      try {
        await gitea.mergePR(toolInput.prNumber, toolInput.mergeStyle || "squash");
        return JSON.stringify({ status: "merged", prNumber: toolInput.prNumber });
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    case "git_list_prs": {
      try {
        const prs = await gitea.listPRs(toolInput.state || "open");
        return JSON.stringify(prs.map(p => ({ number: p.number, title: p.title, state: p.state, user: p.user?.login, head: p.head?.ref, base: p.base?.ref })));
      } catch (e) { return JSON.stringify({ error: e.message }); }
    }
    default:
      return JSON.stringify({ error: `Unknown tool: ${toolName}` });
  }
}

/* ═══ Call Claude API ═══ */
async function callClaude(agentId, messages, maxTokens = 4096) {
  const agent = AGENTS[agentId];
  if (!agent) throw new Error(`Unknown agent: ${agentId}`);

  if (!CLAUDE_KEY) {
    console.error("⚠️  ANTHROPIC_API_KEY not set. Running in dry-run mode.");
    return { text: `[DRY RUN] ${agent.name}(${agent.role}): I would respond to the conversation.`, toolCalls: [], tokenUsage: 0 };
  }

  const systemPrompt = loadSystemPrompt(agentId);

  const body = {
    model: agent.model,
    max_tokens: maxTokens,
    system: systemPrompt,
    messages,
    tools: DASHBOARD_TOOLS,
  };

  const res = await fetch(CLAUDE_API, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": CLAUDE_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Claude API error: ${res.status} ${err}`);
  }

  const data = await res.json();
  const text = data.content.filter(c => c.type === "text").map(c => c.text).join("\n");
  const toolCalls = data.content.filter(c => c.type === "tool_use");
  const tokenUsage = (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0);

  return { text, toolCalls, tokenUsage, stopReason: data.stop_reason };
}

/* ═══ Run Agent Turn (with tool execution loop) ═══ */
async function runAgentTurn(agentId, userMessage, conversationHistory = [], maxToolLoops = 10) {
  const messages = [...conversationHistory, { role: "user", content: userMessage }];
  let totalTokens = 0;
  const collectedMessages = [];
  const humanReports = [];

  for (let i = 0; i < maxToolLoops; i++) {
    const result = await callClaude(agentId, messages);
    totalTokens += result.tokenUsage;

    if (result.toolCalls.length === 0 || result.stopReason === "end_turn") {
      // No more tool calls — agent is done
      return {
        text: result.text,
        messages: collectedMessages,
        humanReports,
        tokenUsage: totalTokens,
        history: messages.concat([{ role: "assistant", content: result.text }]),
      };
    }

    // Process tool calls
    const assistantContent = [];
    if (result.text) assistantContent.push({ type: "text", text: result.text });
    for (const tc of result.toolCalls) {
      assistantContent.push({ type: "tool_use", id: tc.id, name: tc.name, input: tc.input });
    }
    messages.push({ role: "assistant", content: assistantContent });

    // Execute tools and collect results
    const toolResults = [];
    for (const tc of result.toolCalls) {
      const output = await executeTool(tc.name, tc.input);

      // Collect inter-agent messages and human reports
      if (tc.name === "send_message") {
        collectedMessages.push({ to: tc.input.to, content: tc.input.content });
      }
      if (tc.name === "report_to_human") {
        humanReports.push({ type: tc.input.type, content: tc.input.content });
      }

      toolResults.push({ type: "tool_result", tool_use_id: tc.id, content: output });
    }
    messages.push({ role: "user", content: toolResults });
  }

  return {
    text: "[Max tool loops reached]",
    messages: collectedMessages,
    humanReports,
    tokenUsage: totalTokens,
    history: messages,
  };
}

module.exports = {
  AGENTS,
  DASHBOARD_TOOLS,
  loadSystemPrompt,
  executeTool,
  callClaude,
  runAgentTurn,
};
