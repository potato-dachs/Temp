const readline = require("readline");
const { runAgentTurn } = require("./agent-runtime");
const scrumFiles = require("./scrum-files");

/* ═══ Config ═══ */
const SPRINT_DAYS = parseInt(process.env.SPRINT_DAYS || "3");
const TOKEN_BUDGET = parseInt(process.env.TOKEN_BUDGET || "2000000");
const TOKEN_WARNING = 0.8;

/* ═══ State ═══ */
let totalTokensUsed = 0;
let currentSprintNum = 0;
let sprintDir = "";

/* ═══ Human I/O ═══ */
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
function askHuman(question) {
  return new Promise(resolve => {
    console.log(`\n🧑 [人間への質問]\n${question}`);
    rl.question("\n> あなたの回答: ", answer => resolve(answer.trim()));
  });
}
function notifyHuman(message) {
  console.log(`\n📢 [人間への報告]\n${message}`);
}

/* ═══ Logger ═══ */
function log(agent, message) {
  const name = { customer: "佐藤", po: "鈴木", sm: "高橋", "dev-frontend": "伊藤", "dev-backend": "田中" }[agent] || agent;
  console.log(`\n${"─".repeat(60)}`);
  console.log(`🤖 [${name}] ${message.slice(0, 200)}${message.length > 200 ? "..." : ""}`);
}

function logSection(title) {
  console.log(`\n${"═".repeat(60)}`);
  console.log(`  ${title}`);
  console.log(`${"═".repeat(60)}`);
}

function logTokens() {
  const pct = ((totalTokensUsed / TOKEN_BUDGET) * 100).toFixed(1);
  console.log(`📊 トークン使用量: ${totalTokensUsed.toLocaleString()} / ${TOKEN_BUDGET.toLocaleString()} (${pct}%)`);
  if (totalTokensUsed > TOKEN_BUDGET * TOKEN_WARNING) {
    console.log(`⚠️  トークン予算の${(TOKEN_WARNING * 100)}%を超過しました！`);
  }
}

/* ═══ Agent Runner (with message routing) ═══ */
async function runAgent(agentId, instruction, history = []) {
  log(agentId, instruction.slice(0, 100));
  const result = await runAgentTurn(agentId, instruction, history);
  totalTokensUsed += result.tokenUsage;

  if (result.text) log(agentId, result.text);

  // Handle human reports
  for (const report of result.humanReports) {
    if (report.type === "question") {
      const answer = await askHuman(report.content);
      // Feed answer back to agent
      const followUp = await runAgentTurn(agentId, `人間からの回答: ${answer}`, result.history);
      totalTokensUsed += followUp.tokenUsage;
      if (followUp.text) log(agentId, followUp.text);
      return { ...followUp, messages: [...result.messages, ...followUp.messages] };
    } else {
      notifyHuman(report.content);
    }
  }

  // Route inter-agent messages
  for (const msg of result.messages) {
    log(msg.to, `[${agentId}からのメッセージ] ${msg.content.slice(0, 100)}`);
  }

  return result;
}

/* ═══ Sprint Cycle Phases ═══ */

/** Phase 0: Order Creation — Human → Customer Agent */
async function phaseOrderCreate() {
  logSection("Phase 0: 要件整理（佐藤）");

  const humanInput = await askHuman("何を作りたいですか？（簡単な指示でOKです）");

  const orderNum = scrumFiles.getNextOrderNum();
  const result = await runAgent("customer", `
人間からの依頼です。以下の内容を構造化要件書にまとめてください。

人間の指示: "${humanInput}"

要件書を scrum/order/order${String(orderNum).padStart(3, "0")}.md に書き出してください。
不明点があれば report_to_human ツールで人間に質問してください（最大3往復）。
完了したら send_message で po（鈴木）に引き渡してください。
  `);

  return result;
}

/** Phase 1: Backlog Refinement */
async function phaseRefinement() {
  logSection("Phase 1: バックログリファインメント");

  // PO reads current state and refines
  const result = await runAgent("po", `
バックログリファインメントを実施してください。

1. scrum/product_goal.md を読み、必要なら更新
2. scrum/order/ の最新依頼書を読み、PBIに分解
3. 各PBIにタイトル、説明、受入条件を定義
4. scrum/product_backlog.csv に追記/更新
5. api_call で POST /api/tasks を使ってダッシュボードにもタスクを登録
6. 完了したら send_message で sm（高橋）にプランニング準備完了を通知
  `);

  // Dev agents estimate
  for (const devId of ["dev-frontend", "dev-backend"]) {
    await runAgent(devId, `
バックログリファインメント中です。
scrum/product_backlog.csv を読み、各PBIのストーリーポイントを見積もってください。
api_call で GET /api/tasks を使って現在のタスクを確認し、見積もり結果を send_message で po（鈴木）に報告してください。
    `);
  }

  return result;
}

/** Phase 2: Sprint Planning */
async function phaseSprintPlanning() {
  logSection("Phase 2: スプリントプランニング");

  currentSprintNum = scrumFiles.getCurrentSprintNum() + 1;
  sprintDir = scrumFiles.createSprintDir(currentSprintNum);
  const sprintName = `sprint${String(currentSprintNum).padStart(3, "0")}`;
  const sprintId = `sp-${currentSprintNum}`;

  // SM calculates capacity and creates sprint
  const result = await runAgent("sm", `
スプリントプランニングを実施してください。

1. scrum/velocity.csv を読んでベロシティを確認（なければ初回として暫定設定）
2. キャパシティ = ベロシティ × 0.8 で算出
3. api_call で POST /api/sprints を使ってスプリントを作成:
   - id: "${sprintId}"
   - name: "Sprint ${currentSprintNum}"
   - startDate: 今日の日付
   - endDate: ${SPRINT_DAYS}日後
   - status: "planning"
4. scrum/product_backlog.csv から優先度順にPBIを選定（キャパシティ内）
5. api_call で POST /api/sprints/${sprintId}/tasks を使ってタスクをスプリントに割当
6. api_call で PUT /api/sprints/${sprintId} で status を "active" に変更
7. scrum/${sprintName}/sprint_planning.md にプランニング結果を記録
8. scrum/${sprintName}/sprint_backlog.md にバックログを記録
  `);

  return { ...result, sprintId, sprintName };
}

/** Phase 3: One Day of Development */
async function phaseOneDay(dayNum, sprintId, sprintName) {
  logSection(`Phase 3: 開発 Day ${dayNum}`);

  // Daily Scrum (SM)
  console.log(`\n--- デイリースクラム Day ${dayNum} ---`);
  await runAgent("sm", `
デイリースクラム Day ${dayNum} を実施してください。

1. api_call で GET /api/sprints/${sprintId} を使って現在の進捗を確認
2. バーンダウンの状態を分析
3. DoDチェック（日次！）:
   - テスト作成されているか
   - ビルドエラーがないか
   - Lint/Formatエラーがないか
4. scrum/${sprintName}/daily_scrum.md に Day ${dayNum} の記録を追記
5. ブロッカーがあれば対処を検討
  `);

  // Development (Frontend)
  console.log(`\n--- 伊藤 開発作業 Day ${dayNum} ---`);
  await runAgent("dev-frontend", `
開発作業 Day ${dayNum} です。

1. api_call で GET /api/tasks を使って自分にアサインされた未完了タスクを確認
2. 最も優先度の高い未完了タスクに着手（タスクIDを特定）
3. api_call で PATCH /api/tasks/{id}/column で column を "inprogress" に変更
4. ナレッジ検索: api_call で GET /api/knowledge/search/query?q=関連キーワード
5. git_list_dir でリポジトリの構造を確認
6. git_read_file で関連する既存コードを読む
7. git_create_branch でフィーチャーブランチを作成（例: feature/dash-10）
8. git_write_file で実装コードをコミット（1ファイルずつ、適切なコミットメッセージで）
   - テストファイルも必ず作成すること
9. git_create_pr でPull Requestを作成
   - タイトル: タスクID + タイトル
   - 本文: 変更内容の説明 + 関連タスクID
10. api_call で PATCH /api/tasks/{id}/column で column を "review" に変更
11. send_message で dev-backend（田中）にレビューを依頼（PR番号を伝える）
12. 実装中に得た知見があれば api_call で POST /api/knowledge でナレッジ記録
  `);

  // Development (Backend)
  console.log(`\n--- 田中 開発作業 Day ${dayNum} ---`);
  await runAgent("dev-backend", `
開発作業 Day ${dayNum} です。

1. api_call で GET /api/tasks を使って自分にアサインされた未完了タスクを確認
2. 最も優先度の高い未完了タスクに着手
3. api_call で PATCH /api/tasks/{id}/column で column を "inprogress" に変更
4. ナレッジ検索: api_call で GET /api/knowledge/search/query?q=関連キーワード
5. git_list_dir でリポジトリの構造を確認
6. git_read_file で関連する既存コードを読む
7. git_create_branch でフィーチャーブランチを作成
8. git_write_file で実装コードをコミット
   - テストファイルも必ず作成すること
9. git_create_pr でPull Requestを作成
10. api_call で PATCH /api/tasks/{id}/column で column を "review" に変更
11. 伊藤からのレビュー依頼があれば:
    - git_get_pr_diff でPRの差分を取得
    - コードを確認し git_review_pr でレビュー結果を投稿
    - 問題なければ APPROVE、修正必要なら REQUEST_CHANGES
12. 知見があれば POST /api/knowledge でナレッジ記録
  `);

  // PO acceptance for review items
  console.log(`\n--- 鈴木 受入判定 Day ${dayNum} ---`);
  await runAgent("po", `
受入判定を実施してください。

1. api_call で GET /api/tasks を使って "review" ステータスのタスクを確認
2. git_list_prs でオープンなPull Requestを確認
3. 各PRについて git_get_pr_diff で差分を確認
4. 受入条件を照合:
   - 条件を満たしている → git_review_pr で APPROVE + git_merge_pr でマージ
   - api_call で PATCH /api/tasks/{id}/column で "done" に変更
5. 不足がある場合:
   - git_review_pr で REQUEST_CHANGES + 具体的なフィードバック
   - api_call で PATCH /api/tasks/{id}/column で "inprogress" に戻す
  `);
}

/** Phase 4: Sprint Review */
async function phaseSprintReview(sprintId, sprintName) {
  logSection("Phase 4: スプリントレビュー");

  // PO conducts review
  const reviewResult = await runAgent("po", `
スプリントレビューを実施してください。

1. api_call で GET /api/sprints/${sprintId} を使って完了タスクを確認
2. 各PBIの受入条件を最終チェック
3. scrum/${sprintName}/sprint_review.md にレビュー結果を記録
4. send_message で customer（佐藤）に成果を共有
  `);

  // Customer evaluates
  const custResult = await runAgent("customer", `
スプリントレビューの結果を確認してください。

1. api_call で GET /api/sprints/${sprintId} を使って完了タスクを確認
2. 顧客視点でフィードバックを作成
3. report_to_human で人間にサマリーを報告し、承認を要求
4. フィードバックがあれば send_message で po（鈴木）に共有
  `);

  return custResult;
}

/** Phase 5: Sprint Retrospective */
async function phaseRetrospective(sprintId, sprintName) {
  logSection("Phase 5: ふりかえり");

  const retroId = `retro-${currentSprintNum}`;

  const result = await runAgent("sm", `
スプリントレトロスペクティブを実施してください。

1. api_call で GET /api/sprints/${sprintId}/burndown を使ってバーンダウンを分析
2. api_call で POST /api/retros を使ってふりかえりを作成:
   - id: "${retroId}"
   - title: "Sprint ${currentSprintNum} ふりかえり"
   - sprintId: "${sprintId}"
   - date: 今日の日付
3. 自分のKeep/Problem/Tryを items に追加（api_call PUT /api/retros/${retroId}）
4. scrum/${sprintName}/sprint_retrospective.md に記録
5. scrum/velocity.csv にベロシティを追記
6. 改善アクションを1-2個に絞って記録
7. ナレッジに変換: api_call POST /api/knowledge でKPTをナレッジ記事として登録
  `);

  return result;
}

/* ═══ Main: Execute Full Sprint ═══ */
async function executeFullSprint() {
  console.log(`
╔══════════════════════════════════════════════╗
║   🏃 LLM スクラムチーム — スプリント実行      ║
║   スプリント日数: ${SPRINT_DAYS}                          ║
║   トークン予算: ${TOKEN_BUDGET.toLocaleString()}                   ║
╚══════════════════════════════════════════════╝
  `);

  scrumFiles.ensureScrumDirs();

  try {
    // Phase 0: Requirements
    await phaseOrderCreate();
    logTokens();

    // Phase 1: Refinement
    await phaseRefinement();
    logTokens();

    // Phase 2: Planning
    const { sprintId, sprintName } = await phaseSprintPlanning();
    logTokens();

    // Phase 3: Development Days
    for (let day = 1; day <= SPRINT_DAYS; day++) {
      if (totalTokensUsed > TOKEN_BUDGET * TOKEN_WARNING) {
        const cont = await askHuman(`トークン予算の${(TOKEN_WARNING * 100)}%を超えました。続行しますか？ (y/n)`);
        if (cont.toLowerCase() !== "y") {
          notifyHuman("スプリントを中断しました。");
          break;
        }
      }
      await phaseOneDay(day, sprintId, sprintName);
      logTokens();
    }

    // Phase 4: Review
    await phaseSprintReview(sprintId, sprintName);
    logTokens();

    // Phase 5: Retrospective
    await phaseRetrospective(sprintId, sprintName);
    logTokens();

    logSection("🎉 スプリント完了！");
    console.log(`  消費トークン: ${totalTokensUsed.toLocaleString()}`);
    console.log(`  成果物: scrum/sprint${String(currentSprintNum).padStart(3, "0")}/`);

  } catch (err) {
    console.error(`\n❌ エラー: ${err.message}`);
    console.error(err.stack);
  } finally {
    rl.close();
  }
}

/* ═══ CLI Interface ═══ */
const args = process.argv.slice(2);
const command = args[0] || "sprint";

switch (command) {
  case "sprint":
    executeFullSprint();
    break;
  case "daily": {
    const sprintId = args[1] || `sp-${scrumFiles.getCurrentSprintNum()}`;
    const day = parseInt(args[2] || "1");
    const sprintName = `sprint${String(scrumFiles.getCurrentSprintNum()).padStart(3, "0")}`;
    scrumFiles.ensureScrumDirs();
    phaseOneDay(day, sprintId, sprintName).then(() => { logTokens(); rl.close(); });
    break;
  }
  case "retro": {
    const sprintId = args[1] || `sp-${scrumFiles.getCurrentSprintNum()}`;
    const sprintName = `sprint${String(scrumFiles.getCurrentSprintNum()).padStart(3, "0")}`;
    scrumFiles.ensureScrumDirs();
    phaseRetrospective(sprintId, sprintName).then(() => { logTokens(); rl.close(); });
    break;
  }
  case "review": {
    const sprintId = args[1] || `sp-${scrumFiles.getCurrentSprintNum()}`;
    const sprintName = `sprint${String(scrumFiles.getCurrentSprintNum()).padStart(3, "0")}`;
    scrumFiles.ensureScrumDirs();
    phaseSprintReview(sprintId, sprintName).then(() => { logTokens(); rl.close(); });
    break;
  }
  default:
    console.log(`
Usage:
  node orchestrator.js sprint           # フルスプリント実行
  node orchestrator.js daily [sprintId] [dayNum]  # デイリー1日分
  node orchestrator.js review [sprintId]           # スプリントレビュー
  node orchestrator.js retro [sprintId]            # ふりかえり

Environment:
  ANTHROPIC_API_KEY   Claude APIキー（必須）
  DASHBOARD_API       ダッシュボードURL（default: http://localhost:3001）
  SPRINT_DAYS         スプリント日数（default: 3）
  TOKEN_BUDGET        トークン予算（default: 2000000）
    `);
    rl.close();
}
