# LLM スクラムチーム クイックスタート

## 前提条件

- Node.js 18+
- Anthropic API キー（Claude API）
- ダッシュボードバックエンドが起動済み

## セットアップ

### 1. ダッシュボードを起動

```bash
cd backend
npm install
npm start
# → http://localhost:3001 で起動
```

### 2. Orchestratorを準備

```bash
cd orchestrator
# 依存関係なし（Node.js標準のみ使用）

# APIキーを設定
export ANTHROPIC_API_KEY="sk-ant-xxxxx"
```

### 3. フルスプリントを実行

```bash
node orchestrator.js sprint
```

対話形式で開始:
1. 「何を作りたいですか？」と聞かれる → 簡単に指示
2. 佐藤（Customer）が要件を詳細化、不明点を質問してくる
3. 以降は自動で進行:
   - リファインメント → プランニング → 開発(N日) → レビュー → ふりかえり
4. レビュー時に佐藤が成果を報告、承認を求める
5. 完了

### 個別イベントの実行

```bash
# デイリー1日分だけ実行
node orchestrator.js daily sp-1 2

# スプリントレビューだけ
node orchestrator.js review sp-1

# ふりかえりだけ
node orchestrator.js retro sp-1
```

### 環境変数

| 変数 | 説明 | デフォルト |
|------|------|----------|
| `ANTHROPIC_API_KEY` | Claude APIキー | （必須） |
| `DASHBOARD_API` | ダッシュボードURL | `http://localhost:3001` |
| `SPRINT_DAYS` | スプリント日数 | `3` |
| `TOKEN_BUDGET` | トークン予算 | `2000000` |

## Dry Run（APIキーなしで動作確認）

APIキーを設定せずに実行すると、dry-runモードで動作します。
Claude APIは呼び出されず、各エージェントのターンが `[DRY RUN]` と表示されます。

```bash
# APIキーなしで起動
unset ANTHROPIC_API_KEY
node orchestrator.js sprint
```

これでフローの流れとファイル生成を確認できます。

## 生成される成果物

```
scrum/
├── order/order001.md           # 佐藤が作成した要件書
├── product_goal.md             # プロダクトゴール
├── product_backlog.csv         # PBI一覧
├── definition_of_done.md       # 完成の定義
├── velocity.csv                # ベロシティ記録
└── sprint001/
    ├── sprint_planning.md      # プランニング議事録
    ├── sprint_backlog.md       # スプリントバックログ
    ├── daily_scrum.md          # デイリースクラム記録
    ├── sprint_review.md        # レビュー記録
    └── sprint_retrospective.md # ふりかえり記録
```

同時にダッシュボードAPI上でも:
- タスクがカンバンボードに表示
- スプリントとバーンダウンチャートが更新
- ナレッジに知見が蓄積
- ふりかえりにKPTが記録

## トラブルシューティング

**Q: ダッシュボードAPIに接続できない**
→ `npm start` でバックエンドを起動しているか確認。`DASHBOARD_API` が正しいか確認。

**Q: トークン予算を超過した**
→ `TOKEN_BUDGET` を増やすか、`SPRINT_DAYS` を減らす。

**Q: エージェントが同じ操作を繰り返す**
→ 最大ツールループ数（10回）で自動停止。再実行するか、個別イベントで部分実行。
