const fs = require("fs");
const path = require("path");

const SCRUM_DIR = path.join(__dirname, "..", "scrum");
const PROJECT_DIR = path.join(__dirname, "..", "project_output");

/** Ensure scrum directory structure exists */
function ensureScrumDirs() {
  const dirs = [
    SCRUM_DIR,
    path.join(SCRUM_DIR, "order"),
  ];
  for (const d of dirs) {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  }

  // Seed files if they don't exist
  const seeds = {
    "product_goal.md": "# プロダクトゴール\n\n（未設定）\n",
    "definition_of_done.md": "# 完成の定義 (Definition of Done)\n\n- [ ] コードがビルドエラーなくビルドできる\n- [ ] 単体テストが作成され、全て通過している\n- [ ] Lint/Formatエラーがない\n- [ ] コードレビューが完了している\n- [ ] 受入条件が全て満たされている\n- [ ] ナレッジに記録すべき知見があれば記録済み\n",
    "product_backlog.csv": "ID,Title,Description,StoryPoints,Priority,Status,Epic,AcceptanceCriteria,SprintId\n",
    "impediment_log.csv": "ID,Date,Description,Reporter,Status,Resolution\n",
    "velocity.csv": "SprintId,SprintName,PlannedSP,CompletedSP,StartDate,EndDate,TokensUsed\n",
  };

  for (const [file, content] of Object.entries(seeds)) {
    const fp = path.join(SCRUM_DIR, file);
    if (!fs.existsSync(fp)) fs.writeFileSync(fp, content, "utf8");
  }
}

/** Create sprint directory with template files */
function createSprintDir(sprintNum) {
  const name = `sprint${String(sprintNum).padStart(3, "0")}`;
  const dir = path.join(SCRUM_DIR, name);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const templates = {
    "sprint_planning.md": `# スプリントプランニング — ${name}\n\n## 日時\n\n## スプリントゴール\n\n## 選定PBI\n\n## タスク分解\n\n## キャパシティ\n\n## 合意事項\n`,
    "sprint_backlog.md": `# スプリントバックログ — ${name}\n\n## スプリントゴール\n\n## PBI一覧\n\n| ID | Title | SP | Status |\n|---|---|---|---|\n\n## タスク一覧\n\n| TaskID | PBI | Title | Assignee | Status |\n|---|---|---|---|---|\n`,
    "daily_scrum.md": `# デイリースクラム記録 — ${name}\n\n`,
    "sprint_review.md": `# スプリントレビュー — ${name}\n\n## 完了PBI\n\n## 受入判定\n\n## フィードバック\n`,
    "sprint_retrospective.md": `# スプリントレトロスペクティブ — ${name}\n\n## Keep\n\n## Problem\n\n## Try\n\n## アクションアイテム\n`,
  };

  for (const [file, content] of Object.entries(templates)) {
    const fp = path.join(dir, file);
    if (!fs.existsSync(fp)) fs.writeFileSync(fp, content, "utf8");
  }

  return dir;
}

/** Read a file, return content or null */
function readFile(relativePath) {
  const fp = path.join(SCRUM_DIR, relativePath);
  if (!fs.existsSync(fp)) return null;
  return fs.readFileSync(fp, "utf8");
}

/** Write a file (creates dirs if needed) */
function writeFile(relativePath, content) {
  const fp = path.join(SCRUM_DIR, relativePath);
  const dir = path.dirname(fp);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(fp, content, "utf8");
  return fp;
}

/** Append to a file */
function appendFile(relativePath, content) {
  const fp = path.join(SCRUM_DIR, relativePath);
  if (!fs.existsSync(fp)) return writeFile(relativePath, content);
  fs.appendFileSync(fp, content, "utf8");
  return fp;
}

/** Parse CSV to array of objects */
function parseCSV(csvContent) {
  const lines = csvContent.trim().split("\n");
  if (lines.length < 2) return [];
  const headers = lines[0].split(",").map(h => h.trim());
  return lines.slice(1).filter(l => l.trim()).map(line => {
    const vals = line.split(",").map(v => v.trim());
    const obj = {};
    headers.forEach((h, i) => { obj[h] = vals[i] || ""; });
    return obj;
  });
}

/** Convert array of objects to CSV string */
function toCSV(headers, rows) {
  const lines = [headers.join(",")];
  for (const row of rows) {
    lines.push(headers.map(h => String(row[h] || "").replace(/,/g, ";")).join(","));
  }
  return lines.join("\n") + "\n";
}

/** Get the next order number */
function getNextOrderNum() {
  const orderDir = path.join(SCRUM_DIR, "order");
  if (!fs.existsSync(orderDir)) return 1;
  const files = fs.readdirSync(orderDir).filter(f => f.match(/^order\d+\.md$/));
  if (files.length === 0) return 1;
  const nums = files.map(f => parseInt(f.match(/\d+/)[0]));
  return Math.max(...nums) + 1;
}

/** Get the current sprint number */
function getCurrentSprintNum() {
  const dirs = fs.readdirSync(SCRUM_DIR).filter(d => d.match(/^sprint\d+$/));
  if (dirs.length === 0) return 0;
  const nums = dirs.map(d => parseInt(d.match(/\d+/)[0]));
  return Math.max(...nums);
}

/** Read velocity CSV */
function readVelocity() {
  const content = readFile("velocity.csv");
  if (!content) return [];
  return parseCSV(content);
}

/** Append velocity record */
function appendVelocity(record) {
  const headers = ["SprintId", "SprintName", "PlannedSP", "CompletedSP", "StartDate", "EndDate", "TokensUsed"];
  const line = headers.map(h => String(record[h] || "")).join(",");
  appendFile("velocity.csv", line + "\n");
}

module.exports = {
  SCRUM_DIR,
  PROJECT_DIR,
  ensureScrumDirs,
  createSprintDir,
  readFile,
  writeFile,
  appendFile,
  parseCSV,
  toCSV,
  getNextOrderNum,
  getCurrentSprintNum,
  readVelocity,
  appendVelocity,
};
