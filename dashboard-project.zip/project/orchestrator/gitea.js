/**
 * Gitea Integration Module
 *
 * エージェントがGitea APIを通じて:
 * - ブランチ作成
 * - ファイル作成/更新/削除
 * - コミット
 * - Pull Request作成
 * - PRレビューコメント
 *
 * 環境変数:
 *   GITEA_URL      Gitea URL (例: http://localhost:3000)
 *   GITEA_TOKEN    APIトークン
 *   GITEA_OWNER    リポジトリオーナー
 *   GITEA_REPO     リポジトリ名
 */

const GITEA_URL = process.env.GITEA_URL || "http://localhost:3000";
const GITEA_TOKEN = process.env.GITEA_TOKEN || "";
const GITEA_OWNER = process.env.GITEA_OWNER || "llm-team";
const GITEA_REPO = process.env.GITEA_REPO || "project";
const DEFAULT_BRANCH = process.env.GITEA_DEFAULT_BRANCH || "main";

async function giteaFetch(path, opts = {}) {
  const url = `${GITEA_URL}/api/v1${path}`;
  const res = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
      "Authorization": `token ${GITEA_TOKEN}`,
      ...opts.headers,
    },
    ...opts,
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Gitea API ${res.status}: ${text}`);
  }
  if (res.status === 204) return null;
  return res.json();
}

const gitea = {
  /* ── Repository Info ── */

  /** リポジトリ情報を取得 */
  async getRepo() {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}`);
  },

  /* ── Branches ── */

  /** ブランチ一覧を取得 */
  async listBranches() {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/branches`);
  },

  /** ブランチを作成 */
  async createBranch(branchName, fromBranch = DEFAULT_BRANCH) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/branches`, {
      method: "POST",
      body: JSON.stringify({
        new_branch_name: branchName,
        old_branch_name: fromBranch,
      }),
    });
  },

  /** ブランチを削除 */
  async deleteBranch(branchName) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/branches/${branchName}`, {
      method: "DELETE",
    });
  },

  /* ── File Operations ── */

  /** ファイルの内容を取得 */
  async getFile(filePath, ref = DEFAULT_BRANCH) {
    try {
      const data = await giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/contents/${filePath}?ref=${ref}`);
      return {
        content: Buffer.from(data.content, "base64").toString("utf8"),
        sha: data.sha,
        path: data.path,
      };
    } catch {
      return null;
    }
  },

  /** ファイルを作成（新規） */
  async createFile(filePath, content, message, branch = DEFAULT_BRANCH) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/contents/${filePath}`, {
      method: "POST",
      body: JSON.stringify({
        content: Buffer.from(content).toString("base64"),
        message: message || `Add ${filePath}`,
        branch,
      }),
    });
  },

  /** ファイルを更新 */
  async updateFile(filePath, content, message, sha, branch = DEFAULT_BRANCH) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/contents/${filePath}`, {
      method: "PUT",
      body: JSON.stringify({
        content: Buffer.from(content).toString("base64"),
        message: message || `Update ${filePath}`,
        sha,
        branch,
      }),
    });
  },

  /** ファイルを作成または更新（自動判定） */
  async upsertFile(filePath, content, message, branch = DEFAULT_BRANCH) {
    const existing = await gitea.getFile(filePath, branch);
    if (existing) {
      return gitea.updateFile(filePath, content, message, existing.sha, branch);
    } else {
      return gitea.createFile(filePath, content, message, branch);
    }
  },

  /** ファイルを削除 */
  async deleteFile(filePath, message, sha, branch = DEFAULT_BRANCH) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/contents/${filePath}`, {
      method: "DELETE",
      body: JSON.stringify({
        message: message || `Delete ${filePath}`,
        sha,
        branch,
      }),
    });
  },

  /** ディレクトリの内容一覧を取得 */
  async listDir(dirPath = "", ref = DEFAULT_BRANCH) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/contents/${dirPath}?ref=${ref}`);
  },

  /* ── Pull Requests ── */

  /** PR一覧を取得 */
  async listPRs(state = "open") {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls?state=${state}`);
  },

  /** PRを作成 */
  async createPR(title, body, headBranch, baseBranch = DEFAULT_BRANCH, assignees = []) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls`, {
      method: "POST",
      body: JSON.stringify({
        title,
        body: body || "",
        head: headBranch,
        base: baseBranch,
        assignees,
      }),
    });
  },

  /** PRの詳細を取得 */
  async getPR(prNumber) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls/${prNumber}`);
  },

  /** PRのdiffを取得 */
  async getPRDiff(prNumber) {
    const res = await fetch(`${GITEA_URL}/api/v1/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls/${prNumber}.diff`, {
      headers: { "Authorization": `token ${GITEA_TOKEN}` },
    });
    return res.text();
  },

  /** PRにレビューコメントを追加 */
  async reviewPR(prNumber, body, event = "COMMENT") {
    // event: APPROVE, REQUEST_CHANGES, COMMENT
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls/${prNumber}/reviews`, {
      method: "POST",
      body: JSON.stringify({ body, event }),
    });
  },

  /** PRをマージ */
  async mergePR(prNumber, mergeStyle = "merge") {
    // mergeStyle: merge, rebase, squash
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/pulls/${prNumber}/merge`, {
      method: "POST",
      body: JSON.stringify({
        Do: mergeStyle,
        merge_message_field: "",
      }),
    });
  },

  /** PRにコメント */
  async commentPR(prNumber, body) {
    return giteaFetch(`/repos/${GITEA_OWNER}/${GITEA_REPO}/issues/${prNumber}/comments`, {
      method: "POST",
      body: JSON.stringify({ body }),
    });
  },

  /* ── Utility ── */

  /** タスクIDからブランチ名を生成 */
  taskBranch(taskId) {
    return `feature/${taskId.toLowerCase()}`;
  },

  /** PRテンプレートを生成 */
  prBody(taskId, description, changes) {
    return `## 関連タスク
- ${taskId}

## 変更内容
${description}

## 変更ファイル
${(changes || []).map(f => `- \`${f}\``).join("\n")}

## チェックリスト
- [ ] テストが追加/更新されている
- [ ] ビルドが通る
- [ ] 受入条件を満たしている
`;
  },
};

module.exports = { gitea, GITEA_URL, GITEA_OWNER, GITEA_REPO, DEFAULT_BRANCH };
