#!/usr/bin/env node

/**
 * Dashboard MCP Server
 *
 * Exposes all Dashboard REST API endpoints as MCP (Model Context Protocol) tools.
 * Supports stdio transport (for Claude Code, Copilot CLI) and SSE transport (for web).
 *
 * Usage:
 *   stdio:  node mcp-server.js
 *   SSE:    node mcp-server.js --sse --port 3002
 *
 * Configure in Claude Code / Copilot:
 *   { "mcpServers": { "dashboard": { "command": "node", "args": ["mcp-server.js"] } } }
 */

const http = require("http");

const API_BASE = process.env.DASHBOARD_API || "http://localhost:3001";
const args = process.argv.slice(2);
const isSSE = args.includes("--sse");
const ssePort = parseInt(args[args.indexOf("--port") + 1]) || 3002;

/* ═══ MCP Tool Definitions ═══ */
const TOOLS = [
  // ── Tasks ──
  { name: "list_tasks", description: "全タスクを取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/tasks" },
  { name: "create_task", description: "新しいタスクを作成する", inputSchema: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, desc: { type: "string" }, priority: { type: "string", enum: ["high", "medium", "low"] }, column: { type: "string", enum: ["backlog", "todo", "inprogress", "review", "done"] }, assignees: { type: "array", items: { type: "string" } }, tags: { type: "array", items: { type: "string" } }, created: { type: "string" }, epicId: { type: "string" }, projectId: { type: "string" } }, required: ["id", "title"] }, method: "POST", path: "/api/tasks" },
  { name: "update_task", description: "タスクを更新する", inputSchema: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, desc: { type: "string" }, priority: { type: "string" }, column: { type: "string" }, assignees: { type: "array", items: { type: "string" } }, tags: { type: "array", items: { type: "string" } }, epicId: { type: "string" } }, required: ["id"] }, method: "PUT", pathTemplate: "/api/tasks/{id}" },
  { name: "move_task", description: "タスクのカンバンステータスを変更する（ドラッグ&ドロップ）", inputSchema: { type: "object", properties: { id: { type: "string" }, column: { type: "string", enum: ["backlog", "todo", "inprogress", "review", "done"] } }, required: ["id", "column"] }, method: "PATCH", pathTemplate: "/api/tasks/{id}/column" },
  { name: "delete_task", description: "タスクを削除する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "DELETE", pathTemplate: "/api/tasks/{id}" },
  { name: "reorder_tasks", description: "バックログの優先度順序を一括更新する", inputSchema: { type: "object", properties: { orders: { type: "array", items: { type: "object", properties: { id: { type: "string" }, priorityOrder: { type: "integer" } } } } }, required: ["orders"] }, method: "PUT", path: "/api/tasks/reorder/bulk" },
  { name: "set_task_epic", description: "タスクをエピックに割り当てる", inputSchema: { type: "object", properties: { id: { type: "string" }, epicId: { type: "string" } }, required: ["id"] }, method: "PATCH", pathTemplate: "/api/tasks/{id}/epic" },

  // ── Sprints ──
  { name: "list_sprints", description: "全スプリントを取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/sprints" },
  { name: "create_sprint", description: "新しいスプリントを作成する", inputSchema: { type: "object", properties: { id: { type: "string" }, name: { type: "string" }, goal: { type: "string" }, startDate: { type: "string" }, endDate: { type: "string" }, status: { type: "string", enum: ["planning", "active", "completed"] }, projectId: { type: "string" } }, required: ["id", "name", "startDate", "endDate"] }, method: "POST", path: "/api/sprints" },
  { name: "update_sprint", description: "スプリントを更新する（ステータス変更含む）", inputSchema: { type: "object", properties: { id: { type: "string" }, name: { type: "string" }, goal: { type: "string" }, startDate: { type: "string" }, endDate: { type: "string" }, status: { type: "string" } }, required: ["id"] }, method: "PUT", pathTemplate: "/api/sprints/{id}" },
  { name: "delete_sprint", description: "スプリントを削除する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "DELETE", pathTemplate: "/api/sprints/{id}" },
  { name: "add_task_to_sprint", description: "タスクをスプリントに割り当てる", inputSchema: { type: "object", properties: { sprintId: { type: "string" }, taskId: { type: "string" }, points: { type: "integer" } }, required: ["sprintId", "taskId"] }, method: "POST", pathTemplate: "/api/sprints/{sprintId}/tasks" },
  { name: "remove_task_from_sprint", description: "タスクをスプリントから除外する", inputSchema: { type: "object", properties: { sprintId: { type: "string" }, taskId: { type: "string" } }, required: ["sprintId", "taskId"] }, method: "DELETE", pathTemplate: "/api/sprints/{sprintId}/tasks/{taskId}" },
  { name: "update_story_points", description: "スプリント内タスクのストーリーポイントを更新する", inputSchema: { type: "object", properties: { sprintId: { type: "string" }, taskId: { type: "string" }, points: { type: "integer" } }, required: ["sprintId", "taskId", "points"] }, method: "PUT", pathTemplate: "/api/sprints/{sprintId}/tasks/{taskId}/points" },
  { name: "get_burndown", description: "スプリントのバーンダウンチャートデータを取得する", inputSchema: { type: "object", properties: { sprintId: { type: "string" } }, required: ["sprintId"] }, method: "GET", pathTemplate: "/api/sprints/{sprintId}/burndown" },

  // ── Epics ──
  { name: "list_epics", description: "全エピックを取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/epics" },
  { name: "create_epic", description: "エピックを作成する", inputSchema: { type: "object", properties: { id: { type: "string" }, name: { type: "string" }, color: { type: "string" }, description: { type: "string" }, projectId: { type: "string" } }, required: ["id", "name"] }, method: "POST", path: "/api/epics" },
  { name: "delete_epic", description: "エピックを削除する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "DELETE", pathTemplate: "/api/epics/{id}" },

  // ── Knowledge ──
  { name: "list_knowledge", description: "ナレッジ記事一覧を取得する（本文除外で軽量）", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/knowledge" },
  { name: "get_knowledge_article", description: "ナレッジ記事の全文を取得する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "GET", pathTemplate: "/api/knowledge/{id}" },
  { name: "create_knowledge", description: "ナレッジ記事を作成する", inputSchema: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, category: { type: "string", enum: ["frontend", "backend", "infra", "design", "pm", "security", "general"] }, author: { type: "string" }, status: { type: "string", enum: ["draft", "reviewed", "approved"] }, summary: { type: "string" }, body: { type: "string" }, tags: { type: "array", items: { type: "string" } }, related: { type: "array", items: { type: "string" } } }, required: ["id", "title"] }, method: "POST", path: "/api/knowledge" },
  { name: "update_knowledge", description: "ナレッジ記事を更新する", inputSchema: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, category: { type: "string" }, author: { type: "string" }, status: { type: "string" }, summary: { type: "string" }, body: { type: "string" }, tags: { type: "array", items: { type: "string" } }, related: { type: "array", items: { type: "string" } } }, required: ["id"] }, method: "PUT", pathTemplate: "/api/knowledge/{id}" },
  { name: "delete_knowledge", description: "ナレッジ記事を削除する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "DELETE", pathTemplate: "/api/knowledge/{id}" },
  { name: "search_knowledge", description: "ナレッジを検索する（RAG用）", inputSchema: { type: "object", properties: { q: { type: "string" }, category: { type: "string" }, tag: { type: "string" }, status: { type: "string" } }, required: [] }, method: "GET", path: "/api/knowledge/search/query" },
  { name: "export_knowledge_rag", description: "承認済みナレッジをRAG用フォーマットでエクスポートする", inputSchema: { type: "object", properties: { status: { type: "string" } }, required: [] }, method: "GET", path: "/api/knowledge/export/rag" },

  // ── Retrospectives ──
  { name: "list_retros", description: "ふりかえり一覧を取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/retros" },
  { name: "create_retro", description: "ふりかえりを作成する（KPTアイテム含む）", inputSchema: { type: "object", properties: { id: { type: "string" }, title: { type: "string" }, sprintId: { type: "string" }, date: { type: "string" }, projectId: { type: "string" }, items: { type: "array", items: { type: "object", properties: { type: { type: "string", enum: ["keep", "problem", "try"] }, content: { type: "string" }, votes: { type: "integer" }, action: { type: "string" } } } } }, required: ["id", "title"] }, method: "POST", path: "/api/retros" },
  { name: "update_retro", description: "ふりかえりを更新する", inputSchema: { type: "object", properties: { id: { type: "string" }, items: { type: "array" } }, required: ["id"] }, method: "PUT", pathTemplate: "/api/retros/{id}" },

  // ── Goals ──
  { name: "list_org_goals", description: "組織目標一覧を取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/goals/org" },
  { name: "list_personal_goals", description: "個人目標一覧を取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/goals/personal" },

  // ── Members ──
  { name: "list_members", description: "メンバー一覧を取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/members" },

  // ── Projects ──
  { name: "list_projects", description: "プロジェクト一覧を取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/projects" },
  { name: "create_project", description: "新しいプロジェクトを作成する", inputSchema: { type: "object", properties: { id: { type: "string" }, name: { type: "string" }, color: { type: "string" }, description: { type: "string" } }, required: ["id", "name"] }, method: "POST", path: "/api/projects" },
  { name: "delete_project", description: "プロジェクトを削除する", inputSchema: { type: "object", properties: { id: { type: "string" } }, required: ["id"] }, method: "DELETE", pathTemplate: "/api/projects/{id}" },

  // ── Token Usage ──
  { name: "log_token_usage", description: "トークン使用量を記録する", inputSchema: { type: "object", properties: { sprintId: { type: "string" }, agentId: { type: "string" }, action: { type: "string" }, inputTokens: { type: "integer" }, outputTokens: { type: "integer" }, toolCalls: { type: "integer" } }, required: ["sprintId", "agentId"] }, method: "POST", path: "/api/tokens/log" },
  { name: "get_sprint_token_usage", description: "スプリントのトークン消費量を取得する", inputSchema: { type: "object", properties: { sprintId: { type: "string" } }, required: ["sprintId"] }, method: "GET", pathTemplate: "/api/tokens/sprint/{sprintId}" },
  { name: "get_token_usage_summary", description: "全スプリントのトークン消費サマリーを取得する", inputSchema: { type: "object", properties: {}, required: [] }, method: "GET", path: "/api/tokens/summary" },
];

/* ═══ Execute Tool ═══ */
async function executeTool(name, args) {
  const tool = TOOLS.find(t => t.name === name);
  if (!tool) throw new Error(`Unknown tool: ${name}`);

  // Build URL
  let urlPath = tool.path || tool.pathTemplate;
  if (tool.pathTemplate) {
    for (const [key, val] of Object.entries(args)) {
      urlPath = urlPath.replace(`{${key}}`, val);
    }
  }

  // Query params for GET
  const url = new URL(`${API_BASE}${urlPath}`);
  if (tool.method === "GET" && args) {
    for (const [k, v] of Object.entries(args)) {
      if (v !== undefined && v !== null && !urlPath.includes(v)) {
        url.searchParams.set(k, String(v));
      }
    }
  }

  const opts = { method: tool.method, headers: { "Content-Type": "application/json" } };
  if (["POST", "PUT", "PATCH"].includes(tool.method)) {
    // Remove path params from body
    const body = { ...args };
    if (tool.pathTemplate) {
      const pathParams = tool.pathTemplate.match(/\{(\w+)\}/g)?.map(p => p.slice(1, -1)) || [];
      for (const p of pathParams) delete body[p];
    }
    opts.body = JSON.stringify(body);
  }

  const res = await fetch(url.toString(), opts);
  const data = await res.json();
  return JSON.stringify(data, null, 2);
}

/* ═══ JSON-RPC Handler ═══ */
async function handleRPC(request) {
  const { id, method, params } = request;

  switch (method) {
    case "initialize":
      return { id, result: {
        protocolVersion: "2024-11-05",
        capabilities: { tools: {} },
        serverInfo: { name: "dashboard-mcp", version: "1.0.0" },
      }};

    case "notifications/initialized":
      return null; // no response needed

    case "tools/list":
      return { id, result: {
        tools: TOOLS.map(t => ({
          name: t.name,
          description: t.description,
          inputSchema: t.inputSchema,
        })),
      }};

    case "tools/call": {
      const { name, arguments: args } = params;
      try {
        const result = await executeTool(name, args || {});
        return { id, result: { content: [{ type: "text", text: result }] } };
      } catch (e) {
        return { id, result: { content: [{ type: "text", text: `Error: ${e.message}` }], isError: true } };
      }
    }

    case "ping":
      return { id, result: {} };

    default:
      return { id, error: { code: -32601, message: `Method not found: ${method}` } };
  }
}

/* ═══ Stdio Transport ═══ */
function startStdio() {
  let buffer = "";

  process.stdin.setEncoding("utf8");
  process.stdin.on("data", async (chunk) => {
    buffer += chunk;
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const request = JSON.parse(line);
        const response = await handleRPC(request);
        if (response) {
          process.stdout.write(JSON.stringify({ jsonrpc: "2.0", ...response }) + "\n");
        }
      } catch (e) {
        process.stderr.write(`MCP Parse error: ${e.message}\n`);
      }
    }
  });

  process.stderr.write(`🔌 Dashboard MCP Server (stdio) ready — API: ${API_BASE}\n`);
  process.stderr.write(`📋 ${TOOLS.length} tools available\n`);
}

/* ═══ SSE Transport ═══ */
function startSSE() {
  const server = http.createServer(async (req, res) => {
    // CORS
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }

    if (req.url === "/sse" && req.method === "GET") {
      // SSE endpoint
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", "Connection": "keep-alive" });

      const sessionId = `session-${Date.now()}`;
      res.write(`data: ${JSON.stringify({ type: "endpoint", url: `/message?sessionId=${sessionId}` })}\n\n`);

      req.on("close", () => { /* cleanup */ });

    } else if (req.url?.startsWith("/message") && req.method === "POST") {
      // Message endpoint
      let body = "";
      req.on("data", c => body += c);
      req.on("end", async () => {
        try {
          const request = JSON.parse(body);
          const response = await handleRPC(request);
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ jsonrpc: "2.0", ...response }));
        } catch (e) {
          res.writeHead(400, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ error: e.message }));
        }
      });

    } else if (req.url === "/health") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ status: "ok", tools: TOOLS.length }));

    } else {
      res.writeHead(404);
      res.end("Not found");
    }
  });

  server.listen(ssePort, () => {
    console.log(`🔌 Dashboard MCP Server (SSE) running on http://localhost:${ssePort}`);
    console.log(`   SSE endpoint: http://localhost:${ssePort}/sse`);
    console.log(`   API target: ${API_BASE}`);
    console.log(`   📋 ${TOOLS.length} tools available`);
  });
}

/* ═══ Start ═══ */
if (isSSE) {
  startSSE();
} else {
  startStdio();
}
