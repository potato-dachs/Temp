const express = require("express");
const cors = require("cors");
const path = require("path");
const { initDB } = require("./db");

const app = express();
const PORT = process.env.PORT || 3001;

// Initialize database
const db = initDB();

// Middleware
app.use(cors());
app.use(express.json());

// API routes
app.use("/api/members", require("./routes/members")(db));
app.use("/api/tasks", require("./routes/tasks")(db));
app.use("/api/goals", require("./routes/goals")(db));

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Serve frontend static files in production
const frontendBuild = path.join(__dirname, "../frontend/build");
app.use(express.static(frontendBuild));
app.get("*", (req, res) => {
  res.sendFile(path.join(frontendBuild, "index.html"));
});

app.listen(PORT, () => {
  console.log(`✅ Dashboard API running on http://localhost:${PORT}`);
  console.log(`📂 Database: ${path.join(__dirname, "dashboard.db")}`);
});
