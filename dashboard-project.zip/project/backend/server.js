const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const { initDB } = require("./db");

const app = express();
const PORT = process.env.PORT || 3001;

// Initialize database
const db = initDB();

// Middleware
app.use(cors());
app.use(express.json({ limit: "50mb" }));

// API routes
app.use("/api/members", require("./routes/members")(db));
app.use("/api/tasks", require("./routes/tasks")(db));
app.use("/api/goals", require("./routes/goals")(db));
app.use("/api/backup", require("./routes/backup")(db));
app.use("/api/knowledge", require("./routes/knowledge")(db));
app.use("/api/sprints", require("./routes/sprints")(db));
app.use("/api/epics", require("./routes/epics")(db));
app.use("/api/retros", require("./routes/retros")(db));
app.use("/api/tokens", require("./routes/tokens")(db));
app.use("/api/ai", require("./routes/ai")(db));
app.use("/api/ai/agent", require("./routes/ai-agent")(db));
app.use("/api/projects", require("./routes/projects")(db));

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// ── Auto-backup: every 6 hours ──
const BACKUP_DIR = path.join(__dirname, "backups");
const AUTO_BACKUP_INTERVAL = 6 * 60 * 60 * 1000; // 6 hours
const MAX_AUTO_BACKUPS = 20;

function autoBackup() {
  try {
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

    const members = db.prepare("SELECT * FROM members ORDER BY id").all();
    const tasks = db.prepare("SELECT * FROM tasks ORDER BY created_at").all();
    const taskAssignees = db.prepare("SELECT * FROM task_assignees").all();
    const taskTags = db.prepare("SELECT * FROM task_tags").all();
    const orgGoals = db.prepare("SELECT * FROM org_goals ORDER BY created_at").all();
    const personalGoals = db.prepare("SELECT * FROM personal_goals ORDER BY created_at").all();
    const keyResults = db.prepare("SELECT * FROM personal_goal_key_results ORDER BY id").all();

    const backup = {
      version: "1.0",
      type: "auto",
      exported_at: new Date().toISOString(),
      data: { members, tasks, taskAssignees, taskTags, orgGoals, personalGoals, keyResults },
    };

    const filename = `auto-backup-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    fs.writeFileSync(path.join(BACKUP_DIR, filename), JSON.stringify(backup, null, 2), "utf8");
    console.log(`📦 Auto-backup saved: ${filename}`);

    // Prune old auto-backups
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith("auto-backup-") && f.endsWith(".json"))
      .sort()
      .reverse();
    for (const old of files.slice(MAX_AUTO_BACKUPS)) {
      fs.unlinkSync(path.join(BACKUP_DIR, old));
      console.log(`🗑️  Pruned old backup: ${old}`);
    }
  } catch (e) {
    console.error("Auto-backup failed:", e.message);
  }
}

// Run first auto-backup on start, then every interval
autoBackup();
setInterval(autoBackup, AUTO_BACKUP_INTERVAL);

// Serve frontend static files in production
const frontendBuild = path.join(__dirname, "../frontend/build");
app.use(express.static(frontendBuild));
app.get("*", (req, res) => {
  res.sendFile(path.join(frontendBuild, "index.html"));
});

app.listen(PORT, () => {
  console.log(`✅ Dashboard API running on http://localhost:${PORT}`);
  console.log(`📂 Database: ${path.join(__dirname, "dashboard.db")}`);
});
