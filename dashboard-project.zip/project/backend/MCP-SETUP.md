# Dashboard MCP Server セットアップガイド

ダッシュボードの全機能をMCPツールとしてAIアシスタントから利用できます。

## 提供ツール（36種）

| カテゴリ | ツール数 | 主な操作 |
|---------|---------|---------|
| タスク管理 | 7 | CRUD、カンバン移動、優先度並替、エピック割当 |
| スプリント | 8 | 作成、タスク割当、ポイント更新、バーンダウン取得 |
| エピック | 3 | CRUD |
| ナレッジ | 7 | CRUD、検索、RAGエクスポート |
| ふりかえり | 3 | 作成、KPT更新 |
| 目標 | 2 | 組織目標、個人目標の取得 |
| メンバー | 1 | 一覧取得 |

## 起動方法

### 前提: ダッシュボードバックエンドが起動済み
```bash
cd backend && npm start  # → http://localhost:3001
```

### Stdio モード（Claude Code / Copilot CLI 向け）
```bash
node backend/mcp-server.js
```

### SSE モード（Web クライアント向け）
```bash
node backend/mcp-server.js --sse --port 3002
# → http://localhost:3002/sse
```

## 接続設定

### Claude Code（claude_desktop_config.json）
```json
{
  "mcpServers": {
    "dashboard": {
      "command": "node",
      "args": ["/path/to/project/backend/mcp-server.js"],
      "env": {
        "DASHBOARD_API": "http://localhost:3001"
      }
    }
  }
}
```

### GitHub Copilot（.github/copilot/mcp.json）
```json
{
  "servers": {
    "dashboard": {
      "type": "stdio",
      "command": "node",
      "args": ["backend/mcp-server.js"],
      "env": {
        "DASHBOARD_API": "http://localhost:3001"
      }
    }
  }
}
```

### SSE接続（Webアプリケーション等）
```json
{
  "servers": {
    "dashboard": {
      "type": "sse",
      "url": "http://localhost:3002/sse"
    }
  }
}
```

## 使用例

Claude Code や Copilot から自然言語で:

```
「バックログの一覧を見せて」
→ list_tasks ツールが呼ばれる

「DASH-10をレビュー中に移動して」
→ move_task { id: "DASH-10", column: "review" }

「Sprint 3を作成して、5/19から5/30まで」
→ create_sprint { id: "sp-3", name: "Sprint 3", startDate: "2026-05-19", endDate: "2026-05-30" }

「Reactのベストプラクティスに関するナレッジを検索」
→ search_knowledge { q: "React ベストプラクティス", status: "approved" }

「ふりかえりでKeep: デイリーが定着した、Problem: 見積もり精度が低い を追加」
→ create_retro / update_retro
```

## 環境変数

| 変数 | 説明 | デフォルト |
|------|------|----------|
| `DASHBOARD_API` | ダッシュボードバックエンドURL | `http://localhost:3001` |
