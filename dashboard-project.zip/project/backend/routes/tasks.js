const express = require("express");
const router = express.Router();

module.exports = function (db) {
  // ── Auto-migrate: add due_date, comments, activity_log tables ──
  try { db.exec("ALTER TABLE tasks ADD COLUMN due_date TEXT DEFAULT ''"); } catch {}

  db.exec(`
    CREATE TABLE IF NOT EXISTS task_comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id TEXT NOT NULL,
      author TEXT NOT NULL,
      content TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS task_activity (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id TEXT NOT NULL,
      actor TEXT NOT NULL,
      action TEXT NOT NULL,
      detail TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    );
  `);

  // ── Helpers ──
  function getFullTask(taskId) {
    const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(taskId);
    if (!task) return null;
    const assignees = db.prepare("SELECT member_id FROM task_assignees WHERE task_id = ?").all(taskId).map(r => r.member_id);
    const tags = db.prepare("SELECT tag FROM task_tags WHERE task_id = ?").all(taskId).map(r => r.tag);
    const comments = db.prepare("SELECT id, author, content, created_at FROM task_comments WHERE task_id = ? ORDER BY created_at").all(taskId);
    const activity = db.prepare("SELECT id, actor, action, detail, created_at FROM task_activity WHERE task_id = ? ORDER BY created_at DESC LIMIT 20").all(taskId);
    return {
      id: task.id, column: task.column_status, title: task.title, desc: task.description,
      priority: task.priority, assignees, tags, created: task.created_date,
      dueDate: task.due_date || "", epicId: task.epic_id || "", priorityOrder: task.priority_order || 0,
      comments: comments.map(c => ({ id: c.id, author: c.author, content: c.content, createdAt: c.created_at })),
      activity: activity.map(a => ({ id: a.id, actor: a.actor, action: a.action, detail: a.detail, createdAt: a.created_at })),
    };
  }

  function logActivity(taskId, actor, action, detail) {
    db.prepare("INSERT INTO task_activity (task_id, actor, action, detail) VALUES (?, ?, ?, ?)").run(taskId, actor, action, detail || "");
  }

  // GET /api/tasks
  router.get("/", (req, res) => {
    const tasks = db.prepare("SELECT id FROM tasks ORDER BY priority_order, created_at").all();
    const result = tasks.map(t => getFullTask(t.id)).filter(Boolean);
    res.json(result);
  });

  // POST /api/tasks
  router.post("/", (req, res) => {
    const { id, column, title, desc, priority, assignees = [], tags = [], created, epicId, priorityOrder, dueDate, projectId } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });
    const tx = db.transaction(() => {
      db.prepare("INSERT INTO tasks (id, column_status, title, description, priority, created_date, epic_id, priority_order, due_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)")
        .run(id, column || "backlog", title, desc || "", priority || "medium", created || new Date().toISOString().slice(0, 10), epicId || "", priorityOrder || 0, dueDate || "");
      const insA = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of assignees) insA.run(id, a);
      const insT = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");
      for (const t of tags) insT.run(id, t);
      logActivity(id, "system", "created", `タスク「${title}」を作成`);
    });
    tx();
    res.status(201).json(getFullTask(id));
  });

  // PUT /api/tasks/:id
  router.put("/:id", (req, res) => {
    const { id } = req.params;
    const existing = db.prepare("SELECT * FROM tasks WHERE id = ?").get(id);
    if (!existing) return res.status(404).json({ error: "task not found" });
    const { column, title, desc, priority, assignees, tags, created, epicId, priorityOrder, dueDate } = req.body;
    const tx = db.transaction(() => {
      db.prepare("UPDATE tasks SET column_status=?, title=?, description=?, priority=?, created_date=?, epic_id=?, priority_order=?, due_date=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
        .run(column, title, desc || "", priority, created, epicId || "", priorityOrder || 0, dueDate || "", id);
      db.prepare("DELETE FROM task_assignees WHERE task_id = ?").run(id);
      const insA = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of (assignees || [])) insA.run(id, a);
      db.prepare("DELETE FROM task_tags WHERE task_id = ?").run(id);
      const insT = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");
      for (const t of (tags || [])) insT.run(id, t);
      if (existing.column_status !== column) logActivity(id, "system", "status_changed", `${existing.column_status} → ${column}`);
      if (existing.title !== title) logActivity(id, "system", "updated", `タイトル変更`);
    });
    tx();
    res.json(getFullTask(id));
  });

  // PATCH /api/tasks/:id/column
  router.patch("/:id/column", (req, res) => {
    const { id } = req.params;
    const { column } = req.body;
    const old = db.prepare("SELECT column_status FROM tasks WHERE id = ?").get(id);
    db.prepare("UPDATE tasks SET column_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(column, id);
    if (old) logActivity(id, "system", "status_changed", `${old.column_status} → ${column}`);
    res.json({ id, column });
  });

  // PATCH /api/tasks/:id/assignees — quick assign without full update
  router.patch("/:id/assignees", (req, res) => {
    const { id } = req.params;
    const { assignees } = req.body;
    const tx = db.transaction(() => {
      db.prepare("DELETE FROM task_assignees WHERE task_id = ?").run(id);
      const ins = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of (assignees || [])) ins.run(id, a);
      logActivity(id, "system", "assignee_changed", `担当者変更: ${(assignees || []).join(", ")}`);
    });
    tx();
    res.json(getFullTask(id));
  });

  // POST /api/tasks/:id/comments — add comment
  router.post("/:id/comments", (req, res) => {
    const { id } = req.params;
    const { author, content } = req.body;
    if (!content) return res.status(400).json({ error: "content required" });
    db.prepare("INSERT INTO task_comments (task_id, author, content) VALUES (?, ?, ?)").run(id, author || "anonymous", content);
    logActivity(id, author || "anonymous", "commented", content.slice(0, 80));
    res.json(getFullTask(id));
  });

  // GET /api/tasks/:id/activity — get activity log
  router.get("/:id/activity", (req, res) => {
    const activity = db.prepare("SELECT * FROM task_activity WHERE task_id = ? ORDER BY created_at DESC LIMIT 50").all(req.params.id);
    res.json(activity);
  });

  // DELETE /api/tasks/:id
  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM tasks WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  // PUT /api/tasks/reorder/bulk
  router.put("/reorder/bulk", (req, res) => {
    const { orders } = req.body;
    const stmt = db.prepare("UPDATE tasks SET priority_order = ? WHERE id = ?");
    const tx = db.transaction(() => { for (const o of orders) stmt.run(o.priorityOrder, o.id); });
    tx();
    res.json({ status: "ok" });
  });

  // PATCH /api/tasks/:id/epic
  router.patch("/:id/epic", (req, res) => {
    const { epicId } = req.body;
    db.prepare("UPDATE tasks SET epic_id = ? WHERE id = ?").run(epicId || "", req.params.id);
    res.json(getFullTask(req.params.id));
  });

  return router;
};
