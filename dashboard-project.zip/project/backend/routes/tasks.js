const express = require("express");
const router = express.Router();

module.exports = function (db) {
  // Helper: get full task with assignees + tags
  function getFullTask(taskId) {
    const task = db.prepare("SELECT * FROM tasks WHERE id = ?").get(taskId);
    if (!task) return null;
    const assignees = db.prepare("SELECT member_id FROM task_assignees WHERE task_id = ?").all(taskId).map(r => r.member_id);
    const tags = db.prepare("SELECT tag FROM task_tags WHERE task_id = ?").all(taskId).map(r => r.tag);
    return {
      id: task.id,
      column: task.column_status,
      title: task.title,
      desc: task.description,
      priority: task.priority,
      assignees,
      tags,
      created: task.created_date,
    };
  }

  // GET /api/tasks
  router.get("/", (req, res) => {
    const tasks = db.prepare("SELECT id FROM tasks ORDER BY created_at").all();
    const result = tasks.map(t => getFullTask(t.id)).filter(Boolean);
    res.json(result);
  });

  // POST /api/tasks
  router.post("/", (req, res) => {
    const { id, column, title, desc, priority, assignees = [], tags = [], created } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });

    const tx = db.transaction(() => {
      db.prepare("INSERT INTO tasks (id, column_status, title, description, priority, created_date) VALUES (?, ?, ?, ?, ?, ?)")
        .run(id, column || "backlog", title, desc || "", priority || "medium", created || new Date().toISOString().slice(0, 10));
      const insA = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of assignees) insA.run(id, a);
      const insT = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");
      for (const t of tags) insT.run(id, t);
    });
    tx();
    res.status(201).json(getFullTask(id));
  });

  // PUT /api/tasks/:id
  router.put("/:id", (req, res) => {
    const { id } = req.params;
    const existing = db.prepare("SELECT id FROM tasks WHERE id = ?").get(id);
    if (!existing) return res.status(404).json({ error: "task not found" });

    const { column, title, desc, priority, assignees, tags, created } = req.body;
    const tx = db.transaction(() => {
      db.prepare(`UPDATE tasks SET column_status = ?, title = ?, description = ?, priority = ?, created_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`)
        .run(column, title, desc || "", priority, created, id);
      // Replace assignees
      db.prepare("DELETE FROM task_assignees WHERE task_id = ?").run(id);
      const insA = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of (assignees || [])) insA.run(id, a);
      // Replace tags
      db.prepare("DELETE FROM task_tags WHERE task_id = ?").run(id);
      const insT = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");
      for (const t of (tags || [])) insT.run(id, t);
    });
    tx();
    res.json(getFullTask(id));
  });

  // PATCH /api/tasks/:id/column  (drag-n-drop shortcut)
  router.patch("/:id/column", (req, res) => {
    const { id } = req.params;
    const { column } = req.body;
    db.prepare("UPDATE tasks SET column_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?").run(column, id);
    res.json({ id, column });
  });

  // DELETE /api/tasks/:id
  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM tasks WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  return router;
};
