const express = require("express");
const router = express.Router();

module.exports = function (db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS retrospectives (
      id TEXT PRIMARY KEY,
      sprint_id TEXT DEFAULT '',
      title TEXT NOT NULL,
      date TEXT NOT NULL,
      project_id TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS retro_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      retro_id TEXT NOT NULL,
      type TEXT NOT NULL,
      content TEXT NOT NULL,
      votes INTEGER DEFAULT 0,
      action TEXT DEFAULT '',
      FOREIGN KEY (retro_id) REFERENCES retrospectives(id) ON DELETE CASCADE
    );
  `);

  function getFullRetro(id) {
    const r = db.prepare("SELECT * FROM retrospectives WHERE id = ?").get(id);
    if (!r) return null;
    const items = db.prepare("SELECT * FROM retro_items WHERE retro_id = ? ORDER BY type, votes DESC, id").all(id);
    return {
      id: r.id, sprintId: r.sprint_id, title: r.title, date: r.date, projectId: r.project_id,
      items: items.map(i => ({ id: i.id, type: i.type, content: i.content, votes: i.votes, action: i.action })),
    };
  }

  router.get("/", (req, res) => {
    const retros = db.prepare("SELECT id FROM retrospectives ORDER BY date DESC").all();
    res.json(retros.map(r => getFullRetro(r.id)).filter(Boolean));
  });

  router.get("/:id", (req, res) => {
    const retro = getFullRetro(req.params.id);
    if (!retro) return res.status(404).json({ error: "Not found" });
    res.json(retro);
  });

  router.post("/", (req, res) => {
    const { id, sprintId, title, date, projectId, items = [] } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });
    const tx = db.transaction(() => {
      db.prepare("INSERT INTO retrospectives (id, sprint_id, title, date, project_id) VALUES (?, ?, ?, ?, ?)")
        .run(id, sprintId || "", title, date || new Date().toISOString().slice(0, 10), projectId || "");
      const ins = db.prepare("INSERT INTO retro_items (retro_id, type, content, votes, action) VALUES (?, ?, ?, ?, ?)");
      for (const i of items) ins.run(id, i.type, i.content, i.votes || 0, i.action || "");
    });
    tx();
    res.status(201).json(getFullRetro(id));
  });

  router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { sprintId, title, date, projectId, items = [] } = req.body;
    const tx = db.transaction(() => {
      db.prepare("UPDATE retrospectives SET sprint_id=?, title=?, date=?, project_id=? WHERE id=?")
        .run(sprintId || "", title, date, projectId || "", id);
      db.prepare("DELETE FROM retro_items WHERE retro_id = ?").run(id);
      const ins = db.prepare("INSERT INTO retro_items (retro_id, type, content, votes, action) VALUES (?, ?, ?, ?, ?)");
      for (const i of items) ins.run(id, i.type, i.content, i.votes || 0, i.action || "");
    });
    tx();
    res.json(getFullRetro(id));
  });

  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM retrospectives WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  return router;
};
