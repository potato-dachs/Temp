const express = require("express");
const router = express.Router();

module.exports = function (db) {
  router.get("/", (req, res) => {
    const members = db.prepare("SELECT * FROM members ORDER BY id").all();
    res.json(members.map(m => ({
      id: m.id, name: m.name, initials: m.initials, color: m.color,
    })));
  });

  router.post("/", (req, res) => {
    const { id, name, initials, color } = req.body;
    if (!id || !name) return res.status(400).json({ error: "id and name required" });
    db.prepare("INSERT INTO members (id, name, initials, color) VALUES (?, ?, ?, ?)")
      .run(id, name, initials || name.slice(0, 2).toUpperCase(), color || "#0052cc");
    res.status(201).json({ id, name, initials, color });
  });

  router.delete("/:id", (req, res) => {
    const { id } = req.params;
    const tx = db.transaction(() => {
      db.prepare("DELETE FROM task_assignees WHERE member_id = ?").run(id);
      db.prepare("DELETE FROM personal_goals WHERE member_id = ?").run(id);
      db.prepare("DELETE FROM members WHERE id = ?").run(id);
    });
    tx();
    res.json({ deleted: id });
  });

  return router;
};
