const express = require("express");
const router = express.Router();

module.exports = function (db) {

  // ── Ensure tables ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS knowledge_articles (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL DEFAULT 'general',
      author TEXT DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      summary TEXT DEFAULT '',
      body TEXT DEFAULT '',
      version INTEGER NOT NULL DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS knowledge_tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id TEXT NOT NULL,
      tag TEXT NOT NULL,
      FOREIGN KEY (article_id) REFERENCES knowledge_articles(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS knowledge_relations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      from_id TEXT NOT NULL,
      to_id TEXT NOT NULL,
      FOREIGN KEY (from_id) REFERENCES knowledge_articles(id) ON DELETE CASCADE,
      FOREIGN KEY (to_id) REFERENCES knowledge_articles(id) ON DELETE CASCADE
    );
  `);

  // ── Helper: full article with tags & relations ──
  function getFullArticle(id) {
    const a = db.prepare("SELECT * FROM knowledge_articles WHERE id = ?").get(id);
    if (!a) return null;
    const tags = db.prepare("SELECT tag FROM knowledge_tags WHERE article_id = ?").all(id).map(r => r.tag);
    const related = db.prepare("SELECT to_id FROM knowledge_relations WHERE from_id = ?").all(id).map(r => r.to_id);
    return {
      id: a.id, title: a.title, category: a.category, author: a.author,
      status: a.status, summary: a.summary, body: a.body, version: a.version,
      tags, related,
      created: a.created_at, updated: a.updated_at,
    };
  }

  // GET /api/knowledge — list all articles (lightweight, no body)
  router.get("/", (req, res) => {
    const articles = db.prepare("SELECT id, title, category, author, status, summary, version, created_at, updated_at FROM knowledge_articles ORDER BY updated_at DESC").all();
    const result = articles.map(a => {
      const tags = db.prepare("SELECT tag FROM knowledge_tags WHERE article_id = ?").all(a.id).map(r => r.tag);
      return { id: a.id, title: a.title, category: a.category, author: a.author, status: a.status, summary: a.summary, version: a.version, tags, created: a.created_at, updated: a.updated_at };
    });
    res.json(result);
  });

  // GET /api/knowledge/:id — full article
  router.get("/:id", (req, res) => {
    const article = getFullArticle(req.params.id);
    if (!article) return res.status(404).json({ error: "Article not found" });
    res.json(article);
  });

  // POST /api/knowledge — create article
  router.post("/", (req, res) => {
    const { id, title, category, author, status, summary, body, tags = [], related = [] } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });
    const tx = db.transaction(() => {
      db.prepare("INSERT INTO knowledge_articles (id, title, category, author, status, summary, body) VALUES (?, ?, ?, ?, ?, ?, ?)")
        .run(id, title, category || "general", author || "", status || "draft", summary || "", body || "");
      const insT = db.prepare("INSERT INTO knowledge_tags (article_id, tag) VALUES (?, ?)");
      for (const t of tags) insT.run(id, t);
      const insR = db.prepare("INSERT INTO knowledge_relations (from_id, to_id) VALUES (?, ?)");
      for (const r of related) insR.run(id, r);
    });
    tx();
    res.status(201).json(getFullArticle(id));
  });

  // PUT /api/knowledge/:id — update article
  router.put("/:id", (req, res) => {
    const { id } = req.params;
    const existing = db.prepare("SELECT id, version FROM knowledge_articles WHERE id = ?").get(id);
    if (!existing) return res.status(404).json({ error: "Article not found" });
    const { title, category, author, status, summary, body, tags = [], related = [] } = req.body;
    const tx = db.transaction(() => {
      db.prepare("UPDATE knowledge_articles SET title=?, category=?, author=?, status=?, summary=?, body=?, version=?, updated_at=CURRENT_TIMESTAMP WHERE id=?")
        .run(title, category, author || "", status || "draft", summary || "", body || "", existing.version + 1, id);
      db.prepare("DELETE FROM knowledge_tags WHERE article_id = ?").run(id);
      const insT = db.prepare("INSERT INTO knowledge_tags (article_id, tag) VALUES (?, ?)");
      for (const t of tags) insT.run(id, t);
      db.prepare("DELETE FROM knowledge_relations WHERE from_id = ?").run(id);
      const insR = db.prepare("INSERT INTO knowledge_relations (from_id, to_id) VALUES (?, ?)");
      for (const r of related) insR.run(id, r);
    });
    tx();
    res.json(getFullArticle(id));
  });

  // DELETE /api/knowledge/:id
  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM knowledge_articles WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  // GET /api/knowledge/search?q=...&category=...&tag=...&status=...
  // RAG-friendly search endpoint
  router.get("/search/query", (req, res) => {
    const { q, category, tag, status } = req.query;
    let sql = "SELECT id FROM knowledge_articles WHERE 1=1";
    const params = [];
    if (q) { sql += " AND (title LIKE ? OR summary LIKE ? OR body LIKE ?)"; params.push(`%${q}%`, `%${q}%`, `%${q}%`); }
    if (category) { sql += " AND category = ?"; params.push(category); }
    if (status) { sql += " AND status = ?"; params.push(status); }
    sql += " ORDER BY updated_at DESC";
    let ids = db.prepare(sql).all(...params).map(r => r.id);
    if (tag) {
      const tagIds = db.prepare("SELECT DISTINCT article_id FROM knowledge_tags WHERE tag = ?").all(tag).map(r => r.article_id);
      ids = ids.filter(id => tagIds.includes(id));
    }
    res.json(ids.map(id => getFullArticle(id)).filter(Boolean));
  });

  // GET /api/knowledge/export/rag — export all approved articles in RAG-friendly format
  router.get("/export/rag", (req, res) => {
    const statusFilter = req.query.status || "approved";
    const articles = db.prepare("SELECT id FROM knowledge_articles WHERE status = ? ORDER BY updated_at DESC").all(statusFilter);
    const result = articles.map(a => {
      const full = getFullArticle(a.id);
      return {
        id: full.id,
        metadata: {
          title: full.title, category: full.category, tags: full.tags,
          author: full.author, version: full.version,
          summary: full.summary, related: full.related,
          updated: full.updated,
        },
        content: full.body,
      };
    });
    res.json({ count: result.length, articles: result });
  });

  return router;
};
