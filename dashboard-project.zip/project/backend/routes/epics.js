const express = require("express");
const router = express.Router();

module.exports = function (db) {
  // Ensure table
  db.exec(`
    CREATE TABLE IF NOT EXISTS epics (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      color TEXT NOT NULL DEFAULT '#0052cc',
      description TEXT DEFAULT '',
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Add epic_id and priority_order to tasks if not exists
  try { db.exec("ALTER TABLE tasks ADD COLUMN epic_id TEXT DEFAULT ''"); } catch {}
  try { db.exec("ALTER TABLE tasks ADD COLUMN priority_order INTEGER DEFAULT 0"); } catch {}

  // GET /api/epics
  router.get("/", (req, res) => {
    const epics = db.prepare("SELECT * FROM epics ORDER BY sort_order, created_at").all();
    res.json(epics.map(e => ({
      id: e.id, name: e.name, color: e.color,
      description: e.description, sortOrder: e.sort_order,
    })));
  });

  // POST /api/epics
  router.post("/", (req, res) => {
    const { id, name, color, description, sortOrder } = req.body;
    if (!id || !name) return res.status(400).json({ error: "id and name required" });
    db.prepare("INSERT INTO epics (id, name, color, description, sort_order) VALUES (?, ?, ?, ?, ?)")
      .run(id, name, color || "#0052cc", description || "", sortOrder || 0);
    res.status(201).json({ id, name, color: color || "#0052cc", description: description || "", sortOrder: sortOrder || 0 });
  });

  // PUT /api/epics/:id
  router.put("/:id", (req, res) => {
    const { name, color, description, sortOrder } = req.body;
    db.prepare("UPDATE epics SET name=?, color=?, description=?, sort_order=? WHERE id=?")
      .run(name, color, description || "", sortOrder || 0, req.params.id);
    res.json({ id: req.params.id, name, color, description, sortOrder });
  });

  // DELETE /api/epics/:id
  router.delete("/:id", (req, res) => {
    db.prepare("UPDATE tasks SET epic_id = '' WHERE epic_id = ?").run(req.params.id);
    db.prepare("DELETE FROM epics WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  // PUT /api/epics/reorder — bulk update sort orders
  router.put("/reorder/bulk", (req, res) => {
    const { orders } = req.body; // [{ id, sortOrder }]
    const stmt = db.prepare("UPDATE epics SET sort_order = ? WHERE id = ?");
    const tx = db.transaction(() => { for (const o of orders) stmt.run(o.sortOrder, o.id); });
    tx();
    res.json({ status: "ok" });
  });

  return router;
};
