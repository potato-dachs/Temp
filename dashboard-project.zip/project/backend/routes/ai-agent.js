const express = require("express");
const router = express.Router();

const CLAUDE_API = "https://api.anthropic.com/v1/messages";
const CLAUDE_KEY = process.env.ANTHROPIC_API_KEY || "";
const MODEL = process.env.AI_MODEL || "claude-sonnet-4-20250514";
const API_BASE = process.env.DASHBOARD_API_INTERNAL || "http://localhost:3001";

// Tools the agent can call (dashboard API subset)
const AGENT_TOOLS = [
  { name: "dashboard_api", description: "ダッシュボードAPIを呼び出す。タスク作成・更新・ステータス変更・スプリント管理・ナレッジ登録など全ての操作が可能。", input_schema: { type: "object", properties: { method: { type: "string", enum: ["GET", "POST", "PUT", "PATCH", "DELETE"] }, path: { type: "string", description: "APIパス（例: /api/tasks, /api/sprints/sp-1, /api/knowledge）" }, body: { type: "object", description: "リクエストボディ" } }, required: ["method", "path"] } },
  { name: "ask_human", description: "人間に質問して回答を待つ。要件確認や承認依頼に使用。質問は具体的に。", input_schema: { type: "object", properties: { question: { type: "string", description: "人間への質問" } }, required: ["question"] } },
];

const SYSTEM_PROMPT = `あなたはAIスクラムチームの統合エージェントです。以下の5つの役割を状況に応じて切り替えて行動します。

## チームメンバー
- **佐藤**（顧客代表）: 人間の要求を詳細な要件に展開する。質問魔。
- **鈴木**（PO）: バックログ管理、優先度決定、受入判定。表と構造が好き。
- **高橋**（SM）: プロセス管理、デイリー、ふりかえり。DoDに妥協しない。
- **伊藤**（Dev-FE）: フロントエンド実装。一次情報重視。
- **田中**（Dev-BE）: バックエンド実装。慎重派、設計重視。

## 行動ルール
1. まず佐藤として要件を確認。不明点があればask_humanで質問（最大3回）
2. 要件が明確になったら鈴木としてタスクを作成（dashboard_api POST /api/tasks）
3. 高橋としてスプリントを管理
4. 伊藤/田中として実装方針を説明
5. 全ての操作はdashboard_apiツールで実行し、ダッシュボードに反映する

## 応答フォーマット
応答には必ず発言者を明記:
**佐藤**: 〜
**鈴木**: 〜

## 重要
- ダッシュボードAPIを実際に呼び出してタスクやスプリントを操作すること
- ask_humanで質問した場合、回答が来るまで待つこと
- 日本語で応答すること
`;

module.exports = function (db) {
  // Store conversation contexts in memory (per conversation)
  const contexts = {};

  // Execute dashboard API call
  async function callDashboardAPI(method, path, body) {
    const url = `${API_BASE}${path}`;
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body && ["POST", "PUT", "PATCH"].includes(method)) {
      opts.body = JSON.stringify(body);
    }
    try {
      const res = await fetch(url, opts);
      return await res.json();
    } catch (e) {
      return { error: e.message };
    }
  }

  // Call Claude API with tool use loop
  async function callAgent(conversationId, messages) {
    if (!CLAUDE_KEY) {
      return {
        text: "⚠️ ANTHROPIC_API_KEY が設定されていません。バックエンドの環境変数に設定してください。\n\n```\nexport ANTHROPIC_API_KEY=\"sk-ant-xxxxx\"\n```\n\n設定後、バックエンドを再起動してください。",
        toolResults: [],
        pendingQuestion: null,
      };
    }

    const maxLoops = 8;
    let currentMessages = [...messages];
    let allText = [];
    let toolResults = [];
    let pendingQuestion = null;

    for (let i = 0; i < maxLoops; i++) {
      const res = await fetch(CLAUDE_API, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": CLAUDE_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 4096,
          system: SYSTEM_PROMPT,
          messages: currentMessages,
          tools: AGENT_TOOLS,
        }),
      });

      if (!res.ok) {
        const err = await res.text();
        return { text: `API Error: ${res.status} ${err}`, toolResults: [], pendingQuestion: null };
      }

      const data = await res.json();
      const textParts = data.content.filter(c => c.type === "text").map(c => c.text);
      const toolCalls = data.content.filter(c => c.type === "tool_use");

      if (textParts.length > 0) allText.push(textParts.join("\n"));

      // No tool calls — done
      if (toolCalls.length === 0 || data.stop_reason === "end_turn") {
        break;
      }

      // Build assistant content for history
      const assistantContent = [];
      if (textParts.length > 0) assistantContent.push(...textParts.map(t => ({ type: "text", text: t })));
      for (const tc of toolCalls) assistantContent.push({ type: "tool_use", id: tc.id, name: tc.name, input: tc.input });
      currentMessages.push({ role: "assistant", content: assistantContent });

      // Execute tools
      const results = [];
      for (const tc of toolCalls) {
        if (tc.name === "dashboard_api") {
          const { method, path, body } = tc.input;
          const result = await callDashboardAPI(method, path, body);
          const resultStr = JSON.stringify(result, null, 2);
          results.push({ type: "tool_result", tool_use_id: tc.id, content: resultStr });
          toolResults.push({ tool: "dashboard_api", method, path, result: resultStr.slice(0, 200) });
        } else if (tc.name === "ask_human") {
          // Return question to frontend, pause execution
          pendingQuestion = tc.input.question;
          results.push({ type: "tool_result", tool_use_id: tc.id, content: "人間に質問を送信しました。回答を待っています..." });
          // Save state for continuation
          currentMessages.push({ role: "user", content: results });
          contexts[conversationId] = { messages: currentMessages, pendingToolId: tc.id };
          return { text: allText.join("\n\n"), toolResults, pendingQuestion };
        }
      }
      currentMessages.push({ role: "user", content: results });
    }

    // Save context
    contexts[conversationId] = { messages: currentMessages, pendingToolId: null };

    return { text: allText.join("\n\n"), toolResults, pendingQuestion: null };
  }

  // POST /api/ai/agent/chat — send message and get agent response
  router.post("/chat", async (req, res) => {
    const { conversationId, message, projectId } = req.body;
    if (!conversationId || !message) return res.status(400).json({ error: "conversationId and message required" });

    try {
      // Get or create context
      let ctx = contexts[conversationId];
      let messages;

      if (ctx && ctx.pendingToolId) {
        // Continue from pending question — feed human answer back as tool result
        messages = ctx.messages;
        // Replace the last pending tool result with actual answer
        const lastUserMsg = messages[messages.length - 1];
        if (Array.isArray(lastUserMsg.content)) {
          const pendingResult = lastUserMsg.content.find(c => c.tool_use_id === ctx.pendingToolId);
          if (pendingResult) pendingResult.content = `人間の回答: ${message}`;
        }
      } else {
        // New message
        messages = ctx ? ctx.messages : [];
        if (projectId) {
          messages.push({ role: "user", content: `[プロジェクトID: ${projectId}] ${message}` });
        } else {
          messages.push({ role: "user", content: message });
        }
      }

      // Save human message to DB
      db.prepare("INSERT INTO ai_messages (conversation_id, role, agent_id, content, metadata) VALUES (?, 'human', '', ?, '{}')")
        .run(conversationId, message);

      // Call agent
      const result = await callAgent(conversationId, messages);

      // Build response messages
      const responseMessages = [];

      // Agent text response
      if (result.text) {
        responseMessages.push({ role: "assistant", agentId: "customer", content: result.text });
        db.prepare("INSERT INTO ai_messages (conversation_id, role, agent_id, content, metadata) VALUES (?, 'assistant', 'customer', ?, ?)")
          .run(conversationId, result.text, JSON.stringify({ toolResults: result.toolResults }));
      }

      // Tool execution results as system messages
      for (const tr of result.toolResults) {
        const sysMsg = `🔧 ${tr.method} ${tr.path}`;
        responseMessages.push({ role: "assistant", agentId: "system", content: sysMsg });
      }

      // Pending question
      if (result.pendingQuestion) {
        responseMessages.push({ role: "assistant", agentId: "customer", content: result.pendingQuestion });
        db.prepare("INSERT INTO ai_messages (conversation_id, role, agent_id, content, metadata) VALUES (?, 'assistant', 'customer', ?, '{}')")
          .run(conversationId, result.pendingQuestion);
      }

      res.json({
        messages: responseMessages,
        pendingQuestion: result.pendingQuestion,
        toolResults: result.toolResults,
      });
    } catch (e) {
      console.error("AI Agent error:", e);
      res.status(500).json({ error: e.message });
    }
  });

  return router;
};
