const express = require("express");
const router = express.Router();

module.exports = function (db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      color TEXT DEFAULT '#0052cc',
      description TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // Seed if empty
  const count = db.prepare("SELECT COUNT(*) as cnt FROM projects").get();
  if (count.cnt === 0) {
    const ins = db.prepare("INSERT INTO projects (id, name, color, description) VALUES (?, ?, ?, ?)");
    ins.run("proj-1", "Dashboard開発", "#0052cc", "プロジェクト管理ダッシュボードの開発");
    ins.run("proj-2", "モバイルアプリ", "#6554c0", "iOS/Androidアプリの開発");
  }

  router.get("/", (req, res) => {
    const projects = db.prepare("SELECT * FROM projects ORDER BY created_at").all();
    res.json(projects.map(p => ({ id: p.id, name: p.name, color: p.color, description: p.description })));
  });

  router.post("/", (req, res) => {
    const { id, name, color, description } = req.body;
    if (!id || !name) return res.status(400).json({ error: "id and name required" });
    db.prepare("INSERT INTO projects (id, name, color, description) VALUES (?, ?, ?, ?)")
      .run(id, name, color || "#0052cc", description || "");
    res.status(201).json({ id, name, color, description });
  });

  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM projects WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  return router;
};
