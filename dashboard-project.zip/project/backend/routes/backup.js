const express = require("express");
const fs = require("fs");
const path = require("path");
const router = express.Router();

const BACKUP_DIR = path.join(__dirname, "..", "backups");

module.exports = function (db) {

  // Ensure backup directory exists
  if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

  // ── Helper: export all data ──
  function exportAll() {
    const members = db.prepare("SELECT * FROM members ORDER BY id").all();
    const tasks = db.prepare("SELECT * FROM tasks ORDER BY created_at").all();
    const taskAssignees = db.prepare("SELECT * FROM task_assignees").all();
    const taskTags = db.prepare("SELECT * FROM task_tags").all();
    const orgGoals = db.prepare("SELECT * FROM org_goals ORDER BY created_at").all();
    const personalGoals = db.prepare("SELECT * FROM personal_goals ORDER BY created_at").all();
    const keyResults = db.prepare("SELECT * FROM personal_goal_key_results ORDER BY id").all();

    return {
      version: "1.0",
      exported_at: new Date().toISOString(),
      data: { members, tasks, taskAssignees, taskTags, orgGoals, personalGoals, keyResults },
    };
  }

  // ── Helper: restore all data ──
  function restoreAll(backup) {
    const d = backup.data;
    const tx = db.transaction(() => {
      // Clear all tables (order matters for FK)
      db.prepare("DELETE FROM personal_goal_key_results").run();
      db.prepare("DELETE FROM personal_goals").run();
      db.prepare("DELETE FROM org_goals").run();
      db.prepare("DELETE FROM task_tags").run();
      db.prepare("DELETE FROM task_assignees").run();
      db.prepare("DELETE FROM tasks").run();
      db.prepare("DELETE FROM members").run();

      // Restore members
      const insM = db.prepare("INSERT INTO members (id, name, initials, color) VALUES (?, ?, ?, ?)");
      for (const m of (d.members || [])) insM.run(m.id, m.name, m.initials, m.color);

      // Restore tasks
      const insT = db.prepare("INSERT INTO tasks (id, column_status, title, description, priority, created_date, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      for (const t of (d.tasks || [])) insT.run(t.id, t.column_status, t.title, t.description, t.priority, t.created_date, t.created_at, t.updated_at);

      // Restore task assignees
      const insTA = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
      for (const a of (d.taskAssignees || [])) insTA.run(a.task_id, a.member_id);

      // Restore task tags
      const insTT = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");
      for (const t of (d.taskTags || [])) insTT.run(t.task_id, t.tag);

      // Restore org goals
      const insOG = db.prepare("INSERT INTO org_goals (id, level, title, description, progress, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
      for (const g of (d.orgGoals || [])) insOG.run(g.id, g.level, g.title, g.description, g.progress, g.created_at, g.updated_at);

      // Restore personal goals
      const insPG = db.prepare("INSERT INTO personal_goals (id, member_id, period, title, description, progress, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
      for (const g of (d.personalGoals || [])) insPG.run(g.id, g.member_id, g.period, g.title, g.description, g.progress, g.created_at, g.updated_at);

      // Restore key results
      const insKR = db.prepare("INSERT INTO personal_goal_key_results (goal_id, key_result) VALUES (?, ?)");
      for (const kr of (d.keyResults || [])) insKR.run(kr.goal_id, kr.key_result);
    });
    tx();
  }

  // GET /api/backup/export — download full backup as JSON
  router.get("/export", (req, res) => {
    const backup = exportAll();
    res.setHeader("Content-Disposition", `attachment; filename=dashboard-backup-${new Date().toISOString().slice(0, 10)}.json`);
    res.json(backup);
  });

  // POST /api/backup/restore — upload JSON to restore
  router.post("/restore", (req, res) => {
    try {
      const backup = req.body;
      if (!backup.data) return res.status(400).json({ error: "Invalid backup format: missing 'data' field" });
      restoreAll(backup);
      res.json({ status: "restored", timestamp: new Date().toISOString() });
    } catch (e) {
      res.status(500).json({ error: "Restore failed: " + e.message });
    }
  });

  // POST /api/backup/save — save backup to server filesystem
  router.post("/save", (req, res) => {
    const backup = exportAll();
    const filename = `backup-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
    const filepath = path.join(BACKUP_DIR, filename);
    fs.writeFileSync(filepath, JSON.stringify(backup, null, 2), "utf8");
    res.json({ status: "saved", filename, path: filepath });
  });

  // GET /api/backup/list — list available server-side backups
  router.get("/list", (req, res) => {
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.endsWith(".json"))
      .map(f => {
        const stat = fs.statSync(path.join(BACKUP_DIR, f));
        return { filename: f, size: stat.size, created: stat.mtime.toISOString() };
      })
      .sort((a, b) => b.created.localeCompare(a.created));
    res.json(files);
  });

  // POST /api/backup/restore-file — restore from a server-side backup file
  router.post("/restore-file", (req, res) => {
    try {
      const { filename } = req.body;
      if (!filename) return res.status(400).json({ error: "filename required" });
      const filepath = path.join(BACKUP_DIR, filename);
      if (!fs.existsSync(filepath)) return res.status(404).json({ error: "Backup file not found" });
      const backup = JSON.parse(fs.readFileSync(filepath, "utf8"));
      restoreAll(backup);
      res.json({ status: "restored", filename });
    } catch (e) {
      res.status(500).json({ error: "Restore failed: " + e.message });
    }
  });

  // DELETE /api/backup/:filename — delete a server-side backup
  router.delete("/:filename", (req, res) => {
    const filepath = path.join(BACKUP_DIR, req.params.filename);
    if (fs.existsSync(filepath)) fs.unlinkSync(filepath);
    res.json({ deleted: req.params.filename });
  });

  return router;
};
