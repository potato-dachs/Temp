const express = require("express");
const router = express.Router();

module.exports = function (db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_conversations (
      id TEXT PRIMARY KEY,
      title TEXT DEFAULT '',
      status TEXT DEFAULT 'active',
      project_id TEXT DEFAULT '',
      sprint_id TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS ai_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id TEXT NOT NULL,
      role TEXT NOT NULL,
      agent_id TEXT DEFAULT '',
      content TEXT NOT NULL,
      metadata TEXT DEFAULT '{}',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (conversation_id) REFERENCES ai_conversations(id) ON DELETE CASCADE
    );
  `);

  // GET /api/ai/conversations
  router.get("/conversations", (req, res) => {
    const convos = db.prepare("SELECT * FROM ai_conversations ORDER BY created_at DESC").all();
    const result = convos.map(c => {
      const msgCount = db.prepare("SELECT COUNT(*) as cnt FROM ai_messages WHERE conversation_id = ?").get(c.id).cnt;
      const lastMsg = db.prepare("SELECT content, created_at FROM ai_messages WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 1").get(c.id);
      return { id: c.id, title: c.title, status: c.status, projectId: c.project_id, sprintId: c.sprint_id, messageCount: msgCount, lastMessage: lastMsg?.content?.slice(0, 80) || "", createdAt: c.created_at };
    });
    res.json(result);
  });

  // POST /api/ai/conversations
  router.post("/conversations", (req, res) => {
    const { id, title, projectId } = req.body;
    db.prepare("INSERT INTO ai_conversations (id, title, project_id) VALUES (?, ?, ?)").run(id, title || "新しい依頼", projectId || "");
    res.status(201).json({ id, title, status: "active", projectId });
  });

  // GET /api/ai/conversations/:id/messages
  router.get("/conversations/:id/messages", (req, res) => {
    const msgs = db.prepare("SELECT * FROM ai_messages WHERE conversation_id = ? ORDER BY created_at").all(req.params.id);
    res.json(msgs.map(m => ({ id: m.id, role: m.role, agentId: m.agent_id, content: m.content, metadata: JSON.parse(m.metadata || "{}"), createdAt: m.created_at })));
  });

  // POST /api/ai/conversations/:id/messages — human sends a message
  router.post("/conversations/:id/messages", (req, res) => {
    const { role, agentId, content, metadata } = req.body;
    db.prepare("INSERT INTO ai_messages (conversation_id, role, agent_id, content, metadata) VALUES (?, ?, ?, ?, ?)")
      .run(req.params.id, role || "human", agentId || "", content, JSON.stringify(metadata || {}));
    // Update conversation title from first human message
    const convo = db.prepare("SELECT title FROM ai_conversations WHERE id = ?").get(req.params.id);
    if (convo && (convo.title === "新しい依頼" || !convo.title) && role === "human") {
      db.prepare("UPDATE ai_conversations SET title = ? WHERE id = ?").run(content.slice(0, 50), req.params.id);
    }
    res.json({ status: "ok" });
  });

  // DELETE /api/ai/conversations/:id
  router.delete("/conversations/:id", (req, res) => {
    db.prepare("DELETE FROM ai_conversations WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  return router;
};
