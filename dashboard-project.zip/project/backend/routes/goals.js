const express = require("express");
const router = express.Router();

module.exports = function (db) {
  /* ═══ Org Goals ═══ */

  router.get("/org", (req, res) => {
    const goals = db.prepare("SELECT * FROM org_goals ORDER BY level, created_at").all();
    res.json(goals.map(g => ({
      id: g.id, level: g.level, title: g.title, desc: g.description, progress: g.progress,
    })));
  });

  router.post("/org", (req, res) => {
    const { id, level, title, desc, progress } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });
    db.prepare("INSERT INTO org_goals (id, level, title, description, progress) VALUES (?, ?, ?, ?, ?)")
      .run(id, level, title, desc || "", progress || 0);
    res.status(201).json({ id, level, title, desc: desc || "", progress: progress || 0 });
  });

  router.put("/org/:id", (req, res) => {
    const { id } = req.params;
    const { level, title, desc, progress } = req.body;
    db.prepare("UPDATE org_goals SET level = ?, title = ?, description = ?, progress = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
      .run(level, title, desc || "", progress, id);
    res.json({ id, level, title, desc: desc || "", progress });
  });

  router.delete("/org/:id", (req, res) => {
    db.prepare("DELETE FROM org_goals WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  /* ═══ Personal Goals ═══ */

  function getFullPersonalGoal(goalId) {
    const g = db.prepare("SELECT * FROM personal_goals WHERE id = ?").get(goalId);
    if (!g) return null;
    const krs = db.prepare("SELECT key_result FROM personal_goal_key_results WHERE goal_id = ? ORDER BY id").all(goalId).map(r => r.key_result);
    return {
      id: g.id, memberId: g.member_id, period: g.period,
      title: g.title, desc: g.description, progress: g.progress,
      keyResults: krs,
    };
  }

  router.get("/personal", (req, res) => {
    const goals = db.prepare("SELECT id FROM personal_goals ORDER BY member_id, period, created_at").all();
    res.json(goals.map(g => getFullPersonalGoal(g.id)).filter(Boolean));
  });

  router.post("/personal", (req, res) => {
    const { id, memberId, period, title, desc, progress, keyResults = [] } = req.body;
    if (!id || !title) return res.status(400).json({ error: "id and title required" });
    const tx = db.transaction(() => {
      db.prepare("INSERT INTO personal_goals (id, member_id, period, title, description, progress) VALUES (?, ?, ?, ?, ?, ?)")
        .run(id, memberId, period, title, desc || "", progress || 0);
      const insKR = db.prepare("INSERT INTO personal_goal_key_results (goal_id, key_result) VALUES (?, ?)");
      for (const kr of keyResults) insKR.run(id, kr);
    });
    tx();
    res.status(201).json(getFullPersonalGoal(id));
  });

  router.put("/personal/:id", (req, res) => {
    const { id } = req.params;
    const { memberId, period, title, desc, progress, keyResults = [] } = req.body;
    const tx = db.transaction(() => {
      db.prepare("UPDATE personal_goals SET member_id = ?, period = ?, title = ?, description = ?, progress = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
        .run(memberId, period, title, desc || "", progress, id);
      db.prepare("DELETE FROM personal_goal_key_results WHERE goal_id = ?").run(id);
      const insKR = db.prepare("INSERT INTO personal_goal_key_results (goal_id, key_result) VALUES (?, ?)");
      for (const kr of keyResults) insKR.run(id, kr);
    });
    tx();
    res.json(getFullPersonalGoal(id));
  });

  router.delete("/personal/:id", (req, res) => {
    db.prepare("DELETE FROM personal_goals WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  return router;
};
