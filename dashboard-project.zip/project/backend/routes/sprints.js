const express = require("express");
const router = express.Router();

module.exports = function (db) {
  // ── Ensure tables ──
  db.exec(`
    CREATE TABLE IF NOT EXISTS sprints (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      goal TEXT DEFAULT '',
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'planning',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sprint_tasks (
      sprint_id TEXT NOT NULL,
      task_id TEXT NOT NULL,
      story_points INTEGER DEFAULT 0,
      PRIMARY KEY (sprint_id, task_id),
      FOREIGN KEY (sprint_id) REFERENCES sprints(id) ON DELETE CASCADE,
      FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS burndown_snapshots (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sprint_id TEXT NOT NULL,
      snapshot_date TEXT NOT NULL,
      total_points INTEGER NOT NULL DEFAULT 0,
      remaining_points INTEGER NOT NULL DEFAULT 0,
      completed_points INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (sprint_id) REFERENCES sprints(id) ON DELETE CASCADE,
      UNIQUE(sprint_id, snapshot_date)
    );
  `);

  // ── Helpers ──
  function getFullSprint(id) {
    const s = db.prepare("SELECT * FROM sprints WHERE id = ?").get(id);
    if (!s) return null;
    const taskRows = db.prepare(`
      SELECT st.task_id, st.story_points, t.title, t.column_status, t.priority
      FROM sprint_tasks st JOIN tasks t ON st.task_id = t.id
      WHERE st.sprint_id = ?
    `).all(id);
    const tasks = taskRows.map(r => ({
      id: r.task_id, title: r.title, column: r.column_status,
      priority: r.priority, points: r.story_points,
    }));
    const totalPoints = tasks.reduce((s, t) => s + t.points, 0);
    const completedPoints = tasks.filter(t => t.column === "done").reduce((s, t) => s + t.points, 0);
    return {
      id: s.id, name: s.name, goal: s.goal,
      startDate: s.start_date, endDate: s.end_date,
      status: s.status, tasks, totalPoints, completedPoints,
    };
  }

  function takeDailySnapshot(sprintId) {
    const sprint = getFullSprint(sprintId);
    if (!sprint) return;
    const today = new Date().toISOString().slice(0, 10);
    const remaining = sprint.totalPoints - sprint.completedPoints;
    db.prepare(`INSERT OR REPLACE INTO burndown_snapshots (sprint_id, snapshot_date, total_points, remaining_points, completed_points) VALUES (?, ?, ?, ?, ?)`)
      .run(sprintId, today, sprint.totalPoints, remaining, sprint.completedPoints);
  }

  // GET /api/sprints
  router.get("/", (req, res) => {
    const sprints = db.prepare("SELECT id FROM sprints ORDER BY start_date DESC").all();
    res.json(sprints.map(s => getFullSprint(s.id)).filter(Boolean));
  });

  // GET /api/sprints/:id
  router.get("/:id", (req, res) => {
    const sprint = getFullSprint(req.params.id);
    if (!sprint) return res.status(404).json({ error: "Sprint not found" });
    res.json(sprint);
  });

  // POST /api/sprints
  router.post("/", (req, res) => {
    const { id, name, goal, startDate, endDate, status } = req.body;
    if (!id || !name || !startDate || !endDate) return res.status(400).json({ error: "id, name, startDate, endDate required" });
    db.prepare("INSERT INTO sprints (id, name, goal, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, ?)")
      .run(id, name, goal || "", startDate, endDate, status || "planning");
    res.status(201).json(getFullSprint(id));
  });

  // PUT /api/sprints/:id
  router.put("/:id", (req, res) => {
    const { id } = req.params;
    const { name, goal, startDate, endDate, status } = req.body;
    db.prepare("UPDATE sprints SET name=?, goal=?, start_date=?, end_date=?, status=? WHERE id=?")
      .run(name, goal || "", startDate, endDate, status, id);
    if (status === "active") takeDailySnapshot(id);
    res.json(getFullSprint(id));
  });

  // DELETE /api/sprints/:id
  router.delete("/:id", (req, res) => {
    db.prepare("DELETE FROM sprints WHERE id = ?").run(req.params.id);
    res.json({ deleted: req.params.id });
  });

  // POST /api/sprints/:id/tasks — add task to sprint with story points
  router.post("/:id/tasks", (req, res) => {
    const { id } = req.params;
    const { taskId, points } = req.body;
    if (!taskId) return res.status(400).json({ error: "taskId required" });
    db.prepare("INSERT OR REPLACE INTO sprint_tasks (sprint_id, task_id, story_points) VALUES (?, ?, ?)")
      .run(id, taskId, points || 0);
    takeDailySnapshot(id);
    res.json(getFullSprint(id));
  });

  // DELETE /api/sprints/:id/tasks/:taskId — remove task from sprint
  router.delete("/:id/tasks/:taskId", (req, res) => {
    db.prepare("DELETE FROM sprint_tasks WHERE sprint_id = ? AND task_id = ?")
      .run(req.params.id, req.params.taskId);
    takeDailySnapshot(req.params.id);
    res.json(getFullSprint(req.params.id));
  });

  // PUT /api/sprints/:id/tasks/:taskId/points — update story points
  router.put("/:id/tasks/:taskId/points", (req, res) => {
    const { points } = req.body;
    db.prepare("UPDATE sprint_tasks SET story_points = ? WHERE sprint_id = ? AND task_id = ?")
      .run(points || 0, req.params.id, req.params.taskId);
    takeDailySnapshot(req.params.id);
    res.json(getFullSprint(req.params.id));
  });

  // GET /api/sprints/:id/burndown — get burndown chart data
  router.get("/:id/burndown", (req, res) => {
    const sprint = db.prepare("SELECT * FROM sprints WHERE id = ?").get(req.params.id);
    if (!sprint) return res.status(404).json({ error: "Sprint not found" });

    const snapshots = db.prepare("SELECT * FROM burndown_snapshots WHERE sprint_id = ? ORDER BY snapshot_date")
      .all(req.params.id);

    // Calculate ideal burndown line
    const start = new Date(sprint.start_date);
    const end = new Date(sprint.end_date);
    const totalDays = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    const totalPoints = snapshots.length > 0 ? snapshots[0].total_points : 0;

    const ideal = [];
    for (let i = 0; i <= totalDays; i++) {
      const d = new Date(start); d.setDate(d.getDate() + i);
      ideal.push({
        date: d.toISOString().slice(0, 10),
        points: Math.round(totalPoints * (1 - i / totalDays)),
      });
    }

    res.json({
      sprintId: req.params.id,
      startDate: sprint.start_date,
      endDate: sprint.end_date,
      totalPoints,
      ideal,
      actual: snapshots.map(s => ({
        date: s.snapshot_date,
        remaining: s.remaining_points,
        completed: s.completed_points,
      })),
    });
  });

  // POST /api/sprints/:id/snapshot — manually trigger a snapshot
  router.post("/:id/snapshot", (req, res) => {
    takeDailySnapshot(req.params.id);
    res.json({ status: "snapshot taken" });
  });

  return router;
};
