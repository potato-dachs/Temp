const express = require("express");
const router = express.Router();

module.exports = function (db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS token_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sprint_id TEXT NOT NULL,
      agent_id TEXT NOT NULL,
      action TEXT DEFAULT '',
      input_tokens INTEGER DEFAULT 0,
      output_tokens INTEGER DEFAULT 0,
      tool_calls INTEGER DEFAULT 0,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // POST /api/tokens/log — log token usage for a sprint action
  router.post("/log", (req, res) => {
    const { sprintId, agentId, action, inputTokens, outputTokens, toolCalls } = req.body;
    db.prepare("INSERT INTO token_usage (sprint_id, agent_id, action, input_tokens, output_tokens, tool_calls) VALUES (?, ?, ?, ?, ?, ?)")
      .run(sprintId || "", agentId || "", action || "", inputTokens || 0, outputTokens || 0, toolCalls || 0);
    res.json({ status: "logged" });
  });

  // GET /api/tokens/sprint/:sprintId — get total usage for a sprint
  router.get("/sprint/:sprintId", (req, res) => {
    const rows = db.prepare("SELECT * FROM token_usage WHERE sprint_id = ? ORDER BY timestamp").all(req.params.sprintId);
    const totalInput = rows.reduce((s, r) => s + r.input_tokens, 0);
    const totalOutput = rows.reduce((s, r) => s + r.output_tokens, 0);
    const totalTools = rows.reduce((s, r) => s + r.tool_calls, 0);
    const byAgent = {};
    for (const r of rows) {
      if (!byAgent[r.agent_id]) byAgent[r.agent_id] = { input: 0, output: 0, tools: 0 };
      byAgent[r.agent_id].input += r.input_tokens;
      byAgent[r.agent_id].output += r.output_tokens;
      byAgent[r.agent_id].tools += r.tool_calls;
    }
    res.json({
      sprintId: req.params.sprintId,
      totalTokens: totalInput + totalOutput,
      totalInput, totalOutput, totalTools,
      byAgent,
      entries: rows.length,
    });
  });

  // GET /api/tokens/summary — get usage summary across all sprints
  router.get("/summary", (req, res) => {
    const rows = db.prepare(`
      SELECT sprint_id, SUM(input_tokens) as input, SUM(output_tokens) as output, SUM(tool_calls) as tools
      FROM token_usage GROUP BY sprint_id ORDER BY MIN(timestamp)
    `).all();
    res.json(rows.map(r => ({
      sprintId: r.sprint_id,
      totalTokens: r.input + r.output,
      input: r.input, output: r.output, tools: r.tools,
    })));
  });

  return router;
};
