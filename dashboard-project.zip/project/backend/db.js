const Database = require("better-sqlite3");
const path = require("path");

const DB_PATH = path.join(__dirname, "dashboard.db");

function initDB() {
  const db = new Database(DB_PATH);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS members (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      initials TEXT NOT NULL,
      color TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS tasks (
      id TEXT PRIMARY KEY,
      column_status TEXT NOT NULL DEFAULT 'backlog',
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      priority TEXT NOT NULL DEFAULT 'medium',
      created_date TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS task_assignees (
      task_id TEXT NOT NULL,
      member_id TEXT NOT NULL,
      PRIMARY KEY (task_id, member_id),
      FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
      FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS task_tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      task_id TEXT NOT NULL,
      tag TEXT NOT NULL,
      FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS org_goals (
      id TEXT PRIMARY KEY,
      level TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      progress INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS personal_goals (
      id TEXT PRIMARY KEY,
      member_id TEXT NOT NULL,
      period TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      progress INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS personal_goal_key_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      goal_id TEXT NOT NULL,
      key_result TEXT NOT NULL,
      FOREIGN KEY (goal_id) REFERENCES personal_goals(id) ON DELETE CASCADE
    );
  `);

  // Seed members if empty
  const memberCount = db.prepare("SELECT COUNT(*) as cnt FROM members").get();
  if (memberCount.cnt === 0) {
    const insertMember = db.prepare("INSERT INTO members (id, name, initials, color) VALUES (?, ?, ?, ?)");
    const members = [
      ["m1", "Yuki T.", "YT", "#0052cc"],
      ["m2", "Kenji S.", "KS", "#ff8b00"],
      ["m3", "Sakura M.", "SM", "#6554c0"],
      ["m4", "Taro H.", "TH", "#00875a"],
    ];
    const tx = db.transaction(() => { for (const m of members) insertMember.run(...m); });
    tx();
  }

  // Seed tasks if empty
  const taskCount = db.prepare("SELECT COUNT(*) as cnt FROM tasks").get();
  if (taskCount.cnt === 0) {
    const insertTask = db.prepare("INSERT INTO tasks (id, column_status, title, description, priority, created_date) VALUES (?, ?, ?, ?, ?, ?)");
    const insertAssignee = db.prepare("INSERT INTO task_assignees (task_id, member_id) VALUES (?, ?)");
    const insertTag = db.prepare("INSERT INTO task_tags (task_id, tag) VALUES (?, ?)");

    const tasks = [
      { id: "DASH-1", col: "todo", title: "UIデザインの作成", desc: "ダッシュボードのワイヤーフレーム作成", pri: "high", date: "2026-05-10", assignees: ["m1", "m3"], tags: ["デザイン"] },
      { id: "DASH-2", col: "inprogress", title: "APIエンドポイント設計", desc: "RESTful API仕様書のドラフト", pri: "medium", date: "2026-05-09", assignees: ["m2"], tags: ["バックエンド"] },
      { id: "DASH-3", col: "review", title: "認証フローの実装", desc: "OAuth2.0ベースの認証機能", pri: "high", date: "2026-05-08", assignees: ["m4", "m2"], tags: ["セキュリティ"] },
      { id: "DASH-4", col: "done", title: "プロジェクト初期設定", desc: "リポジトリとCI/CDの構築", pri: "low", date: "2026-05-06", assignees: ["m4"], tags: ["インフラ"] },
      { id: "DASH-5", col: "backlog", title: "パフォーマンス最適化", desc: "Lighthouseスコア90+を目標に", pri: "medium", date: "2026-05-11", assignees: [], tags: ["最適化"] },
      { id: "DASH-6", col: "todo", title: "通知システムの設計", desc: "リアルタイム通知の仕組み検討", pri: "low", date: "2026-05-11", assignees: ["m1"], tags: ["機能"] },
      { id: "DASH-7", col: "inprogress", title: "データベーススキーマ設計", desc: "正規化とインデックス計画", pri: "high", date: "2026-05-07", assignees: ["m2", "m4"], tags: ["バックエンド"] },
    ];

    const tx = db.transaction(() => {
      for (const t of tasks) {
        insertTask.run(t.id, t.col, t.title, t.desc, t.pri, t.date);
        for (const a of t.assignees) insertAssignee.run(t.id, a);
        for (const tag of t.tags) insertTag.run(t.id, tag);
      }
    });
    tx();
  }

  // Seed org goals if empty
  const orgCount = db.prepare("SELECT COUNT(*) as cnt FROM org_goals").get();
  if (orgCount.cnt === 0) {
    const insertOG = db.prepare("INSERT INTO org_goals (id, level, title, description, progress) VALUES (?, ?, ?, ?, ?)");
    const goals = [
      ["og1", "company", "売上前年比120%達成", "国内外の売上拡大と新規事業の立ち上げ", 35],
      ["og2", "company", "顧客満足度NPS 50+", "サポート体制強化とプロダクト品質向上", 60],
      ["og3", "division", "プロダクト開発スピード2倍", "CI/CD導入とアジャイル推進", 45],
      ["og4", "division", "エンジニア採用30名", "新卒・中途あわせた採用計画実行", 20],
      ["og5", "dept", "フロントエンド刷新完了", "React移行プロジェクトの完遂", 70],
      ["og6", "dept", "テストカバレッジ80%", "単体・結合テストの網羅率向上", 55],
      ["og7", "section", "デザインシステムv2リリース", "コンポーネントライブラリの整備", 40],
      ["og8", "group", "Sprint velocity 20%改善", "ボトルネック分析と改善施策の実行", 30],
    ];
    const tx = db.transaction(() => { for (const g of goals) insertOG.run(...g); });
    tx();
  }

  // Seed personal goals if empty
  const pgCount = db.prepare("SELECT COUNT(*) as cnt FROM personal_goals").get();
  if (pgCount.cnt === 0) {
    const insertPG = db.prepare("INSERT INTO personal_goals (id, member_id, period, title, description, progress) VALUES (?, ?, ?, ?, ?, ?)");
    const insertKR = db.prepare("INSERT INTO personal_goal_key_results (goal_id, key_result) VALUES (?, ?)");

    const pgs = [
      { id: "pg1", m: "m1", p: "annual", t: "リードデザイナーへの昇格", d: "デザインチームのリードを担当", pr: 50, kr: ["デザインレビュー主導 月4回", "メンバー育成 2名"] },
      { id: "pg2", m: "m1", p: "q1", t: "デザインシステム基盤構築", d: "Figmaトークン整備", pr: 80, kr: ["カラートークン定義完了", "タイポグラフィ定義完了"] },
      { id: "pg3", m: "m1", p: "q2", t: "コンポーネント50種作成", d: "UIコンポーネントの量産", pr: 30, kr: ["基本コンポーネント30種", "複合コンポーネント20種"] },
      { id: "pg4", m: "m2", p: "annual", t: "バックエンドアーキテクト認定", d: "システム設計力の向上", pr: 40, kr: ["AWS SAA取得", "設計レビュー 月2回主導"] },
      { id: "pg5", m: "m2", p: "q1", t: "API基盤のリファクタリング", d: "レスポンスタイム30%改善", pr: 90, kr: ["N+1クエリ解消", "キャッシュ戦略導入"] },
      { id: "pg6", m: "m3", p: "annual", t: "プロジェクトマネジメント力強化", d: "PMP取得とチーム運営", pr: 25, kr: ["PMP試験合格", "2プロジェクト同時PMを経験"] },
      { id: "pg7", m: "m4", p: "annual", t: "インフラ自動化率90%", d: "IaCとCI/CDの全面展開", pr: 65, kr: ["Terraform化 全環境", "デプロイ自動化率90%"] },
      { id: "pg8", m: "m4", p: "q2", t: "Kubernetes移行完了", d: "本番環境のK8s移行", pr: 15, kr: ["ステージング環境構築", "本番カナリアリリース"] },
    ];

    const tx = db.transaction(() => {
      for (const g of pgs) {
        insertPG.run(g.id, g.m, g.p, g.t, g.d, g.pr);
        for (const kr of g.kr) insertKR.run(g.id, kr);
      }
    });
    tx();
  }

  return db;
}

module.exports = { initDB };
