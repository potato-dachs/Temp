import { useState, useRef, useMemo, useEffect, useCallback } from "react";

/*
 * ┌────────────────────────────────────────────────────────┐
 * │  AI-Driven Project Management Dashboard                │
 * │  Single-file React component (~2900 lines)             │
 * ├────────────────────────────────────────────────────────┤
 * │  Table of Contents:                                    │
 * │                                                        │
 * │  §1  API Layer .......................... line ~15      │
 * │  §2  Theme & Constants ................. line ~70      │
 * │  §3  Fallback Data ..................... line ~100      │
 * │  §4  Navigation & Features ............. line ~170      │
 * │  §5  ID Generators ..................... line ~215      │
 * │  §6  Shared Components ................. line ~225      │
 * │  §7  Shared Utilities .................. line ~240      │
 * │  §8  Page Components:                                  │
 * │      - TaskCard / BoardCol ............. line ~250      │
 * │      - CalendarView .................... line ~310      │
 * │      - TaskModal ....................... line ~475      │
 * │      - GoalModal / GoalsPage ........... line ~560      │
 * │      - Sidebar ......................... line ~730      │
 * │      - AIPage .......................... line ~760      │
 * │      - BacklogPage ..................... line ~965      │
 * │      - HomePage ........................ line ~1140     │
 * │      - SprintPage / BurndownChart ...... line ~1375     │
 * │      - RetroPage ....................... line ~1680     │
 * │      - KnowledgePage ................... line ~1875     │
 * │      - ProjectManager .................. line ~2120     │
 * │      - SettingsPage .................... line ~2180     │
 * │  §9  Main Dashboard Component .......... line ~2520     │
 * └────────────────────────────────────────────────────────┘
 */

/* ═══ §1 API Layer ═══ */
const API = "/api";
async function req(path, opts = {}) {
  try {
    const r = await fetch(`${API}${path}`, { headers: { "Content-Type": "application/json" }, ...opts });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } catch (e) { console.warn("API error:", e.message); return null; }
}
const api = {
  getTasks:    () => req("/tasks"),
  createTask:  (t) => req("/tasks", { method: "POST", body: JSON.stringify(t) }),
  updateTask:  (id, t) => req(`/tasks/${id}`, { method: "PUT", body: JSON.stringify(t) }),
  moveTask:    (id, col) => req(`/tasks/${id}/column`, { method: "PATCH", body: JSON.stringify({ column: col }) }),
  deleteTask:  (id) => req(`/tasks/${id}`, { method: "DELETE" }),
  getOrgGoals:       () => req("/goals/org"),
  createOrgGoal:     (g) => req("/goals/org", { method: "POST", body: JSON.stringify(g) }),
  updateOrgGoal:     (id, g) => req(`/goals/org/${id}`, { method: "PUT", body: JSON.stringify(g) }),
  deleteOrgGoal:     (id) => req(`/goals/org/${id}`, { method: "DELETE" }),
  getPersonalGoals:  () => req("/goals/personal"),
  createPersonalGoal:(g) => req("/goals/personal", { method: "POST", body: JSON.stringify(g) }),
  updatePersonalGoal:(id, g) => req(`/goals/personal/${id}`, { method: "PUT", body: JSON.stringify(g) }),
  deletePersonalGoal:(id) => req(`/goals/personal/${id}`, { method: "DELETE" }),
  getMembers:        () => req("/members"),
  createMember:      (m) => req("/members", { method: "POST", body: JSON.stringify(m) }),
  deleteMember:      (id) => req(`/members/${id}`, { method: "DELETE" }),
  exportBackup:      () => req("/backup/export"),
  restoreBackup:     (data) => req("/backup/restore", { method: "POST", body: JSON.stringify(data) }),
  saveBackup:        () => req("/backup/save", { method: "POST" }),
  listBackups:       () => req("/backup/list"),
  restoreFromFile:   (filename) => req("/backup/restore-file", { method: "POST", body: JSON.stringify({ filename }) }),
  deleteBackupFile:  (filename) => req(`/backup/${filename}`, { method: "DELETE" }),
  getKnowledge:      () => req("/knowledge"),
  getArticle:        (id) => req(`/knowledge/${id}`),
  createArticle:     (a) => req("/knowledge", { method: "POST", body: JSON.stringify(a) }),
  updateArticle:     (id, a) => req(`/knowledge/${id}`, { method: "PUT", body: JSON.stringify(a) }),
  deleteArticle:     (id) => req(`/knowledge/${id}`, { method: "DELETE" }),
  getSprints:        () => req("/sprints"),
  createSprint:      (s) => req("/sprints", { method: "POST", body: JSON.stringify(s) }),
  updateSprint:      (id, s) => req(`/sprints/${id}`, { method: "PUT", body: JSON.stringify(s) }),
  deleteSprint:      (id) => req(`/sprints/${id}`, { method: "DELETE" }),
  addTaskToSprint:   (sid, taskId, points) => req(`/sprints/${sid}/tasks`, { method: "POST", body: JSON.stringify({ taskId, points }) }),
  removeTaskFromSprint: (sid, tid) => req(`/sprints/${sid}/tasks/${tid}`, { method: "DELETE" }),
  updateTaskPoints:  (sid, tid, points) => req(`/sprints/${sid}/tasks/${tid}/points`, { method: "PUT", body: JSON.stringify({ points }) }),
  getBurndown:       (sid) => req(`/sprints/${sid}/burndown`),
  takeSnapshot:      (sid) => req(`/sprints/${sid}/snapshot`, { method: "POST" }),
  getEpics:          () => req("/epics"),
  createEpic:        (e) => req("/epics", { method: "POST", body: JSON.stringify(e) }),
  updateEpic:        (id, e) => req(`/epics/${id}`, { method: "PUT", body: JSON.stringify(e) }),
  deleteEpic:        (id) => req(`/epics/${id}`, { method: "DELETE" }),
  reorderTasks:      (orders) => req("/tasks/reorder/bulk", { method: "PUT", body: JSON.stringify({ orders }) }),
  setTaskEpic:       (id, epicId) => req(`/tasks/${id}/epic`, { method: "PATCH", body: JSON.stringify({ epicId }) }),
  quickAssign:       (id, assignees) => req(`/tasks/${id}/assignees`, { method: "PATCH", body: JSON.stringify({ assignees }) }),
  addComment:        (id, author, content) => req(`/tasks/${id}/comments`, { method: "POST", body: JSON.stringify({ author, content }) }),
  getActivity:       (id) => req(`/tasks/${id}/activity`),
  getConversations:  () => req("/ai/conversations"),
  createConversation:(c) => req("/ai/conversations", { method: "POST", body: JSON.stringify(c) }),
  getMessages:       (convId) => req(`/ai/conversations/${convId}/messages`),
  sendMessage:       (convId, msg) => req(`/ai/conversations/${convId}/messages`, { method: "POST", body: JSON.stringify(msg) }),
  deleteConversation:(id) => req(`/ai/conversations/${id}`, { method: "DELETE" }),
  agentChat:         (convId, message, projectId) => req("/ai/agent/chat", { method: "POST", body: JSON.stringify({ conversationId: convId, message, projectId }) }),
  getRetros:         () => req("/retros"),
  createRetro:       (r) => req("/retros", { method: "POST", body: JSON.stringify(r) }),
  updateRetro:       (id, r) => req(`/retros/${id}`, { method: "PUT", body: JSON.stringify(r) }),
  deleteRetro:       (id) => req(`/retros/${id}`, { method: "DELETE" }),
};

/* ═══ §2 Theme & Constants ═══ */
const C = {
  bg: "#f4f5f7", surface: "#ffffff",
  sidebarBg: "#0c2340", sidebarHover: "#153052", sidebarActive: "#1d3f6e",
  sidebarText: "rgba(255,255,255,0.72)", sidebarTextActive: "#fff", sidebarAccent: "#579dff",
  colBg: "#f0f1f4", card: "#ffffff", cardHover: "#f8f9fb",
  border: "#dfe1e6", borderFocus: "#4c9aff",
  text: "#172b4d", textMid: "#44546f", textLight: "#626f86", textVLight: "#8993a4",
  accent: "#0052cc", accentLight: "#deebff",
  danger: "#de350b", dangerBg: "#ffebe6",
  success: "#00875a", successBg: "#e3fcef",
  warning: "#ff8b00", warningBg: "#fffae6",
  purple: "#6554c0", purpleBg: "#eae6ff",
  teal: "#00b8d9", tealBg: "#e6fcff",
};

const PRIORITY = {
  high:   { color: C.danger,  bg: C.dangerBg,  icon: "↑", label: "High" },
  medium: { color: C.warning, bg: C.warningBg, icon: "→", label: "Medium" },
  low:    { color: C.success, bg: C.successBg, icon: "↓", label: "Low" },
};

const FALLBACK_MEMBERS = [
  { id: "m1", name: "Yuki T.",   initials: "YT", color: "#0052cc" },
  { id: "m2", name: "Kenji S.",  initials: "KS", color: "#ff8b00" },
  { id: "m3", name: "Sakura M.", initials: "SM", color: "#6554c0" },
  { id: "m4", name: "Taro H.",   initials: "TH", color: "#00875a" },
];
const MEMBER_COLORS = ["#0052cc", "#ff8b00", "#6554c0", "#00875a", "#de350b", "#00b8d9", "#ff5630", "#36b37e", "#8777d9", "#ff991f"];

/* ═══ Projects ═══ */
const PROJECT_COLORS = ["#0052cc", "#6554c0", "#00875a", "#ff8b00", "#de350b", "#00b8d9"];
const FALLBACK_PROJECTS = [
  { id: "proj-1", name: "Dashboard開発", color: "#0052cc", description: "プロジェクト管理ダッシュボードの開発" },
  { id: "proj-2", name: "モバイルアプリ", color: "#6554c0", description: "iOS/Androidアプリの開発" },
];

const COLUMNS = [
  { id: "backlog", title: "BACKLOG" }, { id: "todo", title: "TO DO" },
  { id: "inprogress", title: "IN PROGRESS" }, { id: "review", title: "IN REVIEW" },
  { id: "done", title: "DONE" },
];
const COL_COLORS = { backlog: "#8993a4", todo: "#0052cc", inprogress: "#ff8b00", review: "#6554c0", done: "#00875a" };

/* ═══ §3 Fallback Data ═══ */
const FALLBACK_EPICS = [
  { id: "ep-1", name: "認証基盤", color: "#de350b", description: "ログイン・認証関連の機能群", sortOrder: 0, projectId: "proj-1" },
  { id: "ep-2", name: "UI刷新", color: "#6554c0", description: "フロントエンドの全面リニューアル", sortOrder: 1, projectId: "proj-1" },
  { id: "ep-3", name: "インフラ整備", color: "#00875a", description: "CI/CD・監視・デプロイ基盤", sortOrder: 2, projectId: "proj-1" },
];
const FALLBACK_TASKS = [
  { id: "DASH-1", column: "todo",       title: "UIデザインの作成",       desc: "ダッシュボードのワイヤーフレーム作成", priority: "high",   assignees: ["m1","m3"], tags: ["デザイン"],     created: "2026-05-10", dueDate: "2026-05-16", epicId: "ep-2", priorityOrder: 0, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-2", column: "inprogress", title: "APIエンドポイント設計",   desc: "RESTful API仕様書のドラフト",       priority: "medium", assignees: ["m2"],     tags: ["バックエンド"], created: "2026-05-09", dueDate: "2026-05-18", epicId: "",     priorityOrder: 1, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-3", column: "review",     title: "認証フローの実装",       desc: "OAuth2.0ベースの認証機能",          priority: "high",   assignees: ["m4","m2"], tags: ["セキュリティ"], created: "2026-05-08", dueDate: "2026-05-15", epicId: "ep-1", priorityOrder: 2, projectId: "proj-1", comments: [{ id: 1, author: "Taro H.", content: "OAuth2.0のライブラリ選定完了。passport.js を使用", createdAt: "2026-05-09T10:00:00" }], activity: [{ id: 1, actor: "system", action: "status_changed", detail: "inprogress → review", createdAt: "2026-05-12T14:00:00" }] },
  { id: "DASH-4", column: "done",       title: "プロジェクト初期設定",    desc: "リポジトリとCI/CDの構築",           priority: "low",    assignees: ["m4"],     tags: ["インフラ"],     created: "2026-05-06", dueDate: "",           epicId: "ep-3", priorityOrder: 3, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-5", column: "backlog",    title: "パフォーマンス最適化",    desc: "Lighthouseスコア90+を目標に",       priority: "medium", assignees: [],         tags: ["最適化"],       created: "2026-05-11", dueDate: "2026-05-25", epicId: "",     priorityOrder: 4, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-6", column: "todo",       title: "通知システムの設計",      desc: "リアルタイム通知の仕組み検討",       priority: "low",    assignees: ["m1"],     tags: ["機能"],         created: "2026-05-11", dueDate: "",           epicId: "ep-2", priorityOrder: 5, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-7", column: "inprogress", title: "データベーススキーマ設計", desc: "正規化とインデックス計画",           priority: "high",   assignees: ["m2","m4"], tags: ["バックエンド"], created: "2026-05-07", dueDate: "2026-05-14", epicId: "",     priorityOrder: 6, projectId: "proj-1", comments: [], activity: [] },
  { id: "DASH-8", column: "todo",       title: "ログイン画面UI", desc: "モバイルアプリのログイン画面実装", priority: "high", assignees: ["m3"], tags: ["UI"], created: "2026-05-12", dueDate: "2026-05-20", epicId: "", priorityOrder: 0, projectId: "proj-2", comments: [], activity: [] },
  { id: "DASH-9", column: "backlog",    title: "プッシュ通知実装", desc: "FCM連携", priority: "medium", assignees: ["m2"], tags: ["機能"], created: "2026-05-12", dueDate: "", epicId: "", priorityOrder: 1, projectId: "proj-2", comments: [], activity: [] },
];
const FALLBACK_ORG_GOALS = [
  { id: "og1", level: "company",  title: "売上前年比120%達成", desc: "国内外の売上拡大と新規事業の立ち上げ", progress: 35 },
  { id: "og2", level: "company",  title: "顧客満足度NPS 50+", desc: "サポート体制強化とプロダクト品質向上", progress: 60 },
  { id: "og3", level: "division", title: "プロダクト開発スピード2倍", desc: "CI/CD導入とアジャイル推進", progress: 45 },
  { id: "og4", level: "division", title: "エンジニア採用30名", desc: "新卒・中途あわせた採用計画実行", progress: 20 },
  { id: "og5", level: "dept",     title: "フロントエンド刷新完了", desc: "React移行プロジェクトの完遂", progress: 70 },
  { id: "og6", level: "dept",     title: "テストカバレッジ80%", desc: "単体・結合テストの網羅率向上", progress: 55 },
  { id: "og7", level: "section",  title: "デザインシステムv2リリース", desc: "コンポーネントライブラリの整備", progress: 40 },
  { id: "og8", level: "group",    title: "Sprint velocity 20%改善", desc: "ボトルネック分析と改善施策の実行", progress: 30 },
];
const FALLBACK_PERSONAL_GOALS = [
  { id: "pg1", memberId: "m1", period: "annual", title: "リードデザイナーへの昇格", desc: "デザインチームのリードを担当", progress: 50, keyResults: ["デザインレビュー主導 月4回", "メンバー育成 2名"] },
  { id: "pg2", memberId: "m1", period: "q1", title: "デザインシステム基盤構築", desc: "Figmaトークン整備", progress: 80, keyResults: ["カラートークン定義完了", "タイポグラフィ定義完了"] },
  { id: "pg3", memberId: "m1", period: "q2", title: "コンポーネント50種作成", desc: "UIコンポーネントの量産", progress: 30, keyResults: ["基本コンポーネント30種", "複合コンポーネント20種"] },
  { id: "pg4", memberId: "m2", period: "annual", title: "バックエンドアーキテクト認定", desc: "システム設計力の向上", progress: 40, keyResults: ["AWS SAA取得", "設計レビュー 月2回主導"] },
  { id: "pg5", memberId: "m2", period: "q1", title: "API基盤のリファクタリング", desc: "レスポンスタイム30%改善", progress: 90, keyResults: ["N+1クエリ解消", "キャッシュ戦略導入"] },
  { id: "pg6", memberId: "m3", period: "annual", title: "プロジェクトマネジメント力強化", desc: "PMP取得とチーム運営", progress: 25, keyResults: ["PMP試験合格", "2プロジェクト同時PMを経験"] },
  { id: "pg7", memberId: "m4", period: "annual", title: "インフラ自動化率90%", desc: "IaCとCI/CDの全面展開", progress: 65, keyResults: ["Terraform化 全環境", "デプロイ自動化率90%"] },
  { id: "pg8", memberId: "m4", period: "q2", title: "Kubernetes移行完了", desc: "本番環境のK8s移行", progress: 15, keyResults: ["ステージング環境構築", "本番カナリアリリース"] },
];

const ORG_LEVELS = [
  { id: "company",  label: "会社方針",     icon: "🏢", color: "#0052cc", depth: 0 },
  { id: "division", label: "本部方針",     icon: "🏛️", color: "#6554c0", depth: 1 },
  { id: "dept",     label: "部方針",       icon: "🏗️", color: "#00b8d9", depth: 2 },
  { id: "section",  label: "室方針",       icon: "🏠", color: "#ff8b00", depth: 3 },
  { id: "group",    label: "グループ方針", icon: "👥", color: "#00875a", depth: 4 },
];
const PERIODS = [
  { id: "annual", label: "通年目標" },
  { id: "q1", label: "Q1 目標" }, { id: "q2", label: "Q2 目標" },
  { id: "q3", label: "Q3 目標" }, { id: "q4", label: "Q4 目標" },
];


/* ── SVG Icons ── */
const I = {
  board:  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="5" height="14" rx="1"/><rect x="12" y="3" width="5" height="8" rx="1"/></svg>,
  book:   <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 3h12a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V4a1 1 0 011-1z"/><path d="M7 3v14"/><path d="M10 7h4"/><path d="M10 10h4"/></svg>,
  target: <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="10" r="7"/><circle cx="10" cy="10" r="3.5"/><circle cx="10" cy="10" r="0.8" fill="currentColor"/></svg>,
  gear:   <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="10" r="2.2"/><path d="M10 3v1.5M10 15.5V17M17 10h-1.5M4.5 10H3M14.95 5.05l-1.06 1.06M6.11 13.89l-1.06 1.06M14.95 14.95l-1.06-1.06M6.11 6.11L5.05 5.05"/></svg>,
  chevL:  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 3L5 8l5 5"/></svg>,
  chevR:  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3l5 5-5 5"/></svg>,
  chevD:  <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 4.5l3 3 3-3"/></svg>,
  plus:   <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M7 2v10M2 7h10"/></svg>,
  search: <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="5.8" cy="5.8" r="3.8"/><path d="M9 9l3 3"/></svg>,
  cal:    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="12" height="11" rx="1.5"/><path d="M2 6.5h12"/><path d="M5.5 1.5v3M10.5 1.5v3"/></svg>,
  kanban: <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="4" height="12" rx="1"/><rect x="10" y="2" width="4" height="7" rx="1"/></svg>,
  sprint: <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 17V5a2 2 0 012-2h4l2 2h4a2 2 0 012 2v8"/><path d="M7 13l3-3 3 3"/></svg>,
  home:   <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 10l7-7 7 7"/><path d="M5 8v8a1 1 0 001 1h3v-4h2v4h3a1 1 0 001-1V8"/></svg>,
  backlog:<svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h12M4 10h12M4 14h8"/><circle cx="16" cy="14" r="1.5" fill="currentColor"/></svg>,
  retro:  <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 5h14v10H3z"/><path d="M8 5v10M13 5v10"/><path d="M5 8h2M10 8h2M15 8h1"/></svg>,
  ai:     <svg width="20" height="20" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="8" r="4"/><path d="M4 18c0-3.3 2.7-6 6-6s6 2.7 6 6"/><path d="M10 4V2M14 6l1.5-1.5M6 6L4.5 4.5"/></svg>,
};

const ALL_NAV = [
  { id: "home", icon: I.home, label: "ホーム", featureKey: "home", alwaysOn: true },
  { id: "ai", icon: I.ai, label: "AIに依頼", featureKey: "ai" },
  { id: "tasks", icon: I.board, label: "タスク管理", featureKey: "tasks", alwaysOn: true },
  { id: "backlog", icon: I.backlog, label: "バックログ", featureKey: "backlog" },
  { id: "sprints", icon: I.sprint, label: "スプリント", featureKey: "sprints" },
  { id: "retro", icon: I.retro, label: "ふりかえり", featureKey: "retro" },
  { id: "goals", icon: I.target, label: "目標管理", featureKey: "goals", shared: true },
  { id: "knowledge", icon: I.book, label: "ナレッジ", featureKey: "knowledge", shared: true },
];
const NAV_BOTTOM = [{ id: "settings", icon: I.gear, label: "設定" }];

const DEFAULT_FEATURES = {
  home: true, tasks: true, ai: true, backlog: true, sprints: true, retro: true, goals: true, knowledge: true,
};

const FEATURE_DESCRIPTIONS = {
  home: { label: "ホーム", desc: "プロジェクト全体のサマリーダッシュボード", icon: "🏠" },
  ai: { label: "AIに依頼", desc: "AIスクラムチームへの開発依頼・チャット", icon: "🤖" },
  tasks: { label: "タスク管理", desc: "カンバンボード・カレンダーでのタスク管理", icon: "📋" },
  backlog: { label: "バックログ", desc: "優先度管理・エピックによるグルーピング", icon: "📝" },
  sprints: { label: "スプリント", desc: "スプリント計画・バーンダウンチャート", icon: "🏃" },
  retro: { label: "ふりかえり", desc: "KPTベースのレトロスペクティブ・ナレッジ連携", icon: "🔄" },
  goals: { label: "目標管理", desc: "組織方針（会社〜グループ）・個人目標・KR", icon: "🎯" },
  knowledge: { label: "ナレッジ", desc: "チームのナレッジベース・RAG対応構造", icon: "📖" },
};

/* ═══ §5 ID Generators (mutable counters for offline mode) ═══ */
let nextNum = 8;          // task IDs: DASH-N
let goalNextId = 100;     // goal IDs
let memberNextId = 10;    // member IDs
let projectNextId = 10;   // project IDs
let epicNextId = 20;      // epic IDs
let sprintNextId = 10;    // sprint IDs
let retroNextId = 10;     // retro IDs
let retroItemNextId = 100;// retro item IDs
let kbNextId = 100;       // knowledge article IDs

/* ═══ §6 Shared Components ═══ */
function Avatar({ member, size = 24 }) {
  return <div title={member.name} style={{ width: size, height: size, borderRadius: "50%", background: member.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.38, fontWeight: 700, color: "#fff", flexShrink: 0 }}>{member.initials}</div>;
}
function AvatarStack({ ids, size = 22, members = FALLBACK_MEMBERS }) {
  const m = ids.map(i => members.find(x => x.id === i)).filter(Boolean);
  if (!m.length) return <span style={{ fontSize: 11, color: C.textVLight }}>未割当</span>;
  return <div style={{ display: "flex" }}>{m.map((x, i) => <div key={x.id} style={{ marginLeft: i ? -6 : 0, zIndex: m.length - i, border: "2px solid #fff", borderRadius: "50%" }}><Avatar member={x} size={size} /></div>)}</div>;
}
function Lbl({ children }) { return <div style={{ fontSize: 11, fontWeight: 600, color: C.textMid, marginBottom: 4, letterSpacing: 0.4 }}>{children}</div>; }
function ProgressBar({ value, color = C.accent, height = 6, width = "100%" }) {
  return <div style={{ width, height, background: C.border, borderRadius: height, overflow: "hidden" }}><div style={{ height: "100%", width: `${Math.min(100, Math.max(0, value))}%`, background: color, borderRadius: height, transition: "width .3s" }} /></div>;
}

const aBtn = { background: "none", border: "none", cursor: "pointer", fontSize: 12, padding: "1px 3px", borderRadius: 3, color: C.textLight };
const inpStyle = { width: "100%", padding: "8px 10px", borderRadius: 3, border: `2px solid ${C.border}`, background: C.surface, color: C.text, fontSize: 13, outline: "none", boxSizing: "border-box", transition: "border .15s" };
const onFocus = e => (e.target.style.borderColor = C.borderFocus);
const onBlur = e => (e.target.style.borderColor = C.border);

/* ═══ §7 Shared Utilities ═══ */
/** Simple Markdown → HTML renderer (basic subset) */
function renderMd(md) {
  if (!md) return "";
  return md
    .replace(/^### (.+)$/gm, '<h4 style="margin:12px 0 4px;font-size:13px;font-weight:700;color:#172b4d">$1</h4>')
    .replace(/^## (.+)$/gm, '<h3 style="margin:16px 0 6px;font-size:14px;font-weight:700;color:#172b4d">$1</h3>')
    .replace(/^# (.+)$/gm, '<h2 style="margin:0 0 8px;font-size:16px;font-weight:700;color:#172b4d">$1</h2>')
    .replace(/```(\w*)\n([\s\S]*?)```/g, '<pre style="background:#f0f1f4;padding:10px 12px;border-radius:4px;font-size:12px;overflow-x:auto;margin:8px 0"><code>$2</code></pre>')
    .replace(/`([^`]+)`/g, '<code style="background:#f0f1f4;padding:1px 4px;border-radius:2px;font-size:12px">$1</code>')
    .replace(/^\- \[ \] (.+)$/gm, '<div style="display:flex;align-items:center;gap:6px;padding:2px 0"><span style="color:#8993a4">☐</span><span>$1</span></div>')
    .replace(/^\- \[x\] (.+)$/gm, '<div style="display:flex;align-items:center;gap:6px;padding:2px 0"><span style="color:#00875a">☑</span><span style="text-decoration:line-through;color:#8993a4">$1</span></div>')
    .replace(/^\- (.+)$/gm, '<div style="padding:1px 0 1px 12px">• $1</div>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n\n/g, '<div style="height:8px"></div>')
    .replace(/\n/g, '<br/>');
}

/** Reusable filter pill style */
function filterPill(active) {
  return { padding: "3px 10px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: active ? C.accentLight : C.colBg, color: active ? C.accent : C.textLight, display: "flex", alignItems: "center" };
}

/* ═══ §8 Page Components ═══ */

/* ── Task Card ── */
function TaskCard({ task, onEdit, onDelete, drag, members, epics = [], onQuickAssign }) {
  const [hov, setHov] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const p = PRIORITY[task.priority];
  const epic = task.epicId ? epics.find(e => e.id === task.epicId) : null;
  const today = new Date().toISOString().slice(0, 10);
  const isOverdue = task.dueDate && task.dueDate < today && task.column !== "done";
  const isDueSoon = task.dueDate && !isOverdue && task.dueDate <= new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10) && task.column !== "done";
  return (
    <div draggable onDragStart={e => drag.start(e, task.id)} onDragEnd={drag.end}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setShowAssign(false); }}
      style={{ background: hov ? C.cardHover : C.card, borderRadius: 3, padding: "10px 12px", cursor: "grab", boxShadow: hov ? "0 1px 6px rgba(9,30,66,0.25)" : "0 1px 1px rgba(9,30,66,0.13)", border: hov ? `1px solid ${C.borderFocus}` : isOverdue ? `1px solid ${C.danger}` : "1px solid transparent", transition: "box-shadow .15s, border .15s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 11, color: C.accent, fontWeight: 600 }}>{task.id}</span>
          {epic && <span style={{ fontSize: 9, padding: "1px 5px", borderRadius: 2, background: `${epic.color}15`, color: epic.color, fontWeight: 700 }}>{epic.name}</span>}
        </div>
        {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={() => onEdit(task)} style={aBtn}>✏️</button><button onClick={() => onDelete(task.id)} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
      </div>
      <div style={{ fontSize: 13, fontWeight: 500, color: C.text, marginBottom: 6, lineHeight: 1.45 }}>{task.title}</div>
      {task.tags.length > 0 && <div style={{ display: "flex", gap: 4, marginBottom: 8, flexWrap: "wrap" }}>{task.tags.map(t => <span key={t} style={{ fontSize: 10, padding: "1px 6px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600 }}>{t}</span>)}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span title={p.label} style={{ fontSize: 11, fontWeight: 800, color: p.color, width: 18, height: 18, display: "inline-flex", alignItems: "center", justifyContent: "center", background: p.bg, borderRadius: 3 }}>{p.icon}</span>
          {/* Quick assign */}
          <div style={{ position: "relative" }}>
            <div onClick={e => { e.stopPropagation(); if (onQuickAssign) setShowAssign(!showAssign); }} style={{ cursor: onQuickAssign ? "pointer" : "default" }}>
              <AvatarStack ids={task.assignees} members={members} />
            </div>
            {showAssign && onQuickAssign && members && (
              <div style={{ position: "absolute", left: 0, top: "100%", marginTop: 4, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 4, boxShadow: "0 4px 12px rgba(9,30,66,0.2)", zIndex: 100, padding: 4, minWidth: 120 }}>
                {members.map(m => {
                  const assigned = task.assignees.includes(m.id);
                  return <button key={m.id} onClick={e => { e.stopPropagation(); const newA = assigned ? task.assignees.filter(a => a !== m.id) : [...task.assignees, m.id]; onQuickAssign(task.id, newA); }} style={{ display: "flex", alignItems: "center", gap: 6, width: "100%", padding: "4px 8px", border: "none", background: assigned ? C.accentLight : "transparent", cursor: "pointer", borderRadius: 3, fontSize: 11, color: C.text }}><Avatar member={m} size={18} />{m.name}{assigned && <span style={{ marginLeft: "auto", color: C.accent }}>✓</span>}</button>;
                })}
              </div>
            )}
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
          {task.comments?.length > 0 && <span style={{ fontSize: 10, color: C.textVLight }} title={`${task.comments.length}件のコメント`}>💬{task.comments.length}</span>}
          {task.dueDate && <span style={{ fontSize: 10, fontWeight: 600, color: isOverdue ? C.danger : isDueSoon ? C.warning : C.textVLight, background: isOverdue ? C.dangerBg : isDueSoon ? C.warningBg : "transparent", padding: isOverdue || isDueSoon ? "1px 4px" : 0, borderRadius: 2 }}>{task.dueDate.slice(5)}</span>}
          {!task.dueDate && <span style={{ fontSize: 10, color: C.textVLight }}>{task.created}</span>}
        </div>
      </div>
    </div>
  );
}

/* ── Board Column ── */
function BoardCol({ col, tasks, onAdd, onEdit, onDelete, drag, isOver, members, epics, onQuickAssign }) {
  return (
    <div onDragOver={e => { e.preventDefault(); drag.over(col.id); }} onDragLeave={drag.leave} onDrop={e => drag.drop(e, col.id)}
      style={{ flex: "0 0 260px", minWidth: 240, background: isOver ? C.accentLight : C.colBg, borderRadius: 6, display: "flex", flexDirection: "column", transition: "background .15s", border: isOver ? `2px dashed ${C.borderFocus}` : "2px dashed transparent", maxHeight: "100%" }}>
      <div style={{ padding: "10px 12px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.8, color: col.id === "done" ? C.success : C.textLight }}>{col.title}</span>
          <span style={{ fontSize: 10, fontWeight: 700, color: C.textVLight, background: "#dfe1e6", borderRadius: 10, padding: "0 6px", lineHeight: "18px" }}>{tasks.length}</span>
        </div>
        <button onClick={() => onAdd(col.id)} style={{ background: "none", border: "none", cursor: "pointer", color: C.textLight, display: "flex", alignItems: "center", padding: 2 }}>{I.plus}</button>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "4px 6px 8px", display: "flex", flexDirection: "column", gap: 6 }}>
        {tasks.map(t => <TaskCard key={t.id} task={t} onEdit={onEdit} onDelete={onDelete} drag={drag} members={members} epics={epics} onQuickAssign={onQuickAssign} />)}
      </div>
    </div>
  );
}

/* ── Calendar View ── */
const WEEKDAYS = ["月", "火", "水", "木", "金", "土", "日"];
function CalendarView({ tasks, onEdit, onDelete, onAddOnDate }) {
  const [viewDate, setViewDate] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const year = viewDate.getFullYear(), month = viewDate.getMonth();
  const calDays = useMemo(() => {
    let sd = new Date(year, month, 1).getDay(); sd = sd === 0 ? 6 : sd - 1;
    const dim = new Date(year, month + 1, 0).getDate(), pd = new Date(year, month, 0).getDate(), cells = [];
    for (let i = sd - 1; i >= 0; i--) cells.push({ day: pd - i, inMonth: false, date: null });
    for (let d = 1; d <= dim; d++) cells.push({ day: d, inMonth: true, date: `${year}-${String(month + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}` });
    const rem = 7 - (cells.length % 7); if (rem < 7) for (let i = 1; i <= rem; i++) cells.push({ day: i, inMonth: false, date: null });
    return cells;
  }, [year, month]);

  // Build date→cellIndex map
  const dateIndex = useMemo(() => {
    const m = {};
    calDays.forEach((c, i) => { if (c.date) m[c.date] = i; });
    return m;
  }, [calDays]);

  // Build bars: tasks with both created and dueDate get a spanning bar
  const bars = useMemo(() => {
    const rows = []; // each row is an array of bars, bars don't overlap within a row
    const barTasks = tasks.filter(t => t.created && t.dueDate && t.dueDate !== "" && t.created !== t.dueDate).sort((a, b) => a.created.localeCompare(b.created));
    const pointTasks = tasks.filter(t => t.created && (!t.dueDate || t.dueDate === "" || t.created === t.dueDate));

    // Assign bars to rows (simple greedy lane allocation)
    const lanes = [];
    // Include pointTasks as single-day bars
    const allBarItems = [
      ...barTasks.map(t => {
        const si = dateIndex[t.created]; const ei = dateIndex[t.dueDate];
        if (si === undefined && ei === undefined) return null;
        return { task: t, startIdx: si !== undefined ? si : 0, endIdx: ei !== undefined ? ei : calDays.length - 1 };
      }).filter(Boolean),
      ...pointTasks.map(t => {
        const si = dateIndex[t.created];
        if (si === undefined) return null;
        return { task: t, startIdx: si, endIdx: si };
      }).filter(Boolean),
    ].sort((a, b) => a.startIdx - b.startIdx);

    for (const item of allBarItems) {
      let placed = false;
      for (let lane = 0; lane < lanes.length; lane++) {
        if (lanes[lane].every(b => b.endIdx < item.startIdx || b.startIdx > item.endIdx)) {
          lanes[lane].push(item);
          placed = true; break;
        }
      }
      if (!placed) lanes.push([item]);
    }
    return { lanes, pointTasks: [] };
  }, [tasks, dateIndex, calDays]);

  const todayStr = new Date().toISOString().slice(0, 10);
  const nb = { background: C.surface, border: `1px solid ${C.border}`, borderRadius: 3, cursor: "pointer", color: C.textLight, display: "flex", alignItems: "center", justifyContent: "center", width: 28, height: 28, padding: 0 };
  const totalCols = 7;
  const barH = 20, barGap = 2, barTop = 28; // bar starts below day number
  const numLanes = bars.lanes.length;
  const cellMinH = Math.max(60, barTop + numLanes * (barH + barGap) + 24); // ensure room for bars + point tasks

  // Point tasks: tasks without dueDate, shown as simple labels on their created date
  const pointsByDate = useMemo(() => {
    const m = {};
    bars.pointTasks.forEach(t => {
      if (t.created) { if (!m[t.created]) m[t.created] = []; m[t.created].push(t); }
    });
    return m;
  }, [bars.pointTasks]);

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <div style={{ padding: "12px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", background: C.surface, borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button onClick={() => setViewDate(new Date(year, month - 1, 1))} style={nb}>{I.chevL}</button>
          <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: C.text, minWidth: 120, textAlign: "center" }}>{year}年{month + 1}月</h2>
          <button onClick={() => setViewDate(new Date(year, month + 1, 1))} style={nb}>{I.chevR}</button>
          <button onClick={() => setViewDate(new Date())} style={{ ...nb, fontSize: 11, fontWeight: 600, padding: "4px 10px", width: "auto" }}>今日</button>
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textLight }}><div style={{ width: 24, height: 6, borderRadius: 3, background: C.accent }} />期間バー</div>
          {COLUMNS.map(c => <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textLight }}><div style={{ width: 8, height: 8, borderRadius: 2, background: COL_COLORS[c.id] }} />{c.title}</div>)}
        </div>
      </div>
      <div style={{ flex: 1, overflow: "auto", padding: "12px 24px 24px" }}>
        {/* Weekday header */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 1, marginBottom: 1 }}>{WEEKDAYS.map(w => <div key={w} style={{ textAlign: "center", fontSize: 11, fontWeight: 700, color: C.textLight, padding: "6px 0", background: C.surface, borderBottom: `2px solid ${C.border}` }}>{w}</div>)}</div>
        {/* Calendar grid with bar overlay */}
        {Array.from({ length: calDays.length / 7 }).map((_, weekIdx) => {
          const weekCells = calDays.slice(weekIdx * 7, weekIdx * 7 + 7);
          return (
            <div key={weekIdx} style={{ position: "relative" }}>
              {/* Day cells */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(7,1fr)", gap: 0 }}>
                {weekCells.map((cell, di) => {
                  const globalIdx = weekIdx * 7 + di;
                  const isT = cell.date === todayStr;
                  const pts = cell.date ? (pointsByDate[cell.date] || []) : [];
                  const ptOffset = barTop + numLanes * (barH + barGap);
                  return (
                    <div key={di} onClick={() => cell.date && onAddOnDate(cell.date)}
                      style={{ minHeight: cellMinH, background: C.surface, padding: "4px 6px", opacity: cell.inMonth ? 1 : 0.35, cursor: cell.date ? "pointer" : "default", borderBottom: `1px solid ${C.border}`, borderRight: di < 6 ? `1px solid ${C.border}` : "none", position: "relative" }}
                      onMouseEnter={e => { if (cell.inMonth) e.currentTarget.style.background = C.colBg; }}
                      onMouseLeave={e => { e.currentTarget.style.background = C.surface; }}>
                      <div style={{ fontSize: 12, fontWeight: isT ? 700 : 500, color: isT ? "#fff" : cell.inMonth ? C.text : C.textVLight }}>
                        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 22, height: 22, borderRadius: "50%", background: isT ? C.accent : "transparent" }}>{cell.day}</span>
                      </div>
                      {/* Point tasks (no dueDate) shown below bars area */}
                      <div style={{ position: "absolute", top: ptOffset, left: 4, right: 4 }}>
                        {pts.slice(0, 2).map(t => {
                          const cc = COL_COLORS[t.column] || C.accent;
                          return <div key={t.id} onClick={e => { e.stopPropagation(); onEdit(t); }} style={{ fontSize: 10, padding: "2px 4px", borderRadius: 2, background: `${cc}11`, borderLeft: `2px solid ${cc}`, color: C.text, fontWeight: 500, cursor: "pointer", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginBottom: 1 }}>{t.title}</div>;
                        })}
                        {pts.length > 2 && <div style={{ fontSize: 9, color: C.textVLight }}>+{pts.length - 2}</div>}
                      </div>
                    </div>
                  );
                })}
              </div>
              {/* Bar overlay for this week */}
              {bars.lanes.map((lane, laneIdx) => {
                return lane.filter(b => {
                  const ws = weekIdx * 7, we = ws + 6;
                  return b.startIdx <= we && b.endIdx >= ws;
                }).map(b => {
                  const ws = weekIdx * 7, we = ws + 6;
                  const visStart = Math.max(b.startIdx - ws, 0);
                  const visEnd = Math.min(b.endIdx - ws, 6);
                  const span = visEnd - visStart + 1;
                  const isStart = b.startIdx >= ws;
                  const isEnd = b.endIdx <= we;
                  const cc = COL_COLORS[b.task.column] || C.accent;
                  const isOverdue = b.task.dueDate < todayStr && b.task.column !== "done";
                  const pct = `${(visStart / 7) * 100}%`;
                  const width = `${(span / 7) * 100}%`;
                  return (
                    <div key={`${b.task.id}-${weekIdx}`}
                      onClick={() => onEdit(b.task)}
                      style={{
                        position: "absolute",
                        top: barTop + laneIdx * (barH + barGap),
                        left: `calc(${pct} + 3px)`,
                        width: `calc(${width} - 6px)`,
                        height: barH,
                        background: isOverdue ? C.danger + "cc" : cc + "cc",
                        borderRadius: `${isStart ? 4 : 0}px ${isEnd ? 4 : 0}px ${isEnd ? 4 : 0}px ${isStart ? 4 : 0}px`,
                        display: "flex", alignItems: "center", padding: "0 6px",
                        cursor: "pointer", zIndex: 2, overflow: "hidden",
                        boxShadow: "0 1px 3px rgba(0,0,0,0.12)",
                      }}>
                      <span style={{ fontSize: 10, fontWeight: 600, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", textShadow: "0 1px 2px rgba(0,0,0,0.3)" }}>
                        {isStart && b.task.id + " "}{b.task.title}
                      </span>
                      {isEnd && isOverdue && <span style={{ marginLeft: "auto", fontSize: 9, flexShrink: 0 }}>⏰</span>}
                    </div>
                  );
                });
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Task Modal ── */
function TaskModal({ task, columnId, defaultDate, onSave, onClose, members = FALLBACK_MEMBERS, epics = [], onAddComment }) {
  const isEdit = !!task;
  const [title, setTitle] = useState(task?.title || ""), [desc, setDesc] = useState(task?.desc || ""), [priority, setPriority] = useState(task?.priority || "medium");
  const [assignees, setAssignees] = useState(task?.assignees || []), [tagIn, setTagIn] = useState(""), [tags, setTags] = useState(task?.tags || []);
  const [col, setCol] = useState(task?.column || columnId || "backlog"), [date, setDate] = useState(task?.created || defaultDate || new Date().toISOString().slice(0, 10));
  const [epicId, setEpicId] = useState(task?.epicId || "");
  const [dueDate, setDueDate] = useState(task?.dueDate || "");
  const [commentText, setCommentText] = useState("");
  const [comments, setComments] = useState(task?.comments || []);
  const toggle = id => setAssignees(p => p.includes(id) ? p.filter(a => a !== id) : [...p, id]);
  const addTag = () => { const t = tagIn.trim(); if (t && !tags.includes(t)) { setTags([...tags, t]); setTagIn(""); } };
  const addComment = () => {
    if (!commentText.trim()) return;
    const c = { id: Date.now(), author: "You", content: commentText.trim(), createdAt: new Date().toISOString() };
    setComments(p => [...p, c]);
    if (onAddComment && task?.id) onAddComment(task.id, "You", commentText.trim());
    setCommentText("");
  };
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(9,30,66,0.54)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.surface, borderRadius: 8, padding: "24px 28px", width: "100%", maxWidth: 500, boxShadow: "0 8px 40px rgba(9,30,66,0.35)", maxHeight: "85vh", overflowY: "auto" }}>
        <h3 style={{ margin: "0 0 20px", color: C.text, fontSize: 18, fontWeight: 600 }}>{isEdit ? "課題を編集" : "課題を作成"}</h3>
        <Lbl>タイトル *</Lbl><input value={title} onChange={e => setTitle(e.target.value)} placeholder="課題のタイトルを入力" style={{ ...inpStyle, marginBottom: 14 }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>説明</Lbl><textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="説明（任意）" rows={3} style={{ ...inpStyle, marginBottom: 14, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />
        <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
          <div style={{ flex: 1 }}><Lbl>作成日</Lbl><input type="date" value={date} onChange={e => setDate(e.target.value)} style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
          <div style={{ flex: 1 }}><Lbl>期限日</Lbl><input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
        </div>
        <Lbl>ステータス</Lbl><div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 14 }}>{COLUMNS.map(c => <button key={c.id} onClick={() => setCol(c.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: col === c.id ? C.accentLight : C.colBg, color: col === c.id ? C.accent : C.textLight }}>{c.title}</button>)}</div>
        <Lbl>優先度</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14 }}>{Object.entries(PRIORITY).map(([k, v]) => <button key={k} onClick={() => setPriority(k)} style={{ padding: "5px 14px", borderRadius: 3, fontSize: 12, fontWeight: 600, cursor: "pointer", border: priority === k ? `2px solid ${v.color}` : `2px solid ${C.border}`, background: priority === k ? v.bg : C.surface, color: priority === k ? v.color : C.textLight, display: "flex", alignItems: "center", gap: 4 }}><span style={{ fontWeight: 800 }}>{v.icon}</span> {v.label}</button>)}</div>
        {epics.length > 0 && (<><Lbl>エピック</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap" }}>
          <button onClick={() => setEpicId("")} style={{ padding: "3px 10px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: !epicId ? C.accentLight : C.colBg, color: !epicId ? C.accent : C.textLight }}>なし</button>
          {epics.map(ep => <button key={ep.id} onClick={() => setEpicId(ep.id)} style={{ padding: "3px 10px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: epicId === ep.id ? `${ep.color}18` : C.colBg, color: epicId === ep.id ? ep.color : C.textLight, borderLeft: `3px solid ${ep.color}` }}>{ep.name}</button>)}
        </div></>)}
        <Lbl>担当者</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>{members.map(m => <button key={m.id} onClick={() => toggle(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px", borderRadius: 3, cursor: "pointer", fontSize: 12, fontWeight: 500, border: assignees.includes(m.id) ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: assignees.includes(m.id) ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={20} />{m.name}</button>)}</div>
        <Lbl>ラベル</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>{tags.map(t => <span key={t} style={{ fontSize: 11, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 4 }}>{t}<span onClick={() => setTags(tags.filter(x => x !== t))} style={{ cursor: "pointer", fontSize: 14, lineHeight: 1 }}>×</span></span>)}<input value={tagIn} onChange={e => setTagIn(e.target.value)} onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addTag())} placeholder="ラベル追加 (Enter)" style={{ ...inpStyle, width: 130, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} /></div>

        {/* Comments section */}
        {isEdit && (<>
          <Lbl>💬 コメント ({comments.length})</Lbl>
          <div style={{ marginBottom: 14, border: `1px solid ${C.border}`, borderRadius: 4, overflow: "hidden" }}>
            {comments.length > 0 && (
              <div style={{ maxHeight: 150, overflowY: "auto" }}>
                {comments.map(c => (
                  <div key={c.id} style={{ padding: "8px 12px", borderBottom: `1px solid ${C.colBg}`, fontSize: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                      <span style={{ fontWeight: 600, color: C.accent }}>{c.author}</span>
                      <span style={{ fontSize: 10, color: C.textVLight }}>{(c.createdAt || "").slice(0, 16).replace("T", " ")}</span>
                    </div>
                    <div style={{ color: C.text, lineHeight: 1.4 }}>{c.content}</div>
                  </div>
                ))}
              </div>
            )}
            <div style={{ display: "flex", gap: 6, padding: "8px 10px", background: C.colBg }}>
              <input value={commentText} onChange={e => setCommentText(e.target.value)}
                onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addComment())}
                placeholder="コメントを入力 (Enter)" style={{ ...inpStyle, flex: 1, padding: "6px 8px", fontSize: 12 }} onFocus={onFocus} onBlur={onBlur} />
              <button onClick={addComment} style={{ padding: "6px 12px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 600, whiteSpace: "nowrap" }}>送信</button>
            </div>
          </div>
        </>)}

        {/* Activity log */}
        {isEdit && task?.activity?.length > 0 && (<>
          <Lbl>📝 履歴</Lbl>
          <div style={{ maxHeight: 100, overflowY: "auto", marginBottom: 14 }}>
            {task.activity.slice(0, 10).map(a => (
              <div key={a.id} style={{ fontSize: 10, color: C.textVLight, padding: "3px 0", display: "flex", gap: 6 }}>
                <span style={{ color: C.textLight, minWidth: 100 }}>{(a.createdAt || "").slice(0, 16).replace("T", " ")}</span>
                <span>{a.detail || a.action}</span>
              </div>
            ))}
          </div>
        </>)}

        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
          <button onClick={onClose} style={{ padding: "8px 20px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 13, fontWeight: 500 }}>キャンセル</button>
          <button onClick={() => { if (!title.trim()) return; onSave({ id: task?.id || `DASH-${nextNum++}`, column: col, title: title.trim(), desc: desc.trim(), priority, assignees, tags, created: date, dueDate, epicId, priorityOrder: task?.priorityOrder || 0, comments, activity: task?.activity || [] }); }} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>{isEdit ? "更新" : "作成"}</button>
        </div>
      </div>
    </div>
  );
}

/* ── Goal Modal ── */
function GoalModal({ goal, mode, onSave, onClose, members = FALLBACK_MEMBERS }) {
  const isEdit = !!goal;
  const [title, setTitle] = useState(goal?.title || "");
  const [desc, setDesc] = useState(goal?.desc || "");
  const [progress, setProgress] = useState(goal?.progress ?? 0);
  const [level, setLevel] = useState(goal?.level || "company");
  const [memberId, setMemberId] = useState(goal?.memberId || "m1");
  const [period, setPeriod] = useState(goal?.period || "annual");
  const [krText, setKrText] = useState("");
  const [keyResults, setKeyResults] = useState(goal?.keyResults || []);
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(9,30,66,0.54)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000 }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: C.surface, borderRadius: 8, padding: "24px 28px", width: "100%", maxWidth: 500, boxShadow: "0 8px 40px rgba(9,30,66,0.35)", maxHeight: "85vh", overflowY: "auto" }}>
        <h3 style={{ margin: "0 0 20px", color: C.text, fontSize: 18, fontWeight: 600 }}>{isEdit ? "目標を編集" : "目標を追加"}</h3>
        {mode === "org" && (<><Lbl>階層</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap" }}>{ORG_LEVELS.map(l => <button key={l.id} onClick={() => setLevel(l.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: level === l.id ? `${l.color}18` : C.colBg, color: level === l.id ? l.color : C.textLight }}>{l.icon} {l.label}</button>)}</div></>)}
        {mode === "personal" && (<>
          <Lbl>メンバー</Lbl><div style={{ display: "flex", gap: 6, marginBottom: 14, flexWrap: "wrap" }}>{members.map(m => <button key={m.id} onClick={() => setMemberId(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px", borderRadius: 3, cursor: "pointer", fontSize: 12, fontWeight: 500, border: memberId === m.id ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: memberId === m.id ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={20} />{m.name}</button>)}</div>
          <Lbl>期間</Lbl><div style={{ display: "flex", gap: 4, marginBottom: 14, flexWrap: "wrap" }}>{PERIODS.map(p => <button key={p.id} onClick={() => setPeriod(p.id)} style={{ padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: period === p.id ? C.accentLight : C.colBg, color: period === p.id ? C.accent : C.textLight }}>{p.label}</button>)}</div>
        </>)}
        <Lbl>目標タイトル *</Lbl><input value={title} onChange={e => setTitle(e.target.value)} placeholder="目標を入力" style={{ ...inpStyle, marginBottom: 14 }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>説明</Lbl><textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="説明（任意）" rows={2} style={{ ...inpStyle, marginBottom: 14, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />
        <Lbl>進捗 ({progress}%)</Lbl>
        <input type="range" min={0} max={100} value={progress} onChange={e => setProgress(Number(e.target.value))} style={{ width: "100%", marginBottom: 14, accentColor: C.accent }} />
        {mode === "personal" && (<>
          <Lbl>Key Results</Lbl>
          <div style={{ display: "flex", flexDirection: "column", gap: 4, marginBottom: 14 }}>
            {keyResults.map((kr, i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: C.text, background: C.colBg, padding: "4px 8px", borderRadius: 3 }}><span style={{ flex: 1 }}>{kr}</span><span onClick={() => setKeyResults(keyResults.filter((_, j) => j !== i))} style={{ cursor: "pointer", color: C.danger, fontSize: 14 }}>×</span></div>)}
            <input value={krText} onChange={e => setKrText(e.target.value)} onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); if (krText.trim()) { setKeyResults([...keyResults, krText.trim()]); setKrText(""); } } }} placeholder="KR を追加 (Enter)" style={{ ...inpStyle, flex: 1, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} />
          </div>
        </>)}
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
          <button onClick={onClose} style={{ padding: "8px 20px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 13, fontWeight: 500 }}>キャンセル</button>
          <button onClick={() => {
            if (!title.trim()) return;
            const base = { title: title.trim(), desc: desc.trim(), progress };
            if (mode === "org") onSave({ id: goal?.id || `og${goalNextId++}`, level, ...base });
            else onSave({ id: goal?.id || `pg${goalNextId++}`, memberId, period, keyResults, ...base });
          }} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>{isEdit ? "更新" : "追加"}</button>
        </div>
      </div>
    </div>
  );
}

/* ── Goals Page ── */
function GoalsPage({ orgGoals, personalGoals, onSaveOrgGoal, onDeleteOrgGoal, onSavePersonalGoal, onDeletePersonalGoal, members = FALLBACK_MEMBERS }) {
  const [tab, setTab] = useState("org");
  const [modal, setModal] = useState(null);
  const [expandedLevels, setExpandedLevels] = useState({ company: true, division: true, dept: true, section: true, group: true });
  const [selectedMember, setSelectedMember] = useState("m1");
  const [selectedPeriod, setSelectedPeriod] = useState("all");
  const toggleLevel = id => setExpandedLevels(p => ({ ...p, [id]: !p[id] }));

  const saveGoal = (goal) => {
    if (modal.mode === "org") onSaveOrgGoal(goal);
    else onSavePersonalGoal(goal);
    setModal(null);
  };

  const memberGoals = personalGoals.filter(g => g.memberId === selectedMember && (selectedPeriod === "all" || g.period === selectedPeriod));
  const member = members.find(m => m.id === selectedMember);
  const levelAvg = (levelId) => { const gs = orgGoals.filter(g => g.level === levelId); return gs.length ? Math.round(gs.reduce((s, g) => s + g.progress, 0) / gs.length) : 0; };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>目標管理</h1>
          <span style={{ fontSize: 9, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.colBg, color: C.textVLight, letterSpacing: 0.3 }}>全プロジェクト共通</span>
          <div style={{ display: "flex", background: C.colBg, borderRadius: 4, padding: 2, border: `1px solid ${C.border}` }}>
            {[{ id: "org", label: "🏢 組織方針" }, { id: "personal", label: "👤 個人目標" }].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)} style={{ padding: "4px 12px", borderRadius: 3, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600, background: tab === t.id ? C.surface : "transparent", color: tab === t.id ? C.accent : C.textLight, boxShadow: tab === t.id ? "0 1px 3px rgba(9,30,66,0.13)" : "none" }}>{t.label}</button>
            ))}
          </div>
        </div>
        <button onClick={() => setModal({ mode: tab })} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 目標を追加</button>
      </header>
      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {tab === "org" ? (
          <div style={{ maxWidth: 900 }}>
            {ORG_LEVELS.map(level => {
              const goals = orgGoals.filter(g => g.level === level.id);
              const avg = levelAvg(level.id);
              const expanded = expandedLevels[level.id];
              return (
                <div key={level.id} style={{ marginBottom: 4 }}>
                  <button onClick={() => toggleLevel(level.id)} style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", padding: "10px 14px", background: C.surface, border: "none", borderBottom: `1px solid ${C.border}`, borderLeft: `4px solid ${level.color}`, cursor: "pointer", borderRadius: expanded ? "6px 6px 0 0" : 6 }}>
                    <span style={{ color: level.color, display: "flex" }}>{expanded ? I.chevD : I.chevR}</span>
                    <span style={{ fontSize: 18 }}>{level.icon}</span>
                    <span style={{ fontSize: 13, fontWeight: 700, color: C.text, flex: 1, textAlign: "left" }}>{level.label}</span>
                    <span style={{ fontSize: 11, color: C.textVLight, marginRight: 8 }}>{goals.length}件</span>
                    <div style={{ width: 80, marginRight: 8 }}><ProgressBar value={avg} color={level.color} height={5} /></div>
                    <span style={{ fontSize: 11, fontWeight: 600, color: level.color, minWidth: 32 }}>{avg}%</span>
                  </button>
                  {expanded && goals.length > 0 && (
                    <div style={{ background: C.surface, borderRadius: "0 0 6px 6px", borderLeft: `4px solid ${level.color}`, borderBottom: `1px solid ${C.border}` }}>
                      {goals.map(g => <OrgGoalRow key={g.id} goal={g} color={level.color} onEdit={() => setModal({ mode: "org", goal: g })} onDelete={() => onDeleteOrgGoal(g.id)} />)}
                    </div>
                  )}
                  {expanded && goals.length === 0 && <div style={{ background: C.surface, borderRadius: "0 0 6px 6px", borderLeft: `4px solid ${level.color}`, borderBottom: `1px solid ${C.border}`, padding: "12px 20px", fontSize: 12, color: C.textVLight }}>目標が設定されていません</div>}
                </div>
              );
            })}
          </div>
        ) : (
          <div style={{ maxWidth: 900 }}>
            <div style={{ display: "flex", gap: 8, marginBottom: 16, alignItems: "center", flexWrap: "wrap" }}>
              {members.map(m => <button key={m.id} onClick={() => setSelectedMember(m.id)} style={{ display: "flex", alignItems: "center", gap: 6, padding: "6px 14px", borderRadius: 6, cursor: "pointer", fontSize: 13, fontWeight: 600, border: selectedMember === m.id ? `2px solid ${m.color}` : `2px solid ${C.border}`, background: selectedMember === m.id ? `${m.color}11` : C.surface, color: C.text }}><Avatar member={m} size={26} />{m.name}</button>)}
            </div>
            <div style={{ display: "flex", gap: 4, marginBottom: 20 }}>
              <button onClick={() => setSelectedPeriod("all")} style={{ padding: "4px 12px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: selectedPeriod === "all" ? C.accentLight : C.colBg, color: selectedPeriod === "all" ? C.accent : C.textLight }}>すべて</button>
              {PERIODS.map(p => <button key={p.id} onClick={() => setSelectedPeriod(p.id)} style={{ padding: "4px 12px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: selectedPeriod === p.id ? C.accentLight : C.colBg, color: selectedPeriod === p.id ? C.accent : C.textLight }}>{p.label}</button>)}
            </div>
            {memberGoals.length === 0 ? (
              <div style={{ textAlign: "center", padding: 40, color: C.textVLight }}><div style={{ fontSize: 36, marginBottom: 8, opacity: 0.3 }}>🎯</div><div style={{ fontSize: 13 }}>{member?.name} の目標はありません</div></div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340, 1fr))", gap: 12 }}>
                {memberGoals.map(g => <PersonalGoalCard key={g.id} goal={g} onEdit={() => setModal({ mode: "personal", goal: g })} onDelete={() => onDeletePersonalGoal(g.id)} />)}
              </div>
            )}
          </div>
        )}
      </div>
      {modal && <GoalModal goal={modal.goal} mode={modal.mode} onSave={saveGoal} onClose={() => setModal(null)} members={members} />}
    </div>
  );
}

function OrgGoalRow({ goal, color, onEdit, onDelete }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderTop: `1px solid ${C.colBg}`, transition: "background .1s", background: hov ? C.cardHover : "transparent" }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 2 }}>{goal.title}</div>
        {goal.desc && <div style={{ fontSize: 11, color: C.textLight, lineHeight: 1.4 }}>{goal.desc}</div>}
      </div>
      <div style={{ width: 100 }}><ProgressBar value={goal.progress} color={color} height={5} /></div>
      <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 36, textAlign: "right" }}>{goal.progress}%</span>
      {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={onEdit} style={aBtn}>✏️</button><button onClick={onDelete} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
    </div>
  );
}

function PersonalGoalCard({ goal, onEdit, onDelete }) {
  const [hov, setHov] = useState(false);
  const periodLabel = PERIODS.find(p => p.id === goal.period)?.label || "";
  const pColor = goal.progress >= 80 ? C.success : goal.progress >= 40 ? C.warning : C.accent;
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ background: C.surface, borderRadius: 6, padding: "16px 18px", border: `1px solid ${hov ? C.borderFocus : C.border}`, boxShadow: hov ? "0 2px 8px rgba(9,30,66,0.15)" : "0 1px 2px rgba(9,30,66,0.08)", transition: "all .15s" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
        <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent }}>{periodLabel}</span>
        {hov && <div style={{ display: "flex", gap: 2 }}><button onClick={onEdit} style={aBtn}>✏️</button><button onClick={onDelete} style={{ ...aBtn, color: C.danger }}>🗑</button></div>}
      </div>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 4, lineHeight: 1.4 }}>{goal.title}</div>
      {goal.desc && <div style={{ fontSize: 12, color: C.textLight, marginBottom: 10, lineHeight: 1.4 }}>{goal.desc}</div>}
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: goal.keyResults?.length ? 12 : 0 }}>
        <div style={{ flex: 1 }}><ProgressBar value={goal.progress} color={pColor} height={6} /></div>
        <span style={{ fontSize: 12, fontWeight: 700, color: pColor }}>{goal.progress}%</span>
      </div>
      {goal.keyResults && goal.keyResults.length > 0 && (
        <div style={{ borderTop: `1px solid ${C.border}`, paddingTop: 8, marginTop: 4 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: C.textVLight, marginBottom: 4, letterSpacing: 0.5 }}>KEY RESULTS</div>
          {goal.keyResults.map((kr, i) => <div key={i} style={{ fontSize: 12, color: C.textMid, padding: "3px 0", display: "flex", alignItems: "flex-start", gap: 6 }}><span style={{ color: C.accent, fontSize: 10, marginTop: 2, flexShrink: 0 }}>●</span>{kr}</div>)}
        </div>
      )}
    </div>
  );
}

/* ── Sidebar ── */
function SidebarItem({ item, active, expanded, onClick }) {
  const [hov, setHov] = useState(false);
  return (
    <button onClick={onClick} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 10, position: "relative", width: "100%", padding: expanded ? "8px 12px" : "8px 0", justifyContent: expanded ? "flex-start" : "center", borderRadius: 4, border: "none", cursor: item.disabled ? "default" : "pointer", background: active ? C.sidebarActive : hov && !item.disabled ? C.sidebarHover : "transparent", color: active ? C.sidebarTextActive : item.disabled ? "rgba(255,255,255,0.32)" : C.sidebarText, fontSize: 13, fontWeight: active ? 600 : 500, transition: "all .12s", marginBottom: 2, whiteSpace: "nowrap", opacity: item.disabled ? 0.7 : 1 }}>
      {active && <div style={{ position: "absolute", left: 0, top: "50%", transform: "translateY(-50%)", width: 3, height: 20, background: C.sidebarAccent, borderRadius: "0 2px 2px 0" }} />}
      <span style={{ flexShrink: 0, display: "flex", alignItems: "center" }}>{item.icon}</span>
      {expanded && <span>{item.label}</span>}
      {expanded && item.shared && <span style={{ fontSize: 8, fontWeight: 700, marginLeft: "auto", background: "rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.55)", padding: "1px 5px", borderRadius: 3, letterSpacing: 0.3 }}>共通</span>}
      {expanded && item.disabled && <span style={{ fontSize: 9, fontWeight: 600, marginLeft: "auto", background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.45)", padding: "1px 6px", borderRadius: 3 }}>Soon</span>}
    </button>
  );
}

function ViewToggle({ view, onChange }) {
  return (
    <div style={{ display: "flex", background: C.colBg, borderRadius: 4, padding: 2, border: `1px solid ${C.border}` }}>
      {[{ id: "board", icon: I.kanban, label: "ボード" }, { id: "calendar", icon: I.cal, label: "カレンダー" }].map(v => (
        <button key={v.id} onClick={() => onChange(v.id)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 10px", borderRadius: 3, border: "none", cursor: "pointer", background: view === v.id ? C.surface : "transparent", color: view === v.id ? C.accent : C.textLight, fontSize: 11, fontWeight: 600, boxShadow: view === v.id ? "0 1px 3px rgba(9,30,66,0.13)" : "none" }}>{v.icon}<span>{v.label}</span></button>
      ))}
    </div>
  );
}

/* ── AI Page ── */
const AGENT_PROFILES = {
  customer: { name: "佐藤", role: "顧客代表", color: "#fbbf24", avatar: "佐" },
  po: { name: "鈴木", role: "PO", color: "#818cf8", avatar: "鈴" },
  sm: { name: "高橋", role: "SM", color: "#4ade80", avatar: "高" },
  "dev-frontend": { name: "伊藤", role: "Dev-FE", color: "#60a5fa", avatar: "伊" },
  "dev-backend": { name: "田中", role: "Dev-BE", color: "#fb923c", avatar: "田" },
  system: { name: "システム", role: "", color: C.textVLight, avatar: "⚙" },
};

function AIPage({ apiAvailable, currentProjectId }) {
  const [conversations, setConversations] = useState([]);
  const [activeConvo, setActiveConvo] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [phase, setPhase] = useState("idle"); // idle, requirements, planning, developing, reviewing, retro, done
  const messagesEndRef = useRef(null);

  // Load conversations
  useEffect(() => {
    (async () => {
      if (!apiAvailable) return;
      const convos = await api.getConversations();
      if (convos) setConversations(convos);
    })();
  }, [apiAvailable]);

  // Load messages when conversation changes
  useEffect(() => {
    if (!activeConvo || !apiAvailable) return;
    (async () => {
      const msgs = await api.getMessages(activeConvo);
      if (msgs) setMessages(msgs);
    })();
  }, [activeConvo, apiAvailable]);

  // Auto-scroll
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const startNew = async () => {
    const id = `conv-${Date.now()}`;
    if (apiAvailable) await api.createConversation({ id, title: "新しい依頼", projectId: currentProjectId });
    setConversations(p => [{ id, title: "新しい依頼", status: "active", messageCount: 0 }, ...p]);
    setActiveConvo(id);
    setMessages([]);
    setPhase("idle");
    // System welcome
    const welcome = { role: "assistant", agentId: "customer", content: "こんにちは！佐藤です。何を作りたいですか？\n\n簡単な指示でOKです。詳細は私が確認しながら要件にまとめます。" };
    setMessages([welcome]);
    if (apiAvailable) await api.sendMessage(id, welcome);
  };

  const sendMsg = async () => {
    if (!input.trim() || !activeConvo || loading) return;
    const text = input.trim();
    setInput("");

    // Add human message
    const humanMsg = { role: "human", agentId: "", content: text };
    setMessages(p => [...p, humanMsg]);

    setLoading(true);

    try {
      // Call real agent API
      const result = await api.agentChat(activeConvo, text, currentProjectId);

      if (result && result.messages) {
        for (const msg of result.messages) {
          setMessages(p => [...p, msg]);
        }
        // Update phase based on tool results
        if (result.toolResults?.length > 0) {
          const hasSprint = result.toolResults.some(r => r.path?.includes("/sprints"));
          const hasTask = result.toolResults.some(r => r.path?.includes("/tasks"));
          const hasKnowledge = result.toolResults.some(r => r.path?.includes("/knowledge"));
          if (hasSprint) setPhase("planning");
          else if (hasTask) setPhase("developing");
          else if (hasKnowledge) setPhase("retro");
        }
        if (result.pendingQuestion) setPhase("requirements");
      } else if (result && result.error) {
        setMessages(p => [...p, { role: "assistant", agentId: "system", content: `⚠️ エラー: ${result.error}` }]);
      }
    } catch (e) {
      setMessages(p => [...p, { role: "assistant", agentId: "system", content: `⚠️ 通信エラー: ${e.message}` }]);
    }

    setLoading(false);

    // Reload conversations list
    if (apiAvailable) {
      const convos = await api.getConversations();
      if (convos) setConversations(convos);
    }
  };

  const activeMessages = messages;
  const convo = conversations.find(c => c.id === activeConvo);

  const phaseLabels = { idle: "待機中", requirements: "要件整理", planning: "プランニング", developing: "開発中", reviewing: "レビュー", retro: "ふりかえり", done: "完了" };
  const phaseColors = { idle: C.textVLight, requirements: "#fbbf24", planning: "#818cf8", developing: "#60a5fa", reviewing: "#4ade80", retro: "#c084fc", done: C.success };

  return (
    <div style={{ flex: 1, display: "flex", overflow: "hidden", background: C.bg }}>
      {/* Conversation list */}
      <div style={{ width: 240, flexShrink: 0, borderRight: `1px solid ${C.border}`, background: C.surface, display: "flex", flexDirection: "column" }}>
        <div style={{ padding: "12px 14px", borderBottom: `1px solid ${C.border}` }}>
          <button onClick={startNew} style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "8px 14px", borderRadius: 4, border: `1px dashed ${C.border}`, background: "transparent", color: C.accent, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 新しい依頼</button>
        </div>
        <div style={{ flex: 1, overflowY: "auto" }}>
          {conversations.length === 0 && <div style={{ padding: 20, textAlign: "center", fontSize: 11, color: C.textVLight }}>「新しい依頼」で開始</div>}
          {conversations.map(c => (
            <div key={c.id} onClick={() => setActiveConvo(c.id)}
              style={{ padding: "10px 14px", cursor: "pointer", borderBottom: `1px solid ${C.colBg}`, background: activeConvo === c.id ? C.accentLight : "transparent", borderLeft: activeConvo === c.id ? `3px solid ${C.accent}` : "3px solid transparent" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.title}</div>
              <div style={{ fontSize: 10, color: C.textVLight, marginTop: 2 }}>{c.messageCount || 0}件のメッセージ</div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column" }}>
        {/* Header */}
        <div style={{ padding: "10px 20px", borderBottom: `1px solid ${C.border}`, background: C.surface, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: C.text }}>{convo ? convo.title : "AIに依頼"}</h2>
            {phase !== "idle" && <span style={{ fontSize: 10, fontWeight: 700, padding: "2px 10px", borderRadius: 10, background: `${phaseColors[phase]}18`, color: phaseColors[phase] }}>{phaseLabels[phase]}</span>}
          </div>
          {/* Agent avatars */}
          <div style={{ display: "flex", gap: -4 }}>
            {Object.entries(AGENT_PROFILES).filter(([k]) => k !== "system").map(([k, a]) => (
              <div key={k} title={`${a.name} (${a.role})`} style={{ width: 26, height: 26, borderRadius: "50%", background: a.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: "#fff", marginLeft: -4, border: "2px solid #fff", zIndex: 1 }}>{a.avatar}</div>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "16px 20px" }}>
          {!activeConvo && (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: C.textVLight }}>
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 48, marginBottom: 12, opacity: 0.2 }}>🤖</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 4 }}>AIスクラムチームに依頼</div>
                <div style={{ fontSize: 12 }}>「新しい依頼」で会話を開始してください</div>
                <div style={{ display: "flex", gap: 8, marginTop: 16, justifyContent: "center", flexWrap: "wrap" }}>
                  {["ダークモード追加", "検索機能を実装", "パフォーマンス改善", "テストを書いて"].map(ex => (
                    <button key={ex} onClick={() => { startNew().then(() => { setInput(ex); }); }}
                      style={{ padding: "6px 12px", borderRadius: 16, border: `1px solid ${C.border}`, background: C.surface, color: C.textLight, cursor: "pointer", fontSize: 11, fontWeight: 500 }}>{ex}</button>
                  ))}
                </div>
              </div>
            </div>
          )}
          {activeMessages.map((msg, i) => <ChatMessage key={i} msg={msg} />)}
          {loading && <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 0" }}><div style={{ width: 6, height: 6, borderRadius: "50%", background: C.accent, animation: "pulse 1s infinite" }} /><span style={{ fontSize: 11, color: C.textVLight }}>考え中...</span></div>}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        {activeConvo && (
          <div style={{ padding: "12px 20px", borderTop: `1px solid ${C.border}`, background: C.surface }}>
            <div style={{ display: "flex", gap: 8 }}>
              <input value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && !e.shiftKey && (e.preventDefault(), sendMsg())}
                placeholder="指示を入力... (Enterで送信)" disabled={loading}
                style={{ flex: 1, padding: "10px 14px", borderRadius: 6, border: `2px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 13, outline: "none" }}
                onFocus={e => e.target.style.borderColor = C.borderFocus} onBlur={e => e.target.style.borderColor = C.border} />
              <button onClick={sendMsg} disabled={loading || !input.trim()}
                style={{ padding: "10px 20px", borderRadius: 6, border: "none", background: loading ? C.border : C.accent, color: "#fff", cursor: loading ? "not-allowed" : "pointer", fontSize: 13, fontWeight: 600 }}>送信</button>
            </div>
          </div>
        )}
      </div>
      <style>{`@keyframes pulse { 0%,100% { opacity:1 } 50% { opacity:0.3 } }`}</style>
    </div>
  );
}

function ChatMessage({ msg }) {
  const isHuman = msg.role === "human";
  const isSystem = msg.agentId === "system";
  const agent = AGENT_PROFILES[msg.agentId] || AGENT_PROFILES.system;

  if (isSystem) {
    return <div style={{ display: "flex", justifyContent: "center", padding: "8px 0" }}><span style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, background: C.colBg, padding: "4px 14px", borderRadius: 10 }}>{msg.content}</span></div>;
  }

  return (
    <div style={{ display: "flex", gap: 10, marginBottom: 12, flexDirection: isHuman ? "row-reverse" : "row", alignItems: "flex-start" }}>
      {!isHuman && (
        <div style={{ width: 32, height: 32, borderRadius: "50%", background: agent.color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{agent.avatar}</div>
      )}
      <div style={{ maxWidth: "70%" }}>
        {!isHuman && <div style={{ fontSize: 10, fontWeight: 600, color: agent.color, marginBottom: 3 }}>{agent.name} <span style={{ color: C.textVLight, fontWeight: 400 }}>{agent.role}</span></div>}
        <div style={{
          padding: "10px 14px", borderRadius: isHuman ? "12px 12px 2px 12px" : "12px 12px 12px 2px",
          background: isHuman ? C.accent : C.surface,
          color: isHuman ? "#fff" : C.text,
          border: isHuman ? "none" : `1px solid ${C.border}`,
          fontSize: 13, lineHeight: 1.6, whiteSpace: "pre-wrap",
        }}>{msg.content}</div>
      </div>
    </div>
  );
}

/* ── Backlog Page ── */
const EPIC_COLORS = ["#de350b", "#6554c0", "#00875a", "#0052cc", "#ff8b00", "#00b8d9", "#ff5630", "#36b37e"];

function BacklogPage({ tasks, epics, onReorder, onSetEpic, onSaveEpic, onDeleteEpic, apiAvailable }) {
  const [groupBy, setGroupBy] = useState("none"); // "none" | "epic" | "priority"
  const [dragIdx, setDragIdx] = useState(null);
  const [overIdx, setOverIdx] = useState(null);
  const [showEpicForm, setShowEpicForm] = useState(false);
  const [epicForm, setEpicForm] = useState({ name: "", color: EPIC_COLORS[0], description: "" });
  const [editingEpic, setEditingEpic] = useState(null);
  const [filterEpic, setFilterEpic] = useState("all");

  // Sort by priorityOrder, filter out done
  const backlog = [...tasks].filter(t => t.column !== "done").sort((a, b) => (a.priorityOrder || 0) - (b.priorityOrder || 0));
  const filtered = filterEpic === "all" ? backlog : filterEpic === "none" ? backlog.filter(t => !t.epicId) : backlog.filter(t => t.epicId === filterEpic);

  // Drag to reorder
  const handleDragStart = (idx) => setDragIdx(idx);
  const handleDragOver = (idx) => { if (dragIdx !== null) setOverIdx(idx); };
  const handleDrop = () => {
    if (dragIdx === null || overIdx === null || dragIdx === overIdx) { setDragIdx(null); setOverIdx(null); return; }
    const reordered = [...filtered];
    const [moved] = reordered.splice(dragIdx, 1);
    reordered.splice(overIdx, 0, moved);
    const orders = reordered.map((t, i) => ({ id: t.id, priorityOrder: i }));
    onReorder(orders);
    setDragIdx(null); setOverIdx(null);
  };

  const handleCreateEpic = () => {
    if (!epicForm.name.trim()) return;
    const id = editingEpic ? editingEpic.id : `ep-${epicNextId++}`;
    onSaveEpic({ id, name: epicForm.name.trim(), color: epicForm.color, description: epicForm.description.trim(), sortOrder: epics.length });
    setEpicForm({ name: "", color: EPIC_COLORS[Math.floor(Math.random() * EPIC_COLORS.length)], description: "" });
    setShowEpicForm(false); setEditingEpic(null);
  };

  const startEditEpic = (e) => { setEditingEpic(e); setEpicForm({ name: e.name, color: e.color, description: e.description || "" }); setShowEpicForm(true); };

  // Group by epic
  const grouped = groupBy === "epic" ? (() => {
    const groups = [{ epic: null, label: "エピックなし", color: C.textVLight, tasks: filtered.filter(t => !t.epicId) }];
    for (const ep of epics) groups.push({ epic: ep, label: ep.name, color: ep.color, tasks: filtered.filter(t => t.epicId === ep.id) });
    return groups.filter(g => g.tasks.length > 0);
  })() : groupBy === "priority" ? (() => {
    return [
      { epic: null, label: "High", color: C.danger, tasks: filtered.filter(t => t.priority === "high") },
      { epic: null, label: "Medium", color: C.warning, tasks: filtered.filter(t => t.priority === "medium") },
      { epic: null, label: "Low", color: C.success, tasks: filtered.filter(t => t.priority === "low") },
    ].filter(g => g.tasks.length > 0);
  })() : null;

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>バックログ</h1>
          <span style={{ fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent }}>{backlog.length} 件</span>
          <div style={{ display: "flex", background: C.colBg, borderRadius: 4, padding: 2, border: `1px solid ${C.border}` }}>
            {[{ id: "none", label: "フラット" }, { id: "epic", label: "エピック別" }, { id: "priority", label: "優先度別" }].map(g => (
              <button key={g.id} onClick={() => setGroupBy(g.id)} style={{ padding: "3px 10px", borderRadius: 3, border: "none", cursor: "pointer", fontSize: 10, fontWeight: 600, background: groupBy === g.id ? C.surface : "transparent", color: groupBy === g.id ? C.accent : C.textLight, boxShadow: groupBy === g.id ? "0 1px 3px rgba(9,30,66,0.13)" : "none" }}>{g.label}</button>
            ))}
          </div>
        </div>
        <button onClick={() => { setEditingEpic(null); setEpicForm({ name: "", color: EPIC_COLORS[Math.floor(Math.random() * EPIC_COLORS.length)], description: "" }); setShowEpicForm(true); }} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} エピック作成</button>
      </header>

      {/* Epic filter bar */}
      <div style={{ padding: "8px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
        <span style={{ fontSize: 10, fontWeight: 600, color: C.textVLight }}>エピック:</span>
        <button onClick={() => setFilterEpic("all")} style={filterPill(filterEpic === "all")}>すべて</button>
        <button onClick={() => setFilterEpic("none")} style={filterPill(filterEpic === "none")}>未分類</button>
        {epics.map(ep => (
          <div key={ep.id} style={{ display: "flex", alignItems: "center", gap: 0 }}>
            <button onClick={() => setFilterEpic(ep.id)} style={{ ...filterPill(filterEpic === ep.id), borderLeft: `3px solid ${ep.color}`, borderRadius: "3px 0 0 3px" }}>{ep.name}</button>
            <button onClick={() => startEditEpic(ep)} style={{ padding: "3px 4px", borderRadius: "0 3px 3px 0", border: "none", background: filterEpic === ep.id ? C.accentLight : C.colBg, color: C.textVLight, cursor: "pointer", fontSize: 9 }}>✏️</button>
          </div>
        ))}
      </div>

      {/* Epic form */}
      {showEpicForm && (
        <div style={{ padding: "12px 24px", background: C.colBg, borderBottom: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", maxWidth: 600 }}>
            <div style={{ flex: 1 }}><Lbl>エピック名 *</Lbl><input value={epicForm.name} onChange={e => setEpicForm({ ...epicForm, name: e.target.value })} onKeyDown={e => e.key === "Enter" && handleCreateEpic()} placeholder="例: 認証基盤" style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
            <div><Lbl>色</Lbl><div style={{ display: "flex", gap: 3 }}>{EPIC_COLORS.map(c => <button key={c} onClick={() => setEpicForm({ ...epicForm, color: c })} style={{ width: 20, height: 20, borderRadius: "50%", background: c, border: epicForm.color === c ? "2px solid #172b4d" : "2px solid transparent", cursor: "pointer", padding: 0 }} />)}</div></div>
            <button onClick={handleCreateEpic} style={{ padding: "8px 16px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>{editingEpic ? "更新" : "作成"}</button>
            {editingEpic && <button onClick={() => { onDeleteEpic(editingEpic.id); setShowEpicForm(false); setEditingEpic(null); }} style={{ padding: "8px 12px", borderRadius: 3, border: "none", background: C.dangerBg, color: C.danger, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>削除</button>}
            <button onClick={() => { setShowEpicForm(false); setEditingEpic(null); }} style={{ padding: "8px 12px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12 }}>取消</button>
          </div>
        </div>
      )}

      {/* Backlog list */}
      <div style={{ flex: 1, overflow: "auto", padding: "16px 24px" }}>
        <div style={{ maxWidth: 800 }}>
          {grouped ? (
            grouped.map((g, gi) => (
              <div key={gi} style={{ marginBottom: 16 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6, padding: "6px 0" }}>
                  <div style={{ width: 4, height: 18, borderRadius: 2, background: g.color }} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{g.label}</span>
                  <span style={{ fontSize: 10, fontWeight: 600, color: C.textVLight }}>{g.tasks.length}件</span>
                </div>
                {g.tasks.map((t, i) => <BacklogRow key={t.id} task={t} rank={i + 1} epics={epics} onSetEpic={onSetEpic} />)}
              </div>
            ))
          ) : (
            <>
              <div style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, marginBottom: 6, padding: "0 4px" }}>ドラッグで優先度を並べ替え（上が高優先）</div>
              {filtered.map((t, i) => (
                <BacklogRow key={t.id} task={t} rank={i + 1} epics={epics} onSetEpic={onSetEpic}
                  draggable onDragStart={() => handleDragStart(i)} onDragOver={() => handleDragOver(i)} onDrop={handleDrop} onDragEnd={() => { setDragIdx(null); setOverIdx(null); }}
                  isDragOver={overIdx === i} isDragging={dragIdx === i} />
              ))}
            </>
          )}
          {filtered.length === 0 && <div style={{ textAlign: "center", padding: 40, color: C.textVLight, fontSize: 12 }}>バックログにタスクがありません</div>}
        </div>
      </div>
    </div>
  );
}

function BacklogRow({ task, rank, epics, onSetEpic, draggable, onDragStart, onDragOver, onDrop, onDragEnd, isDragOver, isDragging }) {
  const [hov, setHov] = useState(false);
  const [showEpicPicker, setShowEpicPicker] = useState(false);
  const p = PRIORITY[task.priority] || PRIORITY.medium;
  const epic = task.epicId ? epics.find(e => e.id === task.epicId) : null;
  const colColor = COL_COLORS[task.column] || C.textVLight;
  const colLabel = COLUMNS.find(c => c.id === task.column)?.title || task.column;

  return (
    <div draggable={draggable} onDragStart={onDragStart} onDragOver={e => { if (draggable) { e.preventDefault(); onDragOver?.(); } }} onDrop={onDrop} onDragEnd={onDragEnd}
      onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setShowEpicPicker(false); }}
      style={{
        display: "flex", alignItems: "center", gap: 8, padding: "8px 12px",
        background: isDragging ? C.accentLight : isDragOver ? `${C.accent}08` : hov ? C.cardHover : C.surface,
        borderRadius: 4, marginBottom: 2, cursor: draggable ? "grab" : "default",
        border: isDragOver ? `2px dashed ${C.borderFocus}` : `1px solid ${hov ? C.border : "transparent"}`,
        transition: "background .1s", position: "relative",
      }}>
      {/* Rank */}
      <span style={{ fontSize: 10, fontWeight: 700, color: C.textVLight, width: 24, textAlign: "center", flexShrink: 0 }}>{rank}</span>
      {/* Priority */}
      <span style={{ fontSize: 10, fontWeight: 800, color: p.color, width: 14, flexShrink: 0 }}>{p.icon}</span>
      {/* ID */}
      <span style={{ fontSize: 10, color: C.accent, fontWeight: 600, width: 55, flexShrink: 0 }}>{task.id}</span>
      {/* Title */}
      <span style={{ flex: 1, fontSize: 12, fontWeight: 500, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{task.title}</span>
      {/* Epic badge */}
      <div style={{ position: "relative" }}>
        <button onClick={e => { e.stopPropagation(); setShowEpicPicker(!showEpicPicker); }} style={{ padding: "2px 8px", borderRadius: 3, border: "none", fontSize: 9, fontWeight: 700, cursor: "pointer", background: epic ? `${epic.color}18` : C.colBg, color: epic ? epic.color : C.textVLight, whiteSpace: "nowrap" }}>
          {epic ? epic.name : "エピック"}
        </button>
        {showEpicPicker && (
          <div style={{ position: "absolute", right: 0, top: "100%", marginTop: 4, background: C.surface, border: `1px solid ${C.border}`, borderRadius: 4, boxShadow: "0 4px 12px rgba(9,30,66,0.2)", zIndex: 100, minWidth: 140 }}>
            <button onClick={() => { onSetEpic(task.id, ""); setShowEpicPicker(false); }} style={{ display: "block", width: "100%", padding: "6px 10px", border: "none", background: "transparent", cursor: "pointer", fontSize: 11, color: C.textLight, textAlign: "left" }}>なし</button>
            {epics.map(ep => (
              <button key={ep.id} onClick={() => { onSetEpic(task.id, ep.id); setShowEpicPicker(false); }} style={{ display: "flex", alignItems: "center", gap: 6, width: "100%", padding: "6px 10px", border: "none", background: task.epicId === ep.id ? C.accentLight : "transparent", cursor: "pointer", fontSize: 11, color: C.text, textAlign: "left" }}>
                <div style={{ width: 8, height: 8, borderRadius: 2, background: ep.color, flexShrink: 0 }} />{ep.name}
              </button>
            ))}
          </div>
        )}
      </div>
      {/* Status */}
      <span style={{ fontSize: 9, padding: "2px 6px", borderRadius: 2, background: `${colColor}18`, color: colColor, fontWeight: 700, flexShrink: 0 }}>{colLabel}</span>
    </div>
  );
}

/* ── Home Page ── */
function HomePage({ tasks, sprints, orgGoals, personalGoals, knowledge, members, onNavigate, featureFlags = DEFAULT_FEATURES }) {
  const total = tasks.length;
  const done = tasks.filter(t => t.column === "done").length;
  const inProgress = tasks.filter(t => t.column === "inprogress").length;
  const inReview = tasks.filter(t => t.column === "review").length;

  const activeSprint = sprints.find(s => s.status === "active");
  const approvedKB = knowledge.filter(a => a.status === "approved").length;
  const orgAvg = orgGoals.length > 0 ? Math.round(orgGoals.reduce((s, g) => s + g.progress, 0) / orgGoals.length) : 0;

  // Task distribution by column
  const colDist = COLUMNS.map(c => ({ ...c, count: tasks.filter(t => t.column === c.id).length }));

  // Member workload (assigned in-progress + review)
  const workload = members.map(m => {
    const active = tasks.filter(t => (t.column === "inprogress" || t.column === "review") && t.assignees.includes(m.id));
    return { ...m, count: active.length };
  }).sort((a, b) => b.count - a.count);

  // Recent knowledge
  const recentKB = [...knowledge].sort((a, b) => (b.updated || b.created || "").localeCompare(a.updated || a.created || "")).slice(0, 3);

  const StatCard = ({ label, value, sub, color, icon, onClick }) => (
    <div onClick={onClick} style={{
      background: C.surface, borderRadius: 6, padding: "16px 18px",
      border: `1px solid ${C.border}`, cursor: onClick ? "pointer" : "default",
      transition: "box-shadow .15s", flex: "1 1 0",
    }} onMouseEnter={e => { if (onClick) e.currentTarget.style.boxShadow = "0 2px 8px rgba(9,30,66,0.15)"; }} onMouseLeave={e => { e.currentTarget.style.boxShadow = "none"; }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, letterSpacing: 0.4, marginBottom: 4 }}>{label}</div>
          <div style={{ fontSize: 26, fontWeight: 700, color: color || C.text, lineHeight: 1 }}>{value}</div>
          {sub && <div style={{ fontSize: 11, color: C.textLight, marginTop: 4 }}>{sub}</div>}
        </div>
        {icon && <div style={{ fontSize: 20, opacity: 0.3 }}>{icon}</div>}
      </div>
    </div>
  );

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, flexShrink: 0 }}>
        <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>ダッシュボード</h1>
        <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>プロジェクト全体のサマリー</div>
      </header>

      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {/* ── Stat cards ── */}
        <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
          <StatCard label="タスク総数" value={total} sub={`${done} 完了 / ${total - done} 残り`} icon="📋" onClick={() => onNavigate("tasks")} />
          <StatCard label="進行中" value={inProgress + inReview} sub={`${inProgress} 開発中 · ${inReview} レビュー`} color={C.warning} icon="⚡" onClick={() => onNavigate("tasks")} />
          <StatCard label="完了率" value={`${total > 0 ? Math.round((done / total) * 100) : 0}%`} sub={<ProgressBar value={total > 0 ? (done / total) * 100 : 0} color={C.success} height={4} />} color={C.success} icon="✅" />
          {featureFlags.knowledge && <StatCard label="ナレッジ" value={knowledge.length} sub={`${approvedKB} 承認済`} color={C.purple} icon="📖" onClick={() => onNavigate("knowledge")} />}
        </div>

        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
          {/* ── Left column ── */}
          <div style={{ flex: "1 1 400px", display: "flex", flexDirection: "column", gap: 16, minWidth: 340 }}>

            {/* Active Sprint */}
            {featureFlags.sprints && <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>🏃 アクティブスプリント</span>
                <button onClick={() => onNavigate("sprints")} style={{ fontSize: 10, fontWeight: 600, color: C.accent, background: "none", border: "none", cursor: "pointer" }}>詳細 →</button>
              </div>
              {activeSprint ? (
                <div style={{ padding: "12px 16px" }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 4 }}>{activeSprint.name}</div>
                  {activeSprint.goal && <div style={{ fontSize: 11, color: C.textLight, marginBottom: 8 }}>{activeSprint.goal}</div>}
                  <div style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 11, color: C.textVLight }}>
                    <span>📅 {activeSprint.startDate} → {activeSprint.endDate}</span>
                    <span>📋 {activeSprint.tasks.length} タスク</span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ flex: 1 }}><ProgressBar value={activeSprint.totalPoints > 0 ? (activeSprint.completedPoints / activeSprint.totalPoints) * 100 : 0} color={C.accent} height={6} /></div>
                    <span style={{ fontSize: 12, fontWeight: 700, color: C.accent }}>{activeSprint.completedPoints}/{activeSprint.totalPoints} pts</span>
                  </div>
                  {/* Mini task status */}
                  <div style={{ display: "flex", gap: 6, marginTop: 10 }}>
                    {COLUMNS.filter(c => c.id !== "backlog").map(c => {
                      const cnt = activeSprint.tasks.filter(t => t.column === c.id).length;
                      return <div key={c.id} style={{ flex: 1, textAlign: "center", padding: "6px 0", background: C.colBg, borderRadius: 3 }}>
                        <div style={{ fontSize: 14, fontWeight: 700, color: COL_COLORS[c.id] }}>{cnt}</div>
                        <div style={{ fontSize: 8, color: C.textVLight, fontWeight: 600 }}>{c.title}</div>
                      </div>;
                    })}
                  </div>
                </div>
              ) : (
                <div style={{ padding: "20px 16px", textAlign: "center", color: C.textVLight, fontSize: 12 }}>アクティブなスプリントはありません</div>
              )}
            </div>}

            {/* Task distribution */}
            <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}` }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>📊 タスク分布</span>
              </div>
              <div style={{ padding: "12px 16px" }}>
                {colDist.map(c => {
                  const pct = total > 0 ? (c.count / total) * 100 : 0;
                  return (
                    <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                      <span style={{ fontSize: 10, fontWeight: 600, color: C.textLight, width: 90 }}>{c.title}</span>
                      <div style={{ flex: 1, height: 8, background: C.colBg, borderRadius: 4, overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${pct}%`, background: COL_COLORS[c.id], borderRadius: 4, transition: "width .3s" }} />
                      </div>
                      <span style={{ fontSize: 11, fontWeight: 600, color: COL_COLORS[c.id], minWidth: 20, textAlign: "right" }}>{c.count}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Organization goals progress */}
            {featureFlags.goals && <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>🎯 組織目標の進捗</span>
                <button onClick={() => onNavigate("goals")} style={{ fontSize: 10, fontWeight: 600, color: C.accent, background: "none", border: "none", cursor: "pointer" }}>詳細 →</button>
              </div>
              <div style={{ padding: "12px 16px" }}>
                {ORG_LEVELS.map(level => {
                  const goals = orgGoals.filter(g => g.level === level.id);
                  if (goals.length === 0) return null;
                  const avg = Math.round(goals.reduce((s, g) => s + g.progress, 0) / goals.length);
                  return (
                    <div key={level.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                      <span style={{ fontSize: 14 }}>{level.icon}</span>
                      <span style={{ fontSize: 11, fontWeight: 600, color: C.text, width: 90 }}>{level.label}</span>
                      <div style={{ flex: 1 }}><ProgressBar value={avg} color={level.color} height={5} /></div>
                      <span style={{ fontSize: 11, fontWeight: 600, color: level.color, minWidth: 32, textAlign: "right" }}>{avg}%</span>
                    </div>
                  );
                })}
                {orgGoals.length === 0 && <div style={{ fontSize: 12, color: C.textVLight, textAlign: "center", padding: 8 }}>目標が未設定です</div>}
              </div>
            </div>}
          </div>

          {/* ── Right column ── */}
          <div style={{ flex: "1 1 300px", display: "flex", flexDirection: "column", gap: 16, minWidth: 280 }}>

            {/* Member workload */}
            <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}` }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>👥 メンバー稼働状況</span>
              </div>
              <div style={{ padding: "8px 16px" }}>
                {workload.map(m => (
                  <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 0", borderBottom: `1px solid ${C.colBg}` }}>
                    <Avatar member={m} size={28} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{m.name}</div>
                      <div style={{ fontSize: 10, color: C.textVLight }}>{m.count > 0 ? `${m.count}件 作業中` : "空き"}</div>
                    </div>
                    <div style={{ display: "flex", gap: 2 }}>
                      {Array.from({ length: Math.min(m.count, 5) }).map((_, i) => (
                        <div key={i} style={{ width: 6, height: 16, borderRadius: 2, background: m.count > 3 ? C.danger : m.count > 1 ? C.warning : C.success }} />
                      ))}
                      {m.count === 0 && <div style={{ width: 6, height: 16, borderRadius: 2, background: C.border }} />}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent knowledge */}
            {featureFlags.knowledge && <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>📖 最新ナレッジ</span>
                <button onClick={() => onNavigate("knowledge")} style={{ fontSize: 10, fontWeight: 600, color: C.accent, background: "none", border: "none", cursor: "pointer" }}>すべて →</button>
              </div>
              {recentKB.length === 0 && <div style={{ padding: "16px", textAlign: "center", color: C.textVLight, fontSize: 12 }}>記事がありません</div>}
              {recentKB.map(a => {
                const cat = KB_CATEGORIES.find(c => c.id === a.category);
                const st = KB_STATUSES.find(s => s.id === a.status);
                return (
                  <div key={a.id} onClick={() => onNavigate("knowledge")} style={{ padding: "10px 16px", borderBottom: `1px solid ${C.colBg}`, cursor: "pointer", transition: "background .1s" }} onMouseEnter={e => e.currentTarget.style.background = C.cardHover} onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
                      {cat && <span style={{ fontSize: 9, padding: "1px 5px", borderRadius: 2, background: `${cat.color}15`, color: cat.color, fontWeight: 700 }}>{cat.label}</span>}
                      {st && <span style={{ width: 5, height: 5, borderRadius: "50%", background: st.color }} />}
                      <span style={{ fontSize: 9, color: C.textVLight, marginLeft: "auto" }}>{(a.updated || a.created || "").slice(0, 10)}</span>
                    </div>
                    <div style={{ fontSize: 12, fontWeight: 600, color: C.text, lineHeight: 1.4 }}>{a.title}</div>
                  </div>
                );
              })}
            </div>}

            {/* Quick stats mini cards */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
              {featureFlags.sprints && <div style={{ background: C.surface, borderRadius: 6, padding: "12px 14px", border: `1px solid ${C.border}`, textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.accent }}>{sprints.length}</div>
                <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>スプリント</div>
              </div>}
              <div style={{ background: C.surface, borderRadius: 6, padding: "12px 14px", border: `1px solid ${C.border}`, textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.accent }}>{members.length}</div>
                <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>メンバー</div>
              </div>
              {featureFlags.goals && <div style={{ background: C.surface, borderRadius: 6, padding: "12px 14px", border: `1px solid ${C.border}`, textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: orgAvg >= 50 ? C.success : C.warning }}>{orgAvg}%</div>
                <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>組織目標平均</div>
              </div>}
              {featureFlags.goals && <div style={{ background: C.surface, borderRadius: 6, padding: "12px 14px", border: `1px solid ${C.border}`, textAlign: "center" }}>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.accent }}>{personalGoals.length}</div>
                <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>個人目標</div>
              </div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Sprint Constants ── */
const SPRINT_STATUSES = [
  { id: "planning", label: "計画中", color: C.textVLight },
  { id: "active", label: "進行中", color: C.accent },
  { id: "completed", label: "完了", color: C.success },
];
const FALLBACK_SPRINTS = [
  { id: "sp-1", name: "Sprint 1", goal: "認証基盤とUI骨格の構築", startDate: "2026-05-05", endDate: "2026-05-18", status: "active", projectId: "proj-1",
    tasks: [
      { id: "DASH-1", title: "UIデザインの作成", column: "todo", priority: "high", points: 5 },
      { id: "DASH-2", title: "APIエンドポイント設計", column: "inprogress", priority: "medium", points: 8 },
      { id: "DASH-3", title: "認証フローの実装", column: "review", priority: "high", points: 13 },
      { id: "DASH-4", title: "プロジェクト初期設定", column: "done", priority: "low", points: 3 },
      { id: "DASH-7", title: "データベーススキーマ設計", column: "inprogress", priority: "high", points: 8 },
    ],
    totalPoints: 37, completedPoints: 3,
  },
];

/* ── Sprint Page ── */
function SprintPage({ sprints, tasks, onSaveSprint, onDeleteSprint, onAddTask, onRemoveTask, onUpdatePoints, apiAvailable, tokenBudget }) {
  const [selected, setSelected] = useState(sprints[0]?.id || null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: "", goal: "", startDate: "", endDate: "" });
  const [showAddTask, setShowAddTask] = useState(false);

  const sprint = sprints.find(s => s.id === selected);

  const handleCreate = () => {
    if (!form.name || !form.startDate || !form.endDate) return;
    const id = `sp-${sprintNextId++}`;
    onSaveSprint({ id, ...form, status: "planning", tasks: [], totalPoints: 0, completedPoints: 0 });
    setSelected(id);
    setCreating(false);
    setForm({ name: "", goal: "", startDate: "", endDate: "" });
  };

  // Unassigned tasks (not in any sprint)
  const assignedIds = new Set(sprints.flatMap(s => s.tasks.map(t => t.id)));
  const unassigned = tasks.filter(t => !assignedIds.has(t.id) && t.column !== "done");

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>スプリント</h1>
          {/* Sprint selector tabs */}
          <div style={{ display: "flex", gap: 4 }}>
            {sprints.map(s => {
              const st = SPRINT_STATUSES.find(x => x.id === s.status);
              return <button key={s.id} onClick={() => { setSelected(s.id); setCreating(false); }} style={{ padding: "4px 12px", borderRadius: 3, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600, background: selected === s.id ? C.accentLight : C.colBg, color: selected === s.id ? C.accent : C.textLight, display: "flex", alignItems: "center", gap: 4 }}><span style={{ width: 6, height: 6, borderRadius: "50%", background: st?.color || C.textVLight }} />{s.name}</button>;
            })}
          </div>
        </div>
        <button onClick={() => setCreating(true)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 新規スプリント</button>
      </header>

      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {creating ? (
          <div style={{ maxWidth: 500, background: C.surface, borderRadius: 6, padding: 24, border: `1px solid ${C.border}` }}>
            <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 600, color: C.text }}>新規スプリント作成</h3>
            <Lbl>スプリント名 *</Lbl><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Sprint 2" style={{ ...inpStyle, marginBottom: 12 }} onFocus={onFocus} onBlur={onBlur} />
            <Lbl>スプリントゴール</Lbl><textarea value={form.goal} onChange={e => setForm({ ...form, goal: e.target.value })} placeholder="このスプリントで達成する目標" rows={2} style={{ ...inpStyle, marginBottom: 12, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />
            <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
              <div style={{ flex: 1 }}><Lbl>開始日 *</Lbl><input type="date" value={form.startDate} onChange={e => setForm({ ...form, startDate: e.target.value })} style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
              <div style={{ flex: 1 }}><Lbl>終了日 *</Lbl><input type="date" value={form.endDate} onChange={e => setForm({ ...form, endDate: e.target.value })} style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
            </div>
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button onClick={() => setCreating(false)} style={{ padding: "8px 16px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12 }}>キャンセル</button>
              <button onClick={handleCreate} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>作成</button>
            </div>
          </div>
        ) : sprint ? (
          <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexWrap: "wrap" }}>
            {/* Left: Sprint info + tasks */}
            <div style={{ flex: "1 1 400px", minWidth: 350 }}>
              {/* Sprint header card */}
              <div style={{ background: C.surface, borderRadius: 6, padding: "16px 20px", border: `1px solid ${C.border}`, marginBottom: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div>
                    <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: C.text }}>{sprint.name}</h2>
                    {sprint.goal && <div style={{ fontSize: 12, color: C.textLight, marginTop: 4 }}>{sprint.goal}</div>}
                  </div>
                  <div style={{ display: "flex", gap: 4 }}>
                    {SPRINT_STATUSES.map(st => (
                      <button key={st.id} onClick={() => onSaveSprint({ ...sprint, status: st.id })} style={{ padding: "3px 10px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: sprint.status === st.id ? (st.id === "active" ? C.accentLight : st.id === "completed" ? C.successBg : C.colBg) : C.colBg, color: sprint.status === st.id ? st.color : C.textLight }}>{st.label}</button>
                    ))}
                    <button onClick={() => onDeleteSprint(sprint.id)} style={{ ...aBtn, color: C.danger, fontSize: 13, marginLeft: 4 }}>🗑</button>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 16, fontSize: 11, color: C.textVLight }}>
                  <span>📅 {sprint.startDate} → {sprint.endDate}</span>
                  <span>📊 {sprint.completedPoints}/{sprint.totalPoints} pts</span>
                  <span>📋 {sprint.tasks.length} タスク</span>
                </div>
                {/* Progress bar */}
                <div style={{ marginTop: 10 }}><ProgressBar value={sprint.totalPoints > 0 ? (sprint.completedPoints / sprint.totalPoints) * 100 : 0} color={C.accent} height={6} /></div>
              </div>

              {/* Sprint backlog */}
              <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                <div style={{ padding: "10px 16px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>スプリントバックログ</span>
                  <button onClick={() => setShowAddTask(!showAddTask)} style={{ fontSize: 11, fontWeight: 600, color: C.accent, background: "none", border: "none", cursor: "pointer" }}>{showAddTask ? "閉じる" : "+ タスク追加"}</button>
                </div>
                {/* Add task panel */}
                {showAddTask && unassigned.length > 0 && (
                  <div style={{ padding: "8px 16px", background: C.colBg, borderBottom: `1px solid ${C.border}`, maxHeight: 180, overflowY: "auto" }}>
                    <div style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, marginBottom: 6 }}>未割当タスク ({unassigned.length})</div>
                    {unassigned.map(t => (
                      <div key={t.id} onClick={() => { onAddTask(sprint.id, t.id, 0); }} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 8px", borderRadius: 3, cursor: "pointer", fontSize: 12, color: C.text, marginBottom: 2, background: C.surface, border: `1px solid ${C.border}` }}>
                        <span style={{ fontSize: 10, color: C.accent, fontWeight: 600 }}>{t.id}</span>
                        <span style={{ flex: 1 }}>{t.title}</span>
                        <span style={{ fontSize: 10, color: C.success, fontWeight: 600 }}>+ 追加</span>
                      </div>
                    ))}
                  </div>
                )}
                {showAddTask && unassigned.length === 0 && (
                  <div style={{ padding: "12px 16px", background: C.colBg, borderBottom: `1px solid ${C.border}`, fontSize: 11, color: C.textVLight }}>未割当のタスクがありません</div>
                )}
                {/* Task list */}
                {sprint.tasks.length === 0 && <div style={{ padding: "16px", textAlign: "center", color: C.textVLight, fontSize: 12 }}>タスクがありません</div>}
                {sprint.tasks.map(t => (
                  <SprintTaskRow key={t.id} task={t} sprintId={sprint.id} onRemove={onRemoveTask} onUpdatePoints={onUpdatePoints} />
                ))}
              </div>
            </div>

            {/* Right: Burndown chart */}
            <div style={{ flex: "1 1 350px", minWidth: 300 }}>
              <BurndownChart sprint={sprint} />

              {/* Token Budget Widget */}
              {tokenBudget && (
                <div style={{ background: C.surface, borderRadius: 6, padding: "16px 20px", border: `1px solid ${C.border}`, marginTop: 12 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: C.text, marginBottom: 10 }}>🎛️ AIトークン予算</div>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <div style={{ flex: 1 }}>
                      <ProgressBar value={0} color={C.accent} height={6} />
                    </div>
                    <span style={{ fontSize: 11, fontWeight: 600, color: C.textVLight }}>0%</span>
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
                    <div style={{ textAlign: "center", padding: "6px 0", background: C.colBg, borderRadius: 3 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{(tokenBudget.maxTokens / 1000000).toFixed(1)}M</div>
                      <div style={{ fontSize: 8, color: C.textVLight, fontWeight: 600 }}>トークン上限</div>
                    </div>
                    <div style={{ textAlign: "center", padding: "6px 0", background: C.colBg, borderRadius: 3 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{tokenBudget.maxToolCalls}</div>
                      <div style={{ fontSize: 8, color: C.textVLight, fontWeight: 600 }}>ツール呼出上限</div>
                    </div>
                  </div>
                  <div style={{ marginTop: 8, fontSize: 10, color: C.textVLight, textAlign: "center" }}>警告: {tokenBudget.warningPct}%到達時</div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div style={{ textAlign: "center", padding: 60, color: C.textVLight }}>
            <div style={{ fontSize: 40, marginBottom: 8, opacity: 0.2 }}>🏃</div>
            <div style={{ fontSize: 13 }}>スプリントを作成してください</div>
          </div>
        )}
      </div>
    </div>
  );
}

function SprintTaskRow({ task, sprintId, onRemove, onUpdatePoints }) {
  const [hov, setHov] = useState(false);
  const [editPts, setEditPts] = useState(false);
  const [pts, setPts] = useState(task.points);
  const p = PRIORITY[task.priority] || PRIORITY.medium;
  const colColor = COL_COLORS[task.column] || C.textVLight;
  const colLabel = COLUMNS.find(c => c.id === task.column)?.title || task.column;

  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setEditPts(false); }}
      style={{ display: "flex", alignItems: "center", gap: 8, padding: "8px 16px", borderBottom: `1px solid ${C.colBg}`, background: hov ? C.cardHover : "transparent" }}>
      <span style={{ fontSize: 10, color: C.accent, fontWeight: 600, width: 55 }}>{task.id}</span>
      <span title={p.label} style={{ fontSize: 10, fontWeight: 800, color: p.color, width: 14 }}>{p.icon}</span>
      <span style={{ flex: 1, fontSize: 12, fontWeight: 500, color: C.text }}>{task.title}</span>
      <span style={{ fontSize: 9, padding: "2px 6px", borderRadius: 2, background: `${colColor}18`, color: colColor, fontWeight: 700 }}>{colLabel}</span>
      {/* Story points */}
      {editPts ? (
        <input type="number" min={0} max={99} value={pts} onChange={e => setPts(Number(e.target.value))}
          onBlur={() => { onUpdatePoints(sprintId, task.id, pts); setEditPts(false); }}
          onKeyDown={e => { if (e.key === "Enter") { onUpdatePoints(sprintId, task.id, pts); setEditPts(false); } }}
          style={{ width: 40, padding: "2px 4px", borderRadius: 3, border: `2px solid ${C.borderFocus}`, fontSize: 11, textAlign: "center", outline: "none" }}
          autoFocus />
      ) : (
        <span onClick={() => setEditPts(true)} style={{ fontSize: 11, fontWeight: 700, color: C.accent, background: C.accentLight, borderRadius: 10, padding: "1px 8px", cursor: "pointer", minWidth: 24, textAlign: "center" }} title="クリックでポイント編集">{task.points || 0}</span>
      )}
      {hov && <button onClick={() => onRemove(sprintId, task.id)} style={{ ...aBtn, color: C.danger, fontSize: 11 }}>✕</button>}
    </div>
  );
}

/* ── Burndown Chart (SVG) ── */
function BurndownChart({ sprint }) {
  const start = new Date(sprint.startDate);
  const end = new Date(sprint.endDate);
  const totalDays = Math.max(1, Math.ceil((end - start) / (1000 * 60 * 60 * 24)));
  const totalPts = sprint.totalPoints || 1;
  const today = new Date();

  // Calculate day-by-day status from tasks
  const daysDone = Math.min(totalDays, Math.ceil((today - start) / (1000 * 60 * 60 * 24)));
  const remaining = totalPts - sprint.completedPoints;

  const W = 360, H = 200, PAD = { t: 20, r: 20, b: 30, l: 35 };
  const gW = W - PAD.l - PAD.r, gH = H - PAD.t - PAD.b;

  // Ideal line points (from totalPts → 0)
  const idealPts = [];
  for (let i = 0; i <= totalDays; i++) {
    const x = PAD.l + (i / totalDays) * gW;
    const remainAtDay = totalPts * (1 - i / totalDays);
    const y = PAD.t + (1 - remainAtDay / totalPts) * gH;
    idealPts.push(`${x},${y}`);
  }

  // Simple actual line: start → current
  const actualPts = [];
  actualPts.push(`${PAD.l},${PAD.t}`); // day 0 = full remaining (top)
  if (daysDone > 0) {
    const x = PAD.l + (Math.min(daysDone, totalDays) / totalDays) * gW;
    const y = PAD.t + (1 - remaining / totalPts) * gH; // remaining towards bottom
    actualPts.push(`${x},${y}`);
  }

  // Y-axis labels (top=totalPts, bottom=0)
  const yLabels = [totalPts, Math.round(totalPts / 2), 0];

  // X-axis: start, mid, end
  const mid = new Date(start); mid.setDate(mid.getDate() + Math.floor(totalDays / 2));
  const fmt = d => `${d.getMonth() + 1}/${d.getDate()}`;

  const pctDone = totalPts > 0 ? Math.round((sprint.completedPoints / totalPts) * 100) : 0;

  return (
    <div style={{ background: C.surface, borderRadius: 6, padding: "16px 20px", border: `1px solid ${C.border}` }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>バーンダウンチャート</span>
        <span style={{ fontSize: 11, fontWeight: 600, color: pctDone >= 80 ? C.success : pctDone >= 40 ? C.warning : C.accent }}>{pctDone}% 完了</span>
      </div>

      <svg width={W} height={H} style={{ display: "block" }}>
        {/* Grid lines */}
        {yLabels.map((v, i) => {
          const y = PAD.t + (1 - v / totalPts) * gH;
          return <g key={i}><line x1={PAD.l} y1={y} x2={W - PAD.r} y2={y} stroke={C.border} strokeDasharray="3,3" /><text x={PAD.l - 6} y={y + 3} textAnchor="end" fontSize={9} fill={C.textVLight}>{v}</text></g>;
        })}
        {/* X axis */}
        <line x1={PAD.l} y1={H - PAD.b} x2={W - PAD.r} y2={H - PAD.b} stroke={C.border} />
        <text x={PAD.l} y={H - PAD.b + 14} fontSize={9} fill={C.textVLight}>{fmt(start)}</text>
        <text x={PAD.l + gW / 2} y={H - PAD.b + 14} textAnchor="middle" fontSize={9} fill={C.textVLight}>{fmt(mid)}</text>
        <text x={W - PAD.r} y={H - PAD.b + 14} textAnchor="end" fontSize={9} fill={C.textVLight}>{fmt(end)}</text>
        {/* Ideal line */}
        <polyline points={idealPts.join(" ")} fill="none" stroke={C.border} strokeWidth={2} strokeDasharray="6,4" />
        {/* Actual line */}
        {actualPts.length > 1 && <polyline points={actualPts.join(" ")} fill="none" stroke={C.accent} strokeWidth={2.5} strokeLinecap="round" />}
        {/* Current point */}
        {actualPts.length > 1 && (() => {
          const last = actualPts[actualPts.length - 1].split(",");
          return <circle cx={last[0]} cy={last[1]} r={4} fill={C.accent} stroke="#fff" strokeWidth={2} />;
        })()}
        {/* Today marker */}
        {daysDone > 0 && daysDone < totalDays && (() => {
          const x = PAD.l + (daysDone / totalDays) * gW;
          return <line x1={x} y1={PAD.t} x2={x} y2={H - PAD.b} stroke={C.danger} strokeWidth={1} strokeDasharray="4,3" opacity={0.5} />;
        })()}
      </svg>

      <div style={{ display: "flex", gap: 16, marginTop: 8, justifyContent: "center" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textVLight }}><div style={{ width: 16, height: 2, background: C.border, borderRadius: 1 }} /> 理想</div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textVLight }}><div style={{ width: 16, height: 2.5, background: C.accent, borderRadius: 1 }} /> 実績</div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 10, color: C.textVLight }}><div style={{ width: 8, height: 0, borderTop: `1px dashed ${C.danger}` }} /> 今日</div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 12 }}>
        <div style={{ textAlign: "center", padding: "8px 0", background: C.colBg, borderRadius: 4 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>{totalPts}</div>
          <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>合計ポイント</div>
        </div>
        <div style={{ textAlign: "center", padding: "8px 0", background: C.colBg, borderRadius: 4 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: C.success }}>{sprint.completedPoints}</div>
          <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>完了</div>
        </div>
        <div style={{ textAlign: "center", padding: "8px 0", background: C.colBg, borderRadius: 4 }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: remaining > 0 ? C.warning : C.success }}>{remaining}</div>
          <div style={{ fontSize: 9, color: C.textVLight, fontWeight: 600 }}>残り</div>
        </div>
      </div>
    </div>
  );
}

/* ── Retrospective Constants ── */
const KPT_TYPES = [
  { id: "keep", label: "Keep", color: C.success, bg: C.successBg, icon: "✅", desc: "続けたいこと" },
  { id: "problem", label: "Problem", color: C.danger, bg: C.dangerBg, icon: "⚠️", desc: "問題・課題" },
  { id: "try", label: "Try", color: C.accent, bg: C.accentLight, icon: "💡", desc: "試したいこと" },
];
const FALLBACK_RETROS = [
  { id: "retro-1", sprintId: "sp-1", title: "Sprint 1 ふりかえり", date: "2026-05-18", projectId: "proj-1",
    items: [
      { id: 1, type: "keep", content: "デイリースクラムが定着してきた", votes: 3, action: "" },
      { id: 2, type: "keep", content: "PRレビューの速度が上がった", votes: 2, action: "" },
      { id: 3, type: "problem", content: "見積もりの精度が低い（実績が1.5倍）", votes: 4, action: "ストーリーポイントの基準を再定義する" },
      { id: 4, type: "problem", content: "テスト環境が不安定", votes: 2, action: "CI環境のDockerイメージを固定" },
      { id: 5, type: "try", content: "モブプログラミングを週1回試す", votes: 3, action: "" },
      { id: 6, type: "try", content: "テストカバレッジ計測を自動化", votes: 1, action: "" },
    ],
  },
];

/* ── Retro Page ── */
function RetroPage({ retros, sprints, onSave, onDelete, onExportToKnowledge }) {
  const [selected, setSelected] = useState(retros[0]?.id || null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ title: "", sprintId: "", date: new Date().toISOString().slice(0, 10) });
  const [newItem, setNewItem] = useState({ type: "keep", content: "" });

  const retro = retros.find(r => r.id === selected);

  const handleCreate = () => {
    if (!form.title.trim()) return;
    const id = `retro-${retroNextId++}`;
    onSave({ id, ...form, title: form.title.trim(), items: [], projectId: "" });
    setSelected(id);
    setCreating(false);
    setForm({ title: "", sprintId: "", date: new Date().toISOString().slice(0, 10) });
  };

  const addItem = () => {
    if (!newItem.content.trim() || !retro) return;
    const item = { id: retroItemNextId++, type: newItem.type, content: newItem.content.trim(), votes: 0, action: "" };
    onSave({ ...retro, items: [...retro.items, item] });
    setNewItem({ ...newItem, content: "" });
  };

  const updateItem = (itemId, updates) => {
    if (!retro) return;
    onSave({ ...retro, items: retro.items.map(i => i.id === itemId ? { ...i, ...updates } : i) });
  };

  const removeItem = (itemId) => {
    if (!retro) return;
    onSave({ ...retro, items: retro.items.filter(i => i.id !== itemId) });
  };

  const voteItem = (itemId) => {
    if (!retro) return;
    onSave({ ...retro, items: retro.items.map(i => i.id === itemId ? { ...i, votes: i.votes + 1 } : i) });
  };

  const handleExport = () => {
    if (!retro) return;
    onExportToKnowledge(retro);
  };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>ふりかえり</h1>
          <div style={{ display: "flex", gap: 4 }}>
            {retros.map(r => (
              <button key={r.id} onClick={() => { setSelected(r.id); setCreating(false); }} style={{
                padding: "4px 12px", borderRadius: 3, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600,
                background: selected === r.id ? C.accentLight : C.colBg, color: selected === r.id ? C.accent : C.textLight,
              }}>{r.title}</button>
            ))}
          </div>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          {retro && <button onClick={handleExport} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.text, cursor: "pointer", fontSize: 12, fontWeight: 600 }}>📖 ナレッジに変換</button>}
          <button onClick={() => setCreating(true)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 新規</button>
        </div>
      </header>

      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        {creating ? (
          <div style={{ maxWidth: 500, background: C.surface, borderRadius: 6, padding: 24, border: `1px solid ${C.border}` }}>
            <h3 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 600, color: C.text }}>新規ふりかえり作成</h3>
            <Lbl>タイトル *</Lbl><input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="Sprint 2 ふりかえり" style={{ ...inpStyle, marginBottom: 12 }} onFocus={onFocus} onBlur={onBlur} />
            <Lbl>対象スプリント</Lbl>
            <select value={form.sprintId} onChange={e => setForm({ ...form, sprintId: e.target.value })} style={{ ...inpStyle, marginBottom: 12 }}>
              <option value="">（選択なし）</option>
              {sprints.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <Lbl>日付</Lbl><input type="date" value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} style={{ ...inpStyle, marginBottom: 16 }} onFocus={onFocus} onBlur={onBlur} />
            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button onClick={() => setCreating(false)} style={{ padding: "8px 16px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12 }}>キャンセル</button>
              <button onClick={handleCreate} style={{ padding: "8px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>作成</button>
            </div>
          </div>
        ) : retro ? (
          <div>
            {/* Retro info */}
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
              <span style={{ fontSize: 11, color: C.textVLight }}>📅 {retro.date}</span>
              {retro.sprintId && <span style={{ fontSize: 11, color: C.accent, fontWeight: 600 }}>🏃 {sprints.find(s => s.id === retro.sprintId)?.name || retro.sprintId}</span>}
              <button onClick={() => onDelete(retro.id)} style={{ ...aBtn, color: C.danger, marginLeft: "auto" }}>🗑 削除</button>
            </div>

            {/* Add item form */}
            <div style={{ display: "flex", gap: 8, marginBottom: 20, background: C.surface, padding: "12px 16px", borderRadius: 6, border: `1px solid ${C.border}`, alignItems: "flex-end" }}>
              <div>
                <Lbl>種別</Lbl>
                <div style={{ display: "flex", gap: 4 }}>
                  {KPT_TYPES.map(t => (
                    <button key={t.id} onClick={() => setNewItem({ ...newItem, type: t.id })} style={{
                      padding: "4px 10px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none",
                      background: newItem.type === t.id ? t.bg : C.colBg, color: newItem.type === t.id ? t.color : C.textLight,
                    }}>{t.icon} {t.label}</button>
                  ))}
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <Lbl>内容</Lbl>
                <input value={newItem.content} onChange={e => setNewItem({ ...newItem, content: e.target.value })}
                  onKeyDown={e => e.key === "Enter" && addItem()}
                  placeholder="ふりかえりの項目を入力 (Enter で追加)" style={inpStyle} onFocus={onFocus} onBlur={onBlur} />
              </div>
              <button onClick={addItem} style={{ padding: "8px 16px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>追加</button>
            </div>

            {/* KPT columns */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
              {KPT_TYPES.map(type => {
                const items = retro.items.filter(i => i.type === type.id).sort((a, b) => b.votes - a.votes);
                return (
                  <div key={type.id} style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
                    <div style={{ padding: "10px 14px", borderBottom: `1px solid ${C.border}`, background: type.bg, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <span style={{ fontSize: 12, fontWeight: 700, color: type.color }}>{type.icon} {type.label}</span>
                      <span style={{ fontSize: 10, fontWeight: 600, color: type.color }}>{items.length}件</span>
                    </div>
                    <div style={{ padding: "6px" }}>
                      {items.length === 0 && <div style={{ padding: "16px 8px", textAlign: "center", fontSize: 11, color: C.textVLight }}>{type.desc}を追加</div>}
                      {items.map(item => (
                        <RetroItem key={item.id} item={item} type={type} onVote={() => voteItem(item.id)} onUpdate={(u) => updateItem(item.id, u)} onRemove={() => removeItem(item.id)} />
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div style={{ textAlign: "center", padding: 60, color: C.textVLight }}>
            <div style={{ fontSize: 40, marginBottom: 8, opacity: 0.2 }}>🔄</div>
            <div style={{ fontSize: 13 }}>ふりかえりを作成してください</div>
          </div>
        )}
      </div>
    </div>
  );
}

function RetroItem({ item, type, onVote, onUpdate, onRemove }) {
  const [hov, setHov] = useState(false);
  const [editAction, setEditAction] = useState(false);
  const [action, setAction] = useState(item.action || "");
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setEditAction(false); }}
      style={{ padding: "8px 10px", borderRadius: 4, marginBottom: 4, background: hov ? `${type.color}08` : "transparent", transition: "background .1s" }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
        <button onClick={onVote} style={{ padding: "2px 6px", borderRadius: 3, border: `1px solid ${C.border}`, background: item.votes > 0 ? type.bg : C.surface, color: item.votes > 0 ? type.color : C.textVLight, cursor: "pointer", fontSize: 10, fontWeight: 700, flexShrink: 0, minWidth: 24, textAlign: "center" }} title="投票">👍 {item.votes}</button>
        <div style={{ flex: 1, fontSize: 12, color: C.text, lineHeight: 1.5 }}>{item.content}</div>
        {hov && <button onClick={onRemove} style={{ ...aBtn, color: C.danger, fontSize: 10, flexShrink: 0 }}>✕</button>}
      </div>
      {/* Action item */}
      {item.action && !editAction && (
        <div onClick={() => setEditAction(true)} style={{ marginTop: 6, marginLeft: 36, fontSize: 11, color: C.accent, background: C.accentLight, padding: "4px 8px", borderRadius: 3, cursor: "pointer" }}>
          📌 {item.action}
        </div>
      )}
      {!item.action && hov && !editAction && (
        <button onClick={() => setEditAction(true)} style={{ marginTop: 4, marginLeft: 36, fontSize: 10, color: C.textVLight, background: "none", border: "none", cursor: "pointer" }}>+ アクション追加</button>
      )}
      {editAction && (
        <div style={{ marginTop: 6, marginLeft: 36, display: "flex", gap: 4 }}>
          <input value={action} onChange={e => setAction(e.target.value)} onKeyDown={e => { if (e.key === "Enter") { onUpdate({ action }); setEditAction(false); } }} placeholder="アクションアイテム" style={{ ...inpStyle, flex: 1, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} autoFocus />
          <button onClick={() => { onUpdate({ action }); setEditAction(false); }} style={{ padding: "4px 10px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 10, fontWeight: 600 }}>保存</button>
        </div>
      )}
    </div>
  );
}

/* ── Knowledge Constants ── */
const KB_CATEGORIES = [
  { id: "frontend", label: "フロントエンド", color: "#0052cc" },
  { id: "backend", label: "バックエンド", color: "#ff8b00" },
  { id: "infra", label: "インフラ", color: "#00875a" },
  { id: "design", label: "デザイン", color: "#6554c0" },
  { id: "pm", label: "プロジェクト管理", color: "#00b8d9" },
  { id: "security", label: "セキュリティ", color: "#de350b" },
  { id: "general", label: "一般", color: "#8993a4" },
];
const KB_STATUSES = [
  { id: "draft", label: "下書き", color: C.textVLight },
  { id: "reviewed", label: "レビュー済", color: C.warning },
  { id: "approved", label: "承認済", color: C.success },
];
const FALLBACK_KB = [
  { id: "kb-001", title: "React状態管理ベストプラクティス", category: "frontend", author: "Yuki T.", status: "approved", summary: "Reactの状態管理パターンを比較し推奨アーキテクチャを解説", body: "# React状態管理ベストプラクティス\n\n## 概要\nReactアプリケーションの状態管理は複雑になりがちです。\n\n## パターン比較\n\n### useState / useReducer\n- コンポーネントローカル\n- シンプルなUI状態に最適\n\n### Context API\n- テーマ、認証など低頻度更新向け\n- 高頻度更新にはパフォーマンス問題\n\n### Zustand / Jotai\n- 軽量で導入が容易\n- ボイラープレートが少ない\n\n## 推奨\n- まずuseStateから始め、必要に応じてZustandへ\n- グローバル状態は最小限に", version: 2, tags: ["React", "状態管理", "hooks"], related: ["kb-002"], created: "2026-05-08", updated: "2026-05-11" },
  { id: "kb-002", title: "REST API設計ガイドライン", category: "backend", author: "Kenji S.", status: "approved", summary: "RESTful API設計の命名規則、レスポンス形式、バージョニング戦略", body: "# REST API設計ガイドライン\n\n## エンドポイント命名\n- 複数形名詞: `/api/users`, `/api/tasks`\n- ネスト: `/api/users/:id/tasks`\n\n## レスポンス形式\n```json\n{\n  \"data\": [...],\n  \"meta\": { \"total\": 100, \"page\": 1 }\n}\n```\n\n## ステータスコード\n- 200: 成功\n- 201: 作成\n- 400: リクエスト不正\n- 404: 未検出\n- 500: サーバーエラー\n\n## バージョニング\n- URLパス: `/api/v1/users`\n- ヘッダー: `Accept: application/vnd.api.v1+json`", version: 1, tags: ["API", "REST", "設計"], related: ["kb-001"], created: "2026-05-06", updated: "2026-05-06" },
  { id: "kb-003", title: "Terraform導入手順書", category: "infra", author: "Taro H.", status: "reviewed", summary: "AWS環境をTerraformでIaC管理するためのセットアップと運用フロー", body: "# Terraform導入手順書\n\n## 前提条件\n- AWS CLI設定済み\n- Terraform v1.5+\n\n## 初期セットアップ\n```bash\nterraform init\nterraform plan\nterraform apply\n```\n\n## ベストプラクティス\n- `modules/` でリソースを分割\n- `tfstate` はS3 + DynamoDBで管理\n- CI/CDで `plan` を自動実行", version: 1, tags: ["Terraform", "AWS", "IaC"], related: [], created: "2026-05-09", updated: "2026-05-10" },
  { id: "kb-004", title: "セキュリティチェックリスト", category: "security", author: "Sakura M.", status: "draft", summary: "リリース前に確認すべきセキュリティ項目のチェックリスト", body: "# セキュリティチェックリスト\n\n## 認証\n- [ ] パスワードハッシュ化 (bcrypt)\n- [ ] JWT有効期限設定\n- [ ] リフレッシュトークン実装\n\n## 入力バリデーション\n- [ ] SQLインジェクション対策\n- [ ] XSS対策\n- [ ] CSRF対策\n\n## インフラ\n- [ ] HTTPS強制\n- [ ] CORS設定\n- [ ] レートリミット", version: 1, tags: ["セキュリティ", "チェックリスト"], related: [], created: "2026-05-11", updated: "2026-05-11" },
];

/* ── Knowledge Page ── */
function KnowledgePage({ articles, onSave, onDelete, apiAvailable, members }) {
  const [selected, setSelected] = useState(null); // article id or null
  const [editing, setEditing] = useState(null);   // article object being edited, or null
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [searchQ, setSearchQ] = useState("");

  const filtered = articles.filter(a => {
    if (filterCat !== "all" && a.category !== filterCat) return false;
    if (filterStatus !== "all" && a.status !== filterStatus) return false;
    if (searchQ && !a.title.toLowerCase().includes(searchQ.toLowerCase()) && !(a.summary || "").toLowerCase().includes(searchQ.toLowerCase()) && !(a.tags || []).some(t => t.toLowerCase().includes(searchQ.toLowerCase()))) return false;
    return true;
  });

  const selectedArticle = selected ? articles.find(a => a.id === selected) : null;

  const startNew = () => {
    const id = `kb-${String(kbNextId++).padStart(3, "0")}`;
    setEditing({ id, title: "", category: "general", author: "", status: "draft", summary: "", body: "", tags: [], related: [], version: 1 });
    setSelected(null);
  };
  const startEdit = (a) => setEditing({ ...a });
  const cancelEdit = () => setEditing(null);
  const saveEdit = () => {
    if (!editing || !editing.title.trim()) return;
    onSave({ ...editing, title: editing.title.trim(), updated: new Date().toISOString() });
    setSelected(editing.id);
    setEditing(null);
  };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      {/* Header */}
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>ナレッジ</h1>
          <span style={{ fontSize: 9, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.colBg, color: C.textVLight, letterSpacing: 0.3 }}>全プロジェクト共通</span>
          <span style={{ fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent }}>{articles.length} 記事</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ position: "relative" }}>
            <span style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: C.textVLight }}>{I.search}</span>
            <input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="記事を検索" style={{ padding: "6px 10px 6px 28px", borderRadius: 3, border: `2px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 12, outline: "none", width: 180 }} onFocus={e => e.target.style.borderColor = C.borderFocus} onBlur={e => e.target.style.borderColor = C.border} />
          </div>
          <button onClick={startNew} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 新規作成</button>
        </div>
      </header>

      {/* Filters */}
      <div style={{ padding: "8px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
        <span style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, marginRight: 4 }}>カテゴリ:</span>
        <button onClick={() => setFilterCat("all")} style={filterPill(filterCat === "all")}>すべて</button>
        {KB_CATEGORIES.map(c => <button key={c.id} onClick={() => setFilterCat(c.id)} style={{ ...filterPill(filterCat === c.id), borderLeft: `3px solid ${c.color}` }}>{c.label}</button>)}
        <span style={{ width: 1, height: 16, background: C.border, margin: "0 4px" }} />
        <span style={{ fontSize: 10, fontWeight: 600, color: C.textVLight, marginRight: 4 }}>ステータス:</span>
        <button onClick={() => setFilterStatus("all")} style={filterPill(filterStatus === "all")}>すべて</button>
        {KB_STATUSES.map(s => <button key={s.id} onClick={() => setFilterStatus(s.id)} style={filterPill(filterStatus === s.id)}><span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", background: s.color, marginRight: 3 }} />{s.label}</button>)}
      </div>

      {/* Content: list + detail/editor */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>
        {/* Article list */}
        <div style={{ width: 320, flexShrink: 0, borderRight: `1px solid ${C.border}`, overflowY: "auto", background: C.surface }}>
          {filtered.length === 0 && <div style={{ padding: 24, textAlign: "center", color: C.textVLight, fontSize: 12 }}>記事が見つかりません</div>}
          {filtered.map(a => <KBListItem key={a.id} article={a} isSelected={selected === a.id} onClick={() => { setSelected(a.id); setEditing(null); }} />)}
        </div>

        {/* Detail / Editor */}
        <div style={{ flex: 1, overflowY: "auto", background: C.bg }}>
          {editing ? (
            <KBEditor article={editing} onChange={setEditing} onSave={saveEdit} onCancel={cancelEdit} articles={articles} members={members} />
          ) : selectedArticle ? (
            <KBDetail article={selectedArticle} articles={articles} onEdit={() => startEdit(selectedArticle)} onDelete={() => { onDelete(selectedArticle.id); setSelected(null); }} onSelect={setSelected} />
          ) : (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: C.textVLight }}>
              <div style={{ textAlign: "center" }}>
                <div style={{ fontSize: 40, marginBottom: 8, opacity: 0.2 }}>📖</div>
                <div style={{ fontSize: 13 }}>記事を選択するか、新規作成してください</div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function KBListItem({ article, isSelected, onClick }) {
  const cat = KB_CATEGORIES.find(c => c.id === article.category);
  const st = KB_STATUSES.find(s => s.id === article.status);
  return (
    <div onClick={onClick} style={{
      padding: "12px 16px", cursor: "pointer", borderBottom: `1px solid ${C.colBg}`,
      background: isSelected ? C.accentLight : "transparent", borderLeft: isSelected ? `3px solid ${C.accent}` : "3px solid transparent",
      transition: "background .1s",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 4 }}>
        {cat && <span style={{ fontSize: 9, padding: "1px 6px", borderRadius: 2, background: `${cat.color}15`, color: cat.color, fontWeight: 700 }}>{cat.label}</span>}
        {st && <span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", background: st.color }} title={st.label} />}
        <span style={{ fontSize: 9, color: C.textVLight, marginLeft: "auto" }}>v{article.version}</span>
      </div>
      <div style={{ fontSize: 13, fontWeight: 600, color: C.text, lineHeight: 1.4, marginBottom: 4 }}>{article.title}</div>
      {article.summary && <div style={{ fontSize: 11, color: C.textLight, lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{article.summary}</div>}
      {article.tags?.length > 0 && <div style={{ display: "flex", gap: 3, marginTop: 6, flexWrap: "wrap" }}>{article.tags.slice(0, 4).map(t => <span key={t} style={{ fontSize: 9, padding: "1px 5px", borderRadius: 2, background: C.colBg, color: C.textLight }}>{t}</span>)}</div>}
    </div>
  );
}

function KBDetail({ article, articles, onEdit, onDelete, onSelect }) {
  const cat = KB_CATEGORIES.find(c => c.id === article.category);
  const st = KB_STATUSES.find(s => s.id === article.status);
  const relatedArticles = (article.related || []).map(id => articles.find(a => a.id === id)).filter(Boolean);

  return (
    <div style={{ padding: "24px 32px", maxWidth: 800 }}>
      {/* Meta bar */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
          {cat && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 3, background: `${cat.color}15`, color: cat.color, fontWeight: 700 }}>{cat.label}</span>}
          {st && <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 3, background: st.id === "approved" ? C.successBg : st.id === "reviewed" ? C.warningBg : C.colBg, color: st.color, fontWeight: 600 }}>{st.label}</span>}
          <span style={{ fontSize: 10, color: C.textVLight }}>v{article.version} · {article.author || "Unknown"} · {(article.updated || article.created || "").slice(0, 10)}</span>
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={onEdit} style={{ padding: "5px 12px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.text, cursor: "pointer", fontSize: 11, fontWeight: 600 }}>✏️ 編集</button>
          <button onClick={onDelete} style={{ padding: "5px 12px", borderRadius: 3, border: "none", background: C.dangerBg, color: C.danger, cursor: "pointer", fontSize: 11, fontWeight: 600 }}>🗑 削除</button>
        </div>
      </div>
      {/* Title */}
      <h1 style={{ margin: "0 0 8px", fontSize: 22, fontWeight: 700, color: C.text, lineHeight: 1.3 }}>{article.title}</h1>
      {article.summary && <div style={{ fontSize: 13, color: C.textLight, lineHeight: 1.5, marginBottom: 16, padding: "10px 14px", background: C.colBg, borderRadius: 4, borderLeft: `3px solid ${C.accent}` }}>{article.summary}</div>}
      {/* Tags */}
      {article.tags?.length > 0 && <div style={{ display: "flex", gap: 4, marginBottom: 16, flexWrap: "wrap" }}>{article.tags.map(t => <span key={t} style={{ fontSize: 10, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600 }}>{t}</span>)}</div>}
      {/* Body */}
      <div style={{ fontSize: 13, color: C.text, lineHeight: 1.7 }} dangerouslySetInnerHTML={{ __html: renderMd(article.body) }} />
      {/* Related */}
      {relatedArticles.length > 0 && (
        <div style={{ marginTop: 24, borderTop: `1px solid ${C.border}`, paddingTop: 16 }}>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.textVLight, marginBottom: 8, letterSpacing: 0.5 }}>関連記事</div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {relatedArticles.map(r => <button key={r.id} onClick={() => onSelect(r.id)} style={{ padding: "6px 12px", borderRadius: 4, border: `1px solid ${C.border}`, background: C.surface, cursor: "pointer", fontSize: 12, fontWeight: 500, color: C.accent }}>{r.title}</button>)}
          </div>
        </div>
      )}
    </div>
  );
}

function KBEditor({ article, onChange, onSave, onCancel, articles, members }) {
  const [tagIn, setTagIn] = useState("");
  const addTag = () => { const t = tagIn.trim(); if (t && !(article.tags || []).includes(t)) { onChange({ ...article, tags: [...(article.tags || []), t] }); setTagIn(""); } };
  const removeTag = (t) => onChange({ ...article, tags: (article.tags || []).filter(x => x !== t) });
  const toggleRelated = (id) => {
    const r = article.related || [];
    onChange({ ...article, related: r.includes(id) ? r.filter(x => x !== id) : [...r, id] });
  };
  const otherArticles = articles.filter(a => a.id !== article.id);

  return (
    <div style={{ padding: "24px 32px", maxWidth: 800 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <h2 style={{ margin: 0, fontSize: 16, fontWeight: 600, color: C.text }}>{article.version > 1 ? "記事を編集" : "新規記事"}</h2>
        <div style={{ display: "flex", gap: 6 }}>
          <button onClick={onCancel} style={{ padding: "6px 16px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12, fontWeight: 500 }}>キャンセル</button>
          <button onClick={onSave} style={{ padding: "6px 20px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>保存</button>
        </div>
      </div>

      <Lbl>タイトル *</Lbl>
      <input value={article.title} onChange={e => onChange({ ...article, title: e.target.value })} placeholder="記事タイトル" style={{ ...inpStyle, marginBottom: 12, fontSize: 15, fontWeight: 600 }} onFocus={onFocus} onBlur={onBlur} />

      <div style={{ display: "flex", gap: 12, marginBottom: 12 }}>
        <div style={{ flex: 1 }}>
          <Lbl>カテゴリ</Lbl>
          <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
            {KB_CATEGORIES.map(c => <button key={c.id} onClick={() => onChange({ ...article, category: c.id })} style={{ padding: "3px 8px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: article.category === c.id ? `${c.color}18` : C.colBg, color: article.category === c.id ? c.color : C.textLight }}>{c.label}</button>)}
          </div>
        </div>
        <div>
          <Lbl>ステータス</Lbl>
          <div style={{ display: "flex", gap: 4 }}>
            {KB_STATUSES.map(s => <button key={s.id} onClick={() => onChange({ ...article, status: s.id })} style={{ padding: "3px 8px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: "none", background: article.status === s.id ? (s.id === "approved" ? C.successBg : s.id === "reviewed" ? C.warningBg : C.colBg) : C.colBg, color: article.status === s.id ? s.color : C.textLight }}>{s.label}</button>)}
          </div>
        </div>
      </div>

      <Lbl>著者</Lbl>
      <input value={article.author || ""} onChange={e => onChange({ ...article, author: e.target.value })} placeholder="著者名" style={{ ...inpStyle, marginBottom: 12 }} onFocus={onFocus} onBlur={onBlur} />

      <Lbl>サマリー（AI用ダイジェスト）</Lbl>
      <textarea value={article.summary || ""} onChange={e => onChange({ ...article, summary: e.target.value })} placeholder="この記事の要約を1-2文で" rows={2} style={{ ...inpStyle, marginBottom: 12, resize: "vertical" }} onFocus={onFocus} onBlur={onBlur} />

      <Lbl>本文（Markdown）</Lbl>
      <textarea value={article.body || ""} onChange={e => onChange({ ...article, body: e.target.value })} placeholder="# 見出し\n\n本文をMarkdownで記述..." rows={14} style={{ ...inpStyle, marginBottom: 12, resize: "vertical", fontFamily: "'SF Mono', Monaco, 'Cascadia Code', monospace", fontSize: 12, lineHeight: 1.6 }} onFocus={onFocus} onBlur={onBlur} />

      <Lbl>タグ</Lbl>
      <div style={{ display: "flex", gap: 4, marginBottom: 12, flexWrap: "wrap", alignItems: "center" }}>
        {(article.tags || []).map(t => <span key={t} style={{ fontSize: 10, padding: "2px 8px", borderRadius: 3, background: C.accentLight, color: C.accent, fontWeight: 600, display: "inline-flex", alignItems: "center", gap: 4 }}>{t}<span onClick={() => removeTag(t)} style={{ cursor: "pointer", fontSize: 13 }}>×</span></span>)}
        <input value={tagIn} onChange={e => setTagIn(e.target.value)} onKeyDown={e => e.key === "Enter" && (e.preventDefault(), addTag())} placeholder="タグ追加 (Enter)" style={{ ...inpStyle, width: 130, padding: "4px 8px", fontSize: 11 }} onFocus={onFocus} onBlur={onBlur} />
      </div>

      {otherArticles.length > 0 && (<>
        <Lbl>関連記事</Lbl>
        <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12 }}>
          {otherArticles.map(a => <button key={a.id} onClick={() => toggleRelated(a.id)} style={{ padding: "3px 10px", borderRadius: 3, fontSize: 10, fontWeight: 600, cursor: "pointer", border: (article.related || []).includes(a.id) ? `1px solid ${C.accent}` : `1px solid ${C.border}`, background: (article.related || []).includes(a.id) ? C.accentLight : C.surface, color: (article.related || []).includes(a.id) ? C.accent : C.textLight }}>{a.title}</button>)}
        </div>
      </>)}
    </div>
  );
}

/* ── Project Manager ── */
function ProjectManager({ projects, onSave, onDelete }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", color: PROJECT_COLORS[0], description: "" });

  const startEdit = (p) => { setEditing(p); setForm({ name: p.name, color: p.color, description: p.description || "" }); setShowForm(true); };
  const handleSave = () => {
    if (!form.name.trim()) return;
    const id = editing ? editing.id : `proj-${projectNextId++}`;
    onSave({ id, name: form.name.trim(), color: form.color, description: form.description.trim() });
    setForm({ name: "", color: PROJECT_COLORS[Math.floor(Math.random() * PROJECT_COLORS.length)], description: "" });
    setShowForm(false); setEditing(null);
  };

  return (
    <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
      <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>プロジェクト管理</div>
          <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>{projects.length}件のプロジェクト</div>
        </div>
        <button onClick={() => { setEditing(null); setForm({ name: "", color: PROJECT_COLORS[Math.floor(Math.random() * PROJECT_COLORS.length)], description: "" }); setShowForm(true); }} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 追加</button>
      </div>
      {showForm && (
        <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, background: C.colBg }}>
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", flexWrap: "wrap" }}>
            <div style={{ flex: 1, minWidth: 150 }}><Lbl>プロジェクト名 *</Lbl><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} onKeyDown={e => e.key === "Enter" && handleSave()} placeholder="例: モバイルアプリ" style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>
            <div><Lbl>色</Lbl><div style={{ display: "flex", gap: 3 }}>{PROJECT_COLORS.map(c => <button key={c} onClick={() => setForm({ ...form, color: c })} style={{ width: 20, height: 20, borderRadius: "50%", background: c, border: form.color === c ? "2px solid #172b4d" : "2px solid transparent", cursor: "pointer", padding: 0 }} />)}</div></div>
            <button onClick={handleSave} style={{ padding: "8px 16px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>{editing ? "更新" : "作成"}</button>
            <button onClick={() => { setShowForm(false); setEditing(null); }} style={{ padding: "8px 12px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12 }}>取消</button>
          </div>
          {form.name && <div style={{ marginTop: 8 }}><Lbl>説明</Lbl><input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} placeholder="プロジェクトの説明（任意）" style={inpStyle} onFocus={onFocus} onBlur={onBlur} /></div>}
        </div>
      )}
      {projects.map(p => <ProjectRow key={p.id} project={p} onEdit={() => startEdit(p)} onDelete={() => onDelete(p.id)} canDelete={projects.length > 1} />)}
    </div>
  );
}

function ProjectRow({ project, onEdit, onDelete, canDelete }) {
  const [hov, setHov] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 18px", borderBottom: `1px solid ${C.colBg}`, background: hov ? C.cardHover : "transparent", transition: "background .1s" }}>
      <div style={{ width: 28, height: 28, borderRadius: 6, background: `linear-gradient(135deg,${project.color},${project.color}aa)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{project.name[0]}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{project.name}</div>
        {project.description && <div style={{ fontSize: 10, color: C.textVLight }}>{project.description}</div>}
      </div>
      {hov && (
        <div style={{ display: "flex", gap: 4 }}>
          <button onClick={onEdit} style={{ ...aBtn, fontSize: 13 }}>✏️</button>
          {canDelete && <button onClick={onDelete} style={{ ...aBtn, color: C.danger, fontSize: 13 }}>🗑</button>}
        </div>
      )}
    </div>
  );
}

/* ── Settings Page ── */
function SettingsPage({ members, onAddMember, onDeleteMember, apiAvailable, onDataReloaded, featureFlags, onFeatureChange, projects, onSaveProject, onDeleteProject, tokenBudget, onTokenBudgetChange }) {
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState("");
  const [color, setColor] = useState(MEMBER_COLORS[0]);
  const [backups, setBackups] = useState([]);
  const [backupMsg, setBackupMsg] = useState(null);
  const [loadingBackups, setLoadingBackups] = useState(false);

  const handleAdd = () => {
    if (!name.trim()) return;
    const parts = name.trim().split(/\s+/);
    const initials = parts.length >= 2
      ? (parts[0][0] + parts[1][0]).toUpperCase()
      : name.trim().slice(0, 2).toUpperCase();
    const id = `m${memberNextId++}`;
    onAddMember({ id, name: name.trim(), initials, color });
    setName("");
    setColor(MEMBER_COLORS[Math.floor(Math.random() * MEMBER_COLORS.length)]);
    setShowAdd(false);
  };

  // Load server-side backup list
  const loadBackups = useCallback(async () => {
    if (!apiAvailable) return;
    setLoadingBackups(true);
    const list = await api.listBackups();
    if (list) setBackups(list);
    setLoadingBackups(false);
  }, [apiAvailable]);

  useEffect(() => { loadBackups(); }, [loadBackups]);

  const showMsg = (text, isErr) => { setBackupMsg({ text, isErr }); setTimeout(() => setBackupMsg(null), 4000); };

  // Export backup as JSON file download
  const handleExport = async () => {
    const data = await api.exportBackup();
    if (!data) return showMsg("エクスポートに失敗しました", true);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url;
    a.download = `dashboard-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click(); URL.revokeObjectURL(url);
    showMsg("バックアップをダウンロードしました", false);
  };

  // Import backup from JSON file
  const handleImport = () => {
    const input = document.createElement("input"); input.type = "file"; input.accept = ".json";
    input.onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      try {
        const text = await file.text();
        const data = JSON.parse(text);
        if (!data.data) return showMsg("無効なバックアップファイルです", true);
        const result = await api.restoreBackup(data);
        if (result) { showMsg("リストア完了 — データを再読み込みします", false); setTimeout(() => onDataReloaded(), 500); }
        else showMsg("リストアに失敗しました", true);
      } catch { showMsg("ファイルの読み込みに失敗しました", true); }
    };
    input.click();
  };

  // Save backup to server
  const handleServerSave = async () => {
    const result = await api.saveBackup();
    if (result) { showMsg(`サーバーに保存: ${result.filename}`, false); loadBackups(); }
    else showMsg("保存に失敗しました", true);
  };

  // Restore from server backup
  const handleServerRestore = async (filename) => {
    if (!confirm(`"${filename}" からリストアしますか？現在のデータは上書きされます。`)) return;
    const result = await api.restoreFromFile(filename);
    if (result) { showMsg("リストア完了", false); setTimeout(() => onDataReloaded(), 500); }
    else showMsg("リストアに失敗しました", true);
  };

  // Delete server backup
  const handleDeleteBackup = async (filename) => {
    await api.deleteBackupFile(filename);
    loadBackups();
  };

  const formatSize = (bytes) => bytes < 1024 ? `${bytes}B` : bytes < 1048576 ? `${(bytes / 1024).toFixed(1)}KB` : `${(bytes / 1048576).toFixed(1)}MB`;

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
      <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>設定</h1>
        {backupMsg && <div style={{ fontSize: 12, fontWeight: 600, padding: "4px 12px", borderRadius: 3, background: backupMsg.isErr ? C.dangerBg : C.successBg, color: backupMsg.isErr ? C.danger : C.success }}>{backupMsg.text}</div>}
      </header>
      <div style={{ flex: 1, overflow: "auto", padding: "20px 24px" }}>
        <div style={{ maxWidth: 600, display: "flex", flexDirection: "column", gap: 16 }}>

          {/* ── Project management ── */}
          <ProjectManager projects={projects} onSave={onSaveProject} onDelete={onDeleteProject} />

          {/* ── Member management ── */}
          <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>メンバー管理</div>
                <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>{members.length}名のメンバー</div>
              </div>
              <button onClick={() => setShowAdd(!showAdd)} style={{ display: "flex", alignItems: "center", gap: 4, padding: "6px 14px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>{I.plus} 追加</button>
            </div>
            {showAdd && (
              <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, background: C.colBg }}>
                <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
                  <div style={{ flex: 1 }}>
                    <Lbl>名前 *</Lbl>
                    <input value={name} onChange={e => setName(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && handleAdd()}
                      placeholder="例: Hanako Y." style={{ ...inpStyle }} onFocus={onFocus} onBlur={onBlur} />
                  </div>
                  <div>
                    <Lbl>カラー</Lbl>
                    <div style={{ display: "flex", gap: 4 }}>
                      {MEMBER_COLORS.map(c => (
                        <button key={c} onClick={() => setColor(c)} style={{ width: 24, height: 24, borderRadius: "50%", background: c, border: color === c ? "2px solid #172b4d" : "2px solid transparent", cursor: "pointer", padding: 0 }} />
                      ))}
                    </div>
                  </div>
                  <button onClick={handleAdd} style={{ padding: "8px 16px", borderRadius: 3, border: "none", background: C.accent, color: "#fff", cursor: "pointer", fontSize: 12, fontWeight: 600, whiteSpace: "nowrap" }}>追加</button>
                  <button onClick={() => setShowAdd(false)} style={{ padding: "8px 12px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 12 }}>取消</button>
                </div>
              </div>
            )}
            {members.map(m => <MemberRow key={m.id} member={m} onDelete={() => onDeleteMember(m.id)} />)}
          </div>

          {/* ── Backup & Restore ── */}
          <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>バックアップ & リストア</div>
              <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>サーバー自動バックアップ（6時間毎）+ 手動バックアップ</div>
            </div>

            {/* Action buttons */}
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}`, display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={handleExport} style={backupBtn}>
                <span style={{ fontSize: 14 }}>📥</span> JSONエクスポート
              </button>
              <button onClick={handleImport} style={backupBtn}>
                <span style={{ fontSize: 14 }}>📤</span> JSONインポート
              </button>
              {apiAvailable && (
                <button onClick={handleServerSave} style={{ ...backupBtn, background: C.accent, color: "#fff", border: "none" }}>
                  <span style={{ fontSize: 14 }}>💾</span> サーバーに保存
                </button>
              )}
            </div>

            {/* Server backup list */}
            {apiAvailable && (
              <div>
                <div style={{ padding: "10px 18px", background: C.colBg, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: C.textLight }}>サーバー上のバックアップ ({backups.length}件)</span>
                  <button onClick={loadBackups} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 11, color: C.accent, fontWeight: 600 }}>更新</button>
                </div>
                {loadingBackups && <div style={{ padding: "12px 18px", fontSize: 12, color: C.textVLight }}>読み込み中...</div>}
                {!loadingBackups && backups.length === 0 && <div style={{ padding: "12px 18px", fontSize: 12, color: C.textVLight }}>バックアップはありません</div>}
                {backups.map(b => (
                  <BackupRow key={b.filename} backup={b} onRestore={() => handleServerRestore(b.filename)} onDelete={() => handleDeleteBackup(b.filename)} />
                ))}
              </div>
            )}
          </div>

          {/* ── Token Budget Management ── */}
          <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>🎛️ AIトークン予算管理</div>
              <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>LLMスクラムチームのスプリントごとのトークン消費を管理</div>
            </div>
            <div style={{ padding: "14px 18px" }}>
              {/* Budget settings */}
              <div style={{ display: "flex", gap: 12, marginBottom: 16, flexWrap: "wrap" }}>
                <div style={{ flex: 1, minWidth: 140 }}>
                  <Lbl>最大トークン数（スプリント上限）</Lbl>
                  <input type="number" value={tokenBudget.maxTokens} onChange={e => onTokenBudgetChange({ ...tokenBudget, maxTokens: Math.max(100000, Number(e.target.value)) })} style={{ ...inpStyle, fontSize: 14, fontWeight: 600 }} onFocus={onFocus} onBlur={onBlur} step={100000} />
                </div>
                <div style={{ flex: 1, minWidth: 140 }}>
                  <Lbl>最大ツール呼び出し数</Lbl>
                  <input type="number" value={tokenBudget.maxToolCalls} onChange={e => onTokenBudgetChange({ ...tokenBudget, maxToolCalls: Math.max(10, Number(e.target.value)) })} style={{ ...inpStyle, fontSize: 14, fontWeight: 600 }} onFocus={onFocus} onBlur={onBlur} step={50} />
                </div>
                <div style={{ flex: 1, minWidth: 140 }}>
                  <Lbl>警告閾値（%）</Lbl>
                  <input type="number" value={tokenBudget.warningPct} onChange={e => onTokenBudgetChange({ ...tokenBudget, warningPct: Math.min(100, Math.max(50, Number(e.target.value))) })} style={{ ...inpStyle, fontSize: 14, fontWeight: 600 }} onFocus={onFocus} onBlur={onBlur} min={50} max={100} />
                </div>
              </div>

              {/* Presets */}
              <Lbl>プリセット</Lbl>
              <div style={{ display: "flex", gap: 6, marginBottom: 16, flexWrap: "wrap" }}>
                {[
                  { label: "軽量（テスト用）", tokens: 500000, tools: 100 },
                  { label: "標準", tokens: 2000000, tools: 500 },
                  { label: "大規模", tokens: 5000000, tools: 1000 },
                  { label: "無制限", tokens: 99999999, tools: 99999 },
                ].map(p => (
                  <button key={p.label} onClick={() => onTokenBudgetChange({ ...tokenBudget, maxTokens: p.tokens, maxToolCalls: p.tools })}
                    style={{ padding: "4px 12px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: `1px solid ${C.border}`, background: tokenBudget.maxTokens === p.tokens ? C.accentLight : C.surface, color: tokenBudget.maxTokens === p.tokens ? C.accent : C.textLight }}>{p.label}</button>
                ))}
              </div>

              {/* Cost estimation */}
              <div style={{ background: C.colBg, borderRadius: 4, padding: "10px 14px", marginBottom: 16 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: C.textMid, marginBottom: 6 }}>コスト概算（Claude Sonnet基準）</div>
                <div style={{ display: "flex", gap: 16, fontSize: 12 }}>
                  <span style={{ color: C.text }}>入力: <strong>${(tokenBudget.maxTokens * 0.5 * 3 / 1000000).toFixed(2)}</strong></span>
                  <span style={{ color: C.text }}>出力: <strong>${(tokenBudget.maxTokens * 0.5 * 15 / 1000000).toFixed(2)}</strong></span>
                  <span style={{ color: C.accent, fontWeight: 600 }}>合計: ~${((tokenBudget.maxTokens * 0.5 * 3 / 1000000) + (tokenBudget.maxTokens * 0.5 * 15 / 1000000)).toFixed(2)}/sprint</span>
                </div>
              </div>

              {/* Sprint usage history */}
              {tokenBudget.sprintUsage.length > 0 && (<>
                <Lbl>スプリント別トークン消費履歴</Lbl>
                <div style={{ maxHeight: 200, overflowY: "auto" }}>
                  {tokenBudget.sprintUsage.map((su, i) => {
                    const pct = (su.tokens / tokenBudget.maxTokens) * 100;
                    const overBudget = pct > 100;
                    const warning = pct > tokenBudget.warningPct;
                    return (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 0", borderBottom: `1px solid ${C.colBg}` }}>
                        <span style={{ fontSize: 11, fontWeight: 600, color: C.text, width: 80 }}>{su.name}</span>
                        <div style={{ flex: 1 }}><ProgressBar value={Math.min(pct, 100)} color={overBudget ? C.danger : warning ? C.warning : C.accent} height={5} /></div>
                        <span style={{ fontSize: 10, fontWeight: 600, color: overBudget ? C.danger : warning ? C.warning : C.textVLight, minWidth: 80, textAlign: "right" }}>{su.tokens.toLocaleString()} ({pct.toFixed(0)}%)</span>
                      </div>
                    );
                  })}
                </div>
              </>)}
              {tokenBudget.sprintUsage.length === 0 && (
                <div style={{ fontSize: 11, color: C.textVLight, textAlign: "center", padding: 12 }}>スプリント実行後にトークン消費履歴が表示されます</div>
              )}
            </div>
          </div>

          {/* ── Feature Toggles ── */}
          <div style={{ background: C.surface, borderRadius: 6, border: `1px solid ${C.border}`, overflow: "hidden" }}>
            <div style={{ padding: "14px 18px", borderBottom: `1px solid ${C.border}` }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: C.text }}>機能の有効化 / 無効化</div>
              <div style={{ fontSize: 11, color: C.textVLight, marginTop: 2 }}>サイドバーに表示する機能を選択できます</div>
            </div>
            {Object.entries(FEATURE_DESCRIPTIONS).map(([key, info]) => {
              const navItem = ALL_NAV.find(n => n.featureKey === key);
              const isAlwaysOn = navItem?.alwaysOn;
              const isOn = featureFlags[key];
              return (
                <div key={key} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 18px", borderBottom: `1px solid ${C.colBg}` }}>
                  <span style={{ fontSize: 18, width: 28, textAlign: "center" }}>{info.icon}</span>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{info.label}</div>
                    <div style={{ fontSize: 11, color: C.textVLight }}>{info.desc}</div>
                  </div>
                  <button onClick={() => { if (!isAlwaysOn) onFeatureChange(key, !isOn); }}
                    style={{
                      width: 44, height: 24, borderRadius: 12, border: "none", cursor: isAlwaysOn ? "not-allowed" : "pointer",
                      background: isOn ? C.accent : C.border, position: "relative", transition: "background .2s",
                      opacity: isAlwaysOn ? 0.5 : 1,
                    }}>
                    <div style={{
                      width: 18, height: 18, borderRadius: "50%", background: "#fff",
                      position: "absolute", top: 3, left: isOn ? 23 : 3,
                      transition: "left .2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                    }} />
                  </button>
                </div>
              );
            })}
          </div>

        </div>
      </div>
    </div>
  );
}

const backupBtn = {
  display: "flex", alignItems: "center", gap: 6, padding: "8px 14px", borderRadius: 3,
  border: `1px solid ${C.border}`, background: C.surface, color: C.text,
  cursor: "pointer", fontSize: 12, fontWeight: 600, transition: "background .1s",
};

function BackupRow({ backup, onRestore, onDelete }) {
  const [hov, setHov] = useState(false);
  const isAuto = backup.filename.startsWith("auto-");
  const date = new Date(backup.created);
  const dateStr = `${date.getFullYear()}/${String(date.getMonth() + 1).padStart(2, "0")}/${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
  const sizeStr = backup.size < 1024 ? `${backup.size}B` : `${(backup.size / 1024).toFixed(1)}KB`;
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 18px", borderTop: `1px solid ${C.colBg}`, background: hov ? C.cardHover : "transparent", transition: "background .1s" }}>
      <span style={{ fontSize: 14 }}>{isAuto ? "🔄" : "💾"}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{backup.filename}</div>
        <div style={{ fontSize: 10, color: C.textVLight }}>{dateStr} · {sizeStr}</div>
      </div>
      {hov && (
        <div style={{ display: "flex", gap: 4 }}>
          <button onClick={onRestore} style={{ padding: "3px 10px", borderRadius: 3, border: "none", background: C.accentLight, color: C.accent, cursor: "pointer", fontSize: 11, fontWeight: 600 }}>リストア</button>
          <button onClick={onDelete} style={{ padding: "3px 8px", borderRadius: 3, border: "none", background: C.dangerBg, color: C.danger, cursor: "pointer", fontSize: 11, fontWeight: 600 }}>削除</button>
        </div>
      )}
    </div>
  );
}

function MemberRow({ member, onDelete }) {
  const [hov, setHov] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  return (
    <div onMouseEnter={() => setHov(true)} onMouseLeave={() => { setHov(false); setConfirmDel(false); }}
      style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 18px", borderBottom: `1px solid ${C.colBg}`, background: hov ? C.cardHover : "transparent", transition: "background .1s" }}>
      <Avatar member={member} size={32} />
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text }}>{member.name}</div>
        <div style={{ fontSize: 11, color: C.textVLight }}>ID: {member.id}</div>
      </div>
      {hov && !confirmDel && (
        <button onClick={() => setConfirmDel(true)} style={{ ...aBtn, color: C.danger, fontSize: 13 }}>🗑</button>
      )}
      {confirmDel && (
        <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
          <span style={{ fontSize: 11, color: C.danger, fontWeight: 600 }}>削除？</span>
          <button onClick={onDelete} style={{ padding: "3px 10px", borderRadius: 3, border: "none", background: C.danger, color: "#fff", cursor: "pointer", fontSize: 11, fontWeight: 600 }}>はい</button>
          <button onClick={() => setConfirmDel(false)} style={{ padding: "3px 10px", borderRadius: 3, border: `1px solid ${C.border}`, background: C.surface, color: C.textMid, cursor: "pointer", fontSize: 11 }}>いいえ</button>
        </div>
      )}
    </div>
  );
}

/* ═══ §9 Main Dashboard Component ═══ */
export default function Dashboard() {
  const [members, setMembers] = useState(FALLBACK_MEMBERS);
  const [tasks, setTasks] = useState(FALLBACK_TASKS);
  const [orgGoals, setOrgGoals] = useState(FALLBACK_ORG_GOALS);
  const [personalGoals, setPersonalGoals] = useState(FALLBACK_PERSONAL_GOALS);
  const [knowledge, setKnowledge] = useState(FALLBACK_KB);
  const [sprints, setSprints] = useState(FALLBACK_SPRINTS);
  const [epics, setEpics] = useState(FALLBACK_EPICS);
  const [featureFlags, setFeatureFlags] = useState(DEFAULT_FEATURES);
  const [tokenBudget, setTokenBudget] = useState({ maxTokens: 2000000, maxToolCalls: 500, warningPct: 80, sprintUsage: [] });
  const [projects, setProjects] = useState(FALLBACK_PROJECTS);
  const [retros, setRetros] = useState(FALLBACK_RETROS);
  const [currentProjectId, setCurrentProjectId] = useState("proj-1");
  const [apiAvailable, setApiAvailable] = useState(false);
  const [activeNav, setActiveNav] = useState("home");
  const [viewMode, setViewMode] = useState("board");
  const [modal, setModal] = useState(null);
  const [dragOverCol, setDragOverCol] = useState(null);
  const [filterMember, setFilterMember] = useState(null);
  const [search, setSearch] = useState("");
  const [sideOpen, setSideOpen] = useState(true);
  const dragRef = useRef(null);

  // ── Load from API on mount ──
  useEffect(() => {
    (async () => {
      const [m, t, og, pg, kb, sp, ep, rt] = await Promise.all([api.getMembers(), api.getTasks(), api.getOrgGoals(), api.getPersonalGoals(), api.getKnowledge(), api.getSprints(), api.getEpics(), api.getRetros()]);
      if (m) setMembers(m);
      if (t) { setTasks(t); setApiAvailable(true); }
      if (og) setOrgGoals(og);
      if (pg) setPersonalGoals(pg);
      if (kb) setKnowledge(kb);
      if (sp) setSprints(sp);
      if (ep) setEpics(ep);
      if (rt) setRetros(rt);
    })();
  }, []);

  // ── Task CRUD with API ──
  const saveTask = useCallback(async (task) => {
    const taskWithProject = { ...task, projectId: task.projectId || currentProjectId };
    const isNew = !tasks.find(t => t.id === taskWithProject.id);
    setTasks(p => {
      const ex = p.find(t => t.id === taskWithProject.id);
      return ex ? p.map(t => t.id === taskWithProject.id ? taskWithProject : t) : [...p, taskWithProject];
    });
    setModal(null);
    if (apiAvailable) {
      if (isNew) await api.createTask(taskWithProject);
      else await api.updateTask(taskWithProject.id, taskWithProject);
    }
  }, [tasks, apiAvailable, currentProjectId]);

  const deleteTask = useCallback(async (id) => {
    setTasks(p => p.filter(t => t.id !== id));
    if (apiAvailable) await api.deleteTask(id);
  }, [apiAvailable]);

  const drag = {
    start: (e, id) => { dragRef.current = id; e.dataTransfer.effectAllowed = "move"; },
    end: () => { dragRef.current = null; setDragOverCol(null); },
    over: (col) => setDragOverCol(col),
    leave: () => setDragOverCol(null),
    drop: async (e, col) => {
      e.preventDefault();
      const taskId = dragRef.current;
      if (taskId) {
        setTasks(p => p.map(t => t.id === taskId ? { ...t, column: col } : t));
        if (apiAvailable) await api.moveTask(taskId, col);
      }
      dragRef.current = null;
      setDragOverCol(null);
    },
  };

  // ── Org Goal CRUD with API ──
  const saveOrgGoal = useCallback(async (goal) => {
    const isNew = !orgGoals.find(g => g.id === goal.id);
    setOrgGoals(p => {
      const ex = p.find(g => g.id === goal.id);
      return ex ? p.map(g => g.id === goal.id ? goal : g) : [...p, goal];
    });
    if (apiAvailable) {
      if (isNew) await api.createOrgGoal(goal);
      else await api.updateOrgGoal(goal.id, goal);
    }
  }, [orgGoals, apiAvailable]);

  const deleteOrgGoal = useCallback(async (id) => {
    setOrgGoals(p => p.filter(g => g.id !== id));
    if (apiAvailable) await api.deleteOrgGoal(id);
  }, [apiAvailable]);

  // ── Personal Goal CRUD with API ──
  const savePersonalGoal = useCallback(async (goal) => {
    const isNew = !personalGoals.find(g => g.id === goal.id);
    setPersonalGoals(p => {
      const ex = p.find(g => g.id === goal.id);
      return ex ? p.map(g => g.id === goal.id ? goal : g) : [...p, goal];
    });
    if (apiAvailable) {
      if (isNew) await api.createPersonalGoal(goal);
      else await api.updatePersonalGoal(goal.id, goal);
    }
  }, [personalGoals, apiAvailable]);

  const deletePersonalGoal = useCallback(async (id) => {
    setPersonalGoals(p => p.filter(g => g.id !== id));
    if (apiAvailable) await api.deletePersonalGoal(id);
  }, [apiAvailable]);

  // ── Member CRUD with API ──
  const addMember = useCallback(async (member) => {
    setMembers(p => [...p, member]);
    if (apiAvailable) await api.createMember(member);
  }, [apiAvailable]);

  const deleteMember = useCallback(async (id) => {
    setMembers(p => p.filter(m => m.id !== id));
    // Remove from task assignees
    setTasks(p => p.map(t => ({ ...t, assignees: t.assignees.filter(a => a !== id) })));
    if (apiAvailable) await api.deleteMember(id);
  }, [apiAvailable]);

  // ── Knowledge CRUD with API ──
  const saveArticle = useCallback(async (article) => {
    const isNew = !knowledge.find(a => a.id === article.id);
    setKnowledge(p => {
      const ex = p.find(a => a.id === article.id);
      return ex ? p.map(a => a.id === article.id ? article : a) : [...p, article];
    });
    if (apiAvailable) {
      if (isNew) await api.createArticle(article);
      else await api.updateArticle(article.id, article);
    }
  }, [knowledge, apiAvailable]);

  const deleteArticle = useCallback(async (id) => {
    setKnowledge(p => p.filter(a => a.id !== id));
    if (apiAvailable) await api.deleteArticle(id);
  }, [apiAvailable]);

  // ── Sprint CRUD with API ──
  const saveSprint = useCallback(async (sprint) => {
    const s = { ...sprint, projectId: sprint.projectId || currentProjectId };
    const isNew = !sprints.find(x => x.id === s.id);
    setSprints(p => {
      const ex = p.find(x => x.id === s.id);
      return ex ? p.map(x => x.id === s.id ? { ...ex, ...s } : x) : [...p, s];
    });
    if (apiAvailable) {
      if (isNew) await api.createSprint(s);
      else await api.updateSprint(s.id, s);
    }
  }, [sprints, apiAvailable, currentProjectId]);

  const deleteSprint = useCallback(async (id) => {
    setSprints(p => p.filter(s => s.id !== id));
    if (apiAvailable) await api.deleteSprint(id);
  }, [apiAvailable]);

  const addTaskToSprint = useCallback(async (sprintId, taskId, points = 0) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    setSprints(p => p.map(s => {
      if (s.id !== sprintId) return s;
      const newTask = { id: taskId, title: task.title, column: task.column, priority: task.priority, points };
      const newTasks = [...s.tasks, newTask];
      return { ...s, tasks: newTasks, totalPoints: newTasks.reduce((sum, t) => sum + t.points, 0), completedPoints: newTasks.filter(t => t.column === "done").reduce((sum, t) => sum + t.points, 0) };
    }));
    if (apiAvailable) await api.addTaskToSprint(sprintId, taskId, points);
  }, [tasks, apiAvailable]);

  const removeTaskFromSprint = useCallback(async (sprintId, taskId) => {
    setSprints(p => p.map(s => {
      if (s.id !== sprintId) return s;
      const newTasks = s.tasks.filter(t => t.id !== taskId);
      return { ...s, tasks: newTasks, totalPoints: newTasks.reduce((sum, t) => sum + t.points, 0), completedPoints: newTasks.filter(t => t.column === "done").reduce((sum, t) => sum + t.points, 0) };
    }));
    if (apiAvailable) await api.removeTaskFromSprint(sprintId, taskId);
  }, [apiAvailable]);

  const updateTaskPoints = useCallback(async (sprintId, taskId, points) => {
    setSprints(p => p.map(s => {
      if (s.id !== sprintId) return s;
      const newTasks = s.tasks.map(t => t.id === taskId ? { ...t, points } : t);
      return { ...s, tasks: newTasks, totalPoints: newTasks.reduce((sum, t) => sum + t.points, 0), completedPoints: newTasks.filter(t => t.column === "done").reduce((sum, t) => sum + t.points, 0) };
    }));
    if (apiAvailable) await api.updateTaskPoints(sprintId, taskId, points);
  }, [apiAvailable]);

  // ── Epic CRUD with API ──
  const saveEpic = useCallback(async (epic) => {
    const e = { ...epic, projectId: epic.projectId || currentProjectId };
    const isNew = !epics.find(x => x.id === e.id);
    setEpics(p => {
      const ex = p.find(x => x.id === e.id);
      return ex ? p.map(x => x.id === e.id ? e : x) : [...p, e];
    });
    if (apiAvailable) {
      if (isNew) await api.createEpic(e);
      else await api.updateEpic(e.id, e);
    }
  }, [epics, apiAvailable, currentProjectId]);

  const deleteEpic = useCallback(async (id) => {
    setEpics(p => p.filter(e => e.id !== id));
    setTasks(p => p.map(t => t.epicId === id ? { ...t, epicId: "" } : t));
    if (apiAvailable) await api.deleteEpic(id);
  }, [apiAvailable]);

  // ── Backlog reorder ──
  const reorderTasks = useCallback(async (orders) => {
    setTasks(p => {
      const orderMap = {};
      for (const o of orders) orderMap[o.id] = o.priorityOrder;
      return p.map(t => orderMap[t.id] !== undefined ? { ...t, priorityOrder: orderMap[t.id] } : t);
    });
    if (apiAvailable) await api.reorderTasks(orders);
  }, [apiAvailable]);

  const setTaskEpic = useCallback(async (taskId, epicId) => {
    setTasks(p => p.map(t => t.id === taskId ? { ...t, epicId } : t));
    if (apiAvailable) await api.setTaskEpic(taskId, epicId);
  }, [apiAvailable]);

  const quickAssignTask = useCallback(async (taskId, assignees) => {
    setTasks(p => p.map(t => t.id === taskId ? { ...t, assignees } : t));
    if (apiAvailable) await api.quickAssign(taskId, assignees);
  }, [apiAvailable]);

  const addTaskComment = useCallback(async (taskId, author, content) => {
    // Optimistic: add to local state
    const c = { id: Date.now(), author, content, createdAt: new Date().toISOString() };
    setTasks(p => p.map(t => t.id === taskId ? { ...t, comments: [...(t.comments || []), c] } : t));
    if (apiAvailable) await api.addComment(taskId, author, content);
  }, [apiAvailable]);

  // ── Project CRUD ──
  const saveProject = useCallback((proj) => {
    setProjects(p => {
      const ex = p.find(x => x.id === proj.id);
      return ex ? p.map(x => x.id === proj.id ? proj : x) : [...p, proj];
    });
  }, []);
  const deleteProject = useCallback((id) => {
    setProjects(p => p.filter(x => x.id !== id));
    if (currentProjectId === id) {
      const remaining = projects.filter(x => x.id !== id);
      setCurrentProjectId(remaining[0]?.id || "");
    }
  }, [currentProjectId, projects]);

  // ── Retro CRUD ──
  const saveRetro = useCallback(async (retro) => {
    const r = { ...retro, projectId: retro.projectId || currentProjectId };
    const isNew = !retros.find(x => x.id === r.id);
    setRetros(p => {
      const ex = p.find(x => x.id === r.id);
      return ex ? p.map(x => x.id === r.id ? r : x) : [...p, r];
    });
    if (apiAvailable) {
      if (isNew) await api.createRetro(r);
      else await api.updateRetro(r.id, r);
    }
  }, [retros, apiAvailable, currentProjectId]);

  const deleteRetro = useCallback(async (id) => {
    setRetros(p => p.filter(x => x.id !== id));
    if (apiAvailable) await api.deleteRetro(id);
  }, [apiAvailable]);

  // ── Export retro to knowledge ──
  const exportRetroToKnowledge = useCallback((retro) => {
    const keeps = retro.items.filter(i => i.type === "keep");
    const problems = retro.items.filter(i => i.type === "problem");
    const tries = retro.items.filter(i => i.type === "try");
    const actions = retro.items.filter(i => i.action);

    const body = [
      `# ${retro.title}`,
      "", `## 概要`, `${retro.date} に実施したスプリントふりかえりの記録。`,
      "", `## Keep（続けたいこと）`,
      ...keeps.map(i => `- ${i.content}${i.votes ? ` (👍${i.votes})` : ""}`),
      "", `## Problem（問題・課題）`,
      ...problems.map(i => `- ${i.content}${i.votes ? ` (👍${i.votes})` : ""}${i.action ? `\n  - 📌 アクション: ${i.action}` : ""}`),
      "", `## Try（試したいこと）`,
      ...tries.map(i => `- ${i.content}${i.votes ? ` (👍${i.votes})` : ""}${i.action ? `\n  - 📌 アクション: ${i.action}` : ""}`),
    ];
    if (actions.length > 0) {
      body.push("", "## アクションアイテム");
      actions.forEach(i => body.push(`- [ ] ${i.action}（元: ${i.content}）`));
    }

    const article = {
      id: `kb-retro-${Date.now()}`,
      title: `[ふりかえり] ${retro.title}`,
      category: "pm",
      author: "チーム",
      status: "reviewed",
      summary: `${retro.title}のKPTまとめ。Keep ${keeps.length}件・Problem ${problems.length}件・Try ${tries.length}件。`,
      body: body.join("\n"),
      tags: ["ふりかえり", "KPT", retro.sprintId ? sprints.find(s => s.id === retro.sprintId)?.name || "" : ""].filter(Boolean),
      related: [],
    };
    saveArticle(article);
    setActiveNav("knowledge");
  }, [sprints, saveArticle, setActiveNav]);

  // ── Reload all data ── from API (after restore) ──
  const reloadAllData = useCallback(async () => {
    const [m, t, og, pg, kb, sp, ep, rt] = await Promise.all([api.getMembers(), api.getTasks(), api.getOrgGoals(), api.getPersonalGoals(), api.getKnowledge(), api.getSprints(), api.getEpics(), api.getRetros()]);
    if (m) setMembers(m);
    if (t) setTasks(t);
    if (og) setOrgGoals(og);
    if (pg) setPersonalGoals(pg);
    if (kb) setKnowledge(kb);
    if (sp) setSprints(sp);
    if (ep) setEpics(ep);
    if (rt) setRetros(rt);
  }, []);

  // ── Project-scoped data ──
  const pTasks = useMemo(() => tasks.filter(t => t.projectId === currentProjectId), [tasks, currentProjectId]);
  const pEpics = useMemo(() => epics.filter(e => e.projectId === currentProjectId), [epics, currentProjectId]);
  const pSprints = useMemo(() => sprints.filter(s => s.projectId === currentProjectId), [sprints, currentProjectId]);
  const pRetros = useMemo(() => retros.filter(r => r.projectId === currentProjectId), [retros, currentProjectId]);
  const currentProject = projects.find(p => p.id === currentProjectId);

  // ── Filters ──
  const filtered = pTasks.filter(t => {
    if (filterMember && !t.assignees.includes(filterMember)) return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) && !(t.desc || "").toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });
  const total = pTasks.length, done = pTasks.filter(t => t.column === "done").length;

  const Placeholder = ({ title, icon, desc }) => (
    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", background: C.bg }}>
      <div style={{ textAlign: "center", color: C.textLight }}>
        <div style={{ fontSize: 48, marginBottom: 16, opacity: 0.25 }}>{icon}</div>
        <h2 style={{ margin: "0 0 8px", fontSize: 20, fontWeight: 600, color: C.text }}>{title}</h2>
        <p style={{ margin: 0, fontSize: 13, color: C.textVLight }}>{desc}</p>
        <span style={{ display: "inline-block", marginTop: 16, fontSize: 11, fontWeight: 600, padding: "4px 14px", borderRadius: 3, background: C.accentLight, color: C.accent }}>Coming Soon</span>
      </div>
    </div>
  );

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Noto Sans JP',sans-serif", color: C.text, overflow: "hidden", fontSize: 14 }}>
      <style>{`*::-webkit-scrollbar{width:6px;height:6px}*::-webkit-scrollbar-track{background:transparent}*::-webkit-scrollbar-thumb{background:#c1c7d0;border-radius:3px}*::-webkit-scrollbar-thumb:hover{background:#a5adba}*{box-sizing:border-box}`}</style>

      {/* Sidebar */}
      <aside style={{ width: sideOpen ? 240 : 56, background: C.sidebarBg, display: "flex", flexDirection: "column", transition: "width .2s ease", flexShrink: 0, overflow: "hidden" }}>
        <div style={{ padding: sideOpen ? "16px 16px 12px" : "16px 10px 12px", display: "flex", alignItems: "center", gap: 10, minHeight: 56 }}>
          <div style={{ width: 32, height: 32, borderRadius: 6, background: currentProject ? `linear-gradient(135deg,${currentProject.color},${currentProject.color}aa)` : "linear-gradient(135deg,#0065ff,#4c9aff)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 800, color: "#fff", flexShrink: 0 }}>{currentProject ? currentProject.name[0] : "D"}</div>
          {sideOpen && <div style={{ overflow: "hidden", flex: 1 }}><div style={{ fontSize: 14, fontWeight: 700, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{currentProject?.name || "Dashboard"}</div><div style={{ fontSize: 10, color: C.sidebarText, fontWeight: 500 }}>プロジェクト管理{apiAvailable ? "" : " (オフライン)"}</div></div>}
        </div>
        {/* Project selector */}
        {sideOpen && (
          <div style={{ padding: "0 8px 4px" }}>
            <select value={currentProjectId} onChange={e => setCurrentProjectId(e.target.value)}
              style={{ width: "100%", padding: "6px 8px", borderRadius: 4, border: "none", background: C.sidebarHover, color: C.sidebarTextActive, fontSize: 11, fontWeight: 600, cursor: "pointer", outline: "none", appearance: "auto" }}>
              {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
        )}
        <div style={{ height: 1, background: "rgba(255,255,255,0.08)", margin: "0 12px" }} />
        <nav style={{ padding: "8px 8px 0", flex: 1 }}>{ALL_NAV.filter(n => featureFlags[n.featureKey]).map(item => <SidebarItem key={item.id} item={item} active={activeNav === item.id} expanded={sideOpen} onClick={() => !item.disabled && setActiveNav(item.id)} />)}</nav>
        <div style={{ height: 1, background: "rgba(255,255,255,0.08)", margin: "0 12px" }} />
        <nav style={{ padding: "8px 8px 4px" }}>{NAV_BOTTOM.map(item => <SidebarItem key={item.id} item={item} active={activeNav === item.id} expanded={sideOpen} onClick={() => !item.disabled && setActiveNav(item.id)} />)}</nav>
        <button onClick={() => setSideOpen(!sideOpen)} style={{ margin: "4px 8px 12px", padding: "6px", borderRadius: 4, border: "none", background: "rgba(255,255,255,0.06)", color: C.sidebarText, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>{sideOpen ? I.chevL : I.chevR}</button>
      </aside>

      {/* Main */}
      {activeNav === "home" ? (
        <HomePage tasks={pTasks} sprints={pSprints} orgGoals={orgGoals} personalGoals={personalGoals} knowledge={knowledge} members={members} onNavigate={setActiveNav} featureFlags={featureFlags} />
      ) : activeNav === "tasks" ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: C.bg }}>
          <header style={{ padding: "12px 24px", background: C.surface, borderBottom: `1px solid ${C.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}><h1 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: C.text }}>タスク管理</h1><span style={{ fontSize: 10, fontWeight: 600, padding: "2px 8px", borderRadius: 3, background: C.successBg, color: C.success }}>{done}/{total} 完了</span></div>
                <div style={{ marginTop: 4, height: 3, width: 140, background: C.border, borderRadius: 2, overflow: "hidden" }}><div style={{ height: "100%", width: total > 0 ? `${(done / total) * 100}%` : "0%", background: C.accent, borderRadius: 2, transition: "width .3s" }} /></div>
              </div>
              <ViewToggle view={viewMode} onChange={setViewMode} />
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div style={{ position: "relative" }}><span style={{ position: "absolute", left: 8, top: "50%", transform: "translateY(-50%)", color: C.textVLight }}>{I.search}</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="課題を検索" style={{ padding: "6px 10px 6px 28px", borderRadius: 3, border: `2px solid ${C.border}`, background: C.bg, color: C.text, fontSize: 12, outline: "none", width: 180 }} onFocus={e => e.target.style.borderColor = C.borderFocus} onBlur={e => e.target.style.borderColor = C.border} /></div>
              <div style={{ display: "flex", gap: 2, alignItems: "center" }}>
                <button onClick={() => setFilterMember(null)} style={{ padding: "3px 8px", borderRadius: 3, fontSize: 11, fontWeight: 600, cursor: "pointer", border: "none", background: !filterMember ? C.accentLight : "transparent", color: !filterMember ? C.accent : C.textLight }}>全員</button>
                {members.map(m => <button key={m.id} onClick={() => setFilterMember(m.id === filterMember ? null : m.id)} style={{ padding: 2, borderRadius: "50%", border: filterMember === m.id ? `2px solid ${m.color}` : "2px solid transparent", background: "transparent", cursor: "pointer", lineHeight: 0 }}><Avatar member={m} size={24} /></button>)}
              </div>
            </div>
          </header>
          {viewMode === "board" ? (
            <div style={{ flex: 1, overflowX: "auto", overflowY: "auto", padding: "16px 20px", display: "flex", gap: 10 }}>
              {COLUMNS.map(c => <BoardCol key={c.id} col={c} tasks={filtered.filter(t => t.column === c.id)} onAdd={cid => setModal({ columnId: cid })} onEdit={t => setModal({ task: t })} onDelete={deleteTask} drag={drag} isOver={dragOverCol === c.id} members={members} epics={pEpics} onQuickAssign={quickAssignTask} />)}
            </div>
          ) : (
            <CalendarView tasks={filtered} onEdit={t => setModal({ task: t })} onDelete={deleteTask} onAddOnDate={date => setModal({ defaultDate: date })} />
          )}
        </div>
      ) : activeNav === "backlog" ? (
        <BacklogPage tasks={pTasks} epics={pEpics} onReorder={reorderTasks} onSetEpic={setTaskEpic}
          onSaveEpic={saveEpic} onDeleteEpic={deleteEpic} apiAvailable={apiAvailable} />
      ) : activeNav === "sprints" ? (
        <SprintPage sprints={pSprints} tasks={pTasks} onSaveSprint={saveSprint} onDeleteSprint={deleteSprint}
          onAddTask={addTaskToSprint} onRemoveTask={removeTaskFromSprint} onUpdatePoints={updateTaskPoints} apiAvailable={apiAvailable} tokenBudget={tokenBudget} />
      ) : activeNav === "retro" ? (
        <RetroPage retros={pRetros} sprints={pSprints} onSave={saveRetro} onDelete={deleteRetro} onExportToKnowledge={exportRetroToKnowledge} />
      ) : activeNav === "goals" ? (
        <GoalsPage orgGoals={orgGoals} personalGoals={personalGoals}
          onSaveOrgGoal={saveOrgGoal} onDeleteOrgGoal={deleteOrgGoal}
          onSavePersonalGoal={savePersonalGoal} onDeletePersonalGoal={deletePersonalGoal} members={members} />
      ) : activeNav === "knowledge" ? (
        <KnowledgePage articles={knowledge} onSave={saveArticle} onDelete={deleteArticle} apiAvailable={apiAvailable} members={members} />
      ) : activeNav === "ai" ? (
        <AIPage apiAvailable={apiAvailable} currentProjectId={currentProjectId} />
      ) : activeNav === "settings" ? (
        <SettingsPage members={members} onAddMember={addMember} onDeleteMember={deleteMember} apiAvailable={apiAvailable} onDataReloaded={reloadAllData}
          featureFlags={featureFlags} onFeatureChange={(key, val) => { setFeatureFlags(p => ({ ...p, [key]: val })); if (!val && activeNav === key) setActiveNav("home"); }}
          projects={projects} onSaveProject={saveProject} onDeleteProject={deleteProject}
          tokenBudget={tokenBudget} onTokenBudgetChange={setTokenBudget} />
      ) : null}

      {modal && <TaskModal task={modal.task} columnId={modal.columnId} defaultDate={modal.defaultDate} onSave={saveTask} onClose={() => setModal(null)} members={members} epics={pEpics} onAddComment={addTaskComment} />}
    </div>
  );
}
