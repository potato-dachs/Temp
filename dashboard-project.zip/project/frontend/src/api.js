const BASE = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

export const api = {
  // Members
  getMembers: () => request("/members"),

  // Tasks
  getTasks: () => request("/tasks"),
  createTask: (task) => request("/tasks", { method: "POST", body: JSON.stringify(task) }),
  updateTask: (id, task) => request(`/tasks/${id}`, { method: "PUT", body: JSON.stringify(task) }),
  moveTask: (id, column) => request(`/tasks/${id}/column`, { method: "PATCH", body: JSON.stringify({ column }) }),
  deleteTask: (id) => request(`/tasks/${id}`, { method: "DELETE" }),

  // Org Goals
  getOrgGoals: () => request("/goals/org"),
  createOrgGoal: (goal) => request("/goals/org", { method: "POST", body: JSON.stringify(goal) }),
  updateOrgGoal: (id, goal) => request(`/goals/org/${id}`, { method: "PUT", body: JSON.stringify(goal) }),
  deleteOrgGoal: (id) => request(`/goals/org/${id}`, { method: "DELETE" }),

  // Personal Goals
  getPersonalGoals: () => request("/goals/personal"),
  createPersonalGoal: (goal) => request("/goals/personal", { method: "POST", body: JSON.stringify(goal) }),
  updatePersonalGoal: (id, goal) => request(`/goals/personal/${id}`, { method: "PUT", body: JSON.stringify(goal) }),
  deletePersonalGoal: (id) => request(`/goals/personal/${id}`, { method: "DELETE" }),
};
