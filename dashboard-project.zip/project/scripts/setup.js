#!/usr/bin/env node

/**
 * One-command setup: install dependencies + build frontend
 */

const { execSync } = require("child_process");
const path = require("path");

const ROOT = path.join(__dirname, "..");

function run(label, cmd, cwd) {
  console.log(`\n📦 ${label}...`);
  try {
    execSync(cmd, { cwd: path.join(ROOT, cwd), stdio: "inherit" });
    console.log(`✅ ${label} done`);
  } catch (e) {
    console.error(`❌ ${label} failed`);
    process.exit(1);
  }
}

console.log(`
┌─────────────────────────────────────────────┐
│  🔧 AI Dashboard — Setup                    │
└─────────────────────────────────────────────┘
`);

run("Installing backend dependencies", "npm install", "backend");
run("Installing frontend dependencies", "npm install", "frontend");
run("Building frontend for production", "npx vite build", "frontend");

console.log(`
┌─────────────────────────────────────────────┐
│  ✅ Setup complete!                          │
│                                             │
│  Start with:                                │
│    npm start          (production)           │
│    npm run dev        (development)          │
│                                             │
│  Then open: http://localhost:3001            │
└─────────────────────────────────────────────┘
`);
