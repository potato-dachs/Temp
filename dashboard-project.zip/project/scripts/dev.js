#!/usr/bin/env node

/**
 * Development mode launcher
 * Runs backend (port 3001) + frontend dev server (port 3000) concurrently
 * With colorized, prefixed output
 */

const { spawn } = require("child_process");
const path = require("path");

const ROOT = path.join(__dirname, "..");

function run(name, cmd, args, cwd, color) {
  const p = spawn(cmd, args, {
    cwd: path.join(ROOT, cwd),
    stdio: ["inherit", "pipe", "pipe"],
    shell: true,
    env: { ...process.env, FORCE_COLOR: "1" },
  });

  const prefix = `\x1b[${color}m[${name}]\x1b[0m`;

  p.stdout.on("data", (data) => {
    data.toString().split("\n").filter(l => l.trim()).forEach(line => {
      console.log(`${prefix} ${line}`);
    });
  });

  p.stderr.on("data", (data) => {
    data.toString().split("\n").filter(l => l.trim()).forEach(line => {
      console.error(`${prefix} ${line}`);
    });
  });

  p.on("close", (code) => {
    console.log(`${prefix} exited with code ${code}`);
  });

  return p;
}

console.log(`
┌─────────────────────────────────────────────┐
│  🚀 AI Dashboard — Development Mode         │
│                                             │
│  Backend:  http://localhost:3001 (API)       │
│  Frontend: http://localhost:3000 (Vite HMR)  │
│                                             │
│  Press Ctrl+C to stop                       │
└─────────────────────────────────────────────┘
`);

const backend = run("BE", "node", ["server.js"], "backend", "36");   // cyan
const frontend = run("FE", "npx", ["vite"], "frontend", "35");       // magenta

process.on("SIGINT", () => {
  console.log("\n🛑 Shutting down...");
  backend.kill();
  frontend.kill();
  process.exit(0);
});
