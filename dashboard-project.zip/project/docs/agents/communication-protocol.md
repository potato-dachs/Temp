# エージェント間通信プロトコル仕様

## 1. メッセージ形式

全エージェント間のやり取りは以下のJSON形式で行う。

```json
{
  "messageId": "msg-{timestamp}-{random}",
  "from": "orchestrator | po-agent | sm-agent | dev-frontend | dev-backend | dev-infra | dev-qa",
  "to": "agent-id | broadcast | human",
  "type": "request | response | notification | escalation",
  "action": "アクション名",
  "context": {
    "sprintId": "現在のスプリントID",
    "projectId": "現在のプロジェクトID",
    "timestamp": "ISO 8601"
  },
  "payload": {},
  "replyTo": "返信先のmessageId（responseの場合）",
  "priority": "normal | urgent",
  "ttl": 300
}
```

### フィールド定義

| フィールド | 必須 | 説明 |
|-----------|------|------|
| messageId | ✅ | ユニークなメッセージID |
| from | ✅ | 送信元エージェントID |
| to | ✅ | 送信先（broadcast = 全員） |
| type | ✅ | メッセージ種別 |
| action | ✅ | 要求するアクション名 |
| context | ✅ | 共通コンテキスト |
| payload | ✅ | アクション固有のデータ |
| replyTo | - | 返信時のみ |
| priority | - | デフォルト: normal |
| ttl | - | タイムアウト秒数（デフォルト: 300） |

---

## 2. アクション一覧

### Orchestrator → PO Agent

| action | 説明 | payload |
|--------|------|---------|
| `request_backlog` | 優先バックログの提示を要求 | `{ maxItems: number }` |
| `request_acceptance` | タスクの受入判定を要求 | `{ taskId: string }` |
| `feedback_from_human` | 人間からのフィードバックを転送 | `{ feedback: string, taskIds: string[] }` |

### Orchestrator → SM Agent

| action | 説明 | payload |
|--------|------|---------|
| `request_capacity` | キャパシティ算出を要求 | `{}` |
| `trigger_daily` | デイリースクラムの実行を指示 | `{}` |
| `trigger_retro` | ふりかえりの実施を指示 | `{ sprintId: string }` |
| `create_sprint` | スプリント作成を指示 | `{ tasks: array, capacity: number }` |

### Orchestrator → Dev Agents

| action | 説明 | payload |
|--------|------|---------|
| `request_estimate` | 見積もりを要求 | `{ taskId: string, title: string, desc: string }` |
| `assign_task` | タスクをアサイン | `{ taskId: string }` |
| `request_review` | レビューを依頼 | `{ taskId: string, author: string }` |

### SM Agent → Dev Agents

| action | 説明 | payload |
|--------|------|---------|
| `request_status` | デイリーの状態報告を要求 | `{}` |
| `blocker_advice` | ブロッカー解消のアドバイス | `{ taskId: string, suggestion: string }` |

### Dev Agent → SM Agent

| action | 説明 | payload |
|--------|------|---------|
| `status_report` | 状態報告 | `{ yesterday, today, blockers, taskId }` |
| `report_blocker` | ブロッカー報告 | `{ taskId, description, severity }` |

### PO Agent → Orchestrator

| action | 説明 | payload |
|--------|------|---------|
| `backlog_ready` | バックログ提示完了 | `{ taskIds: string[], totalPoints: number }` |
| `acceptance_result` | 受入判定結果 | `{ taskId, result: "accepted"|"rejected", feedback }` |

### Dev Agent → Dev Agent

| action | 説明 | payload |
|--------|------|---------|
| `review_result` | レビュー結果 | `{ taskId, result: "approved"|"changes_requested", comments }` |

### Any → Orchestrator

| action | 説明 | payload |
|--------|------|---------|
| `escalation` | 問題のエスカレーション | `{ issue, severity, suggestion }` |

---

## 3. 通信パターン

### 3.1 Request-Response（同期的）

```
Orchestrator                 PO Agent
    │                            │
    │── request_backlog ────────>│
    │                            │ (APIを叩いてバックログ整理)
    │<── backlog_ready ─────────│
    │                            │
```

ルール:
- request には ttl を設定（デフォルト 300秒）
- ttl 内に response がなければタイムアウト
- タイムアウト時は Orchestrator が介入

### 3.2 Broadcast（一斉通知）

```
Orchestrator
    │
    │── sprint_started ──> PO Agent
    │── sprint_started ──> SM Agent
    │── sprint_started ──> Dev-Frontend
    │── sprint_started ──> Dev-Backend
    │── sprint_started ──> Dev-QA
```

ルール:
- to: "broadcast" で全エージェントに送信
- response は不要（notification type）

### 3.3 Escalation（段階的上位報告）

```
Dev Agent ──report_blocker──> SM Agent
                                │
                          (解決を試みる)
                                │
                          解決できない場合
                                │
SM Agent ──escalation──> Orchestrator
                                │
                          (判断・介入)
                                │
                          人間に報告が必要な場合
                                │
Orchestrator ──report_to_human──> Human
```

### 3.4 Consensus（合意形成）

```
PO Agent                     Dev Agents
    │                            │
    │── request_estimate ──────>│ (各Dev)
    │                            │
    │<── estimate_response ─────│ Dev-FE: 5pt
    │<── estimate_response ─────│ Dev-BE: 8pt
    │<── estimate_response ─────│ Dev-QA: 3pt
    │                            │
    │ (見積もりが大きく乖離している場合)
    │── discussion_needed ─────>│
    │                            │
    │ (議論後、合意値を決定)
    │── estimate_finalized ────>│ 最終値: 5pt
```

---

## 4. 状態共有ルール

### 4.1 Single Source of Truth

```
✅ 正しい方法:
   Agent → API (書き込み) → API (読み取り) → Agent

❌ 間違い:
   Agent A → (直接メモリ共有) → Agent B
```

全エージェントはダッシュボードAPIのみを通じて状態を共有する。
メッセージは「アクション要求」と「結果通知」のみ。
データの実体はAPIに問い合わせる。

### 4.2 楽観的ロック

複数エージェントが同じリソースを同時に更新する場合:
- APIは最後の書き込みが勝つ（Last Write Wins）
- 競合が問題になる場合はOrchestratorがシリアライズ

### 4.3 コンテキスト最小化

各メッセージには必要最小限の情報のみ含める。
詳細データはメッセージに含めず、IDを渡してAPI経由で取得させる。

```
✅ { taskId: "DASH-10" }  → 受け取り側が GET /api/tasks で取得
❌ { task: { id: "DASH-10", title: "...", desc: "...", ... } }
```

---

## 5. エラーハンドリング

### 5.1 タイムアウト

| シナリオ | ttl | 対処 |
|---------|-----|------|
| 見積もり要求 | 120秒 | デフォルト値（中央値）を採用 |
| デイリー報告 | 60秒 | 「報告なし」として記録 |
| レビュー | 300秒 | Orchestrator が別のレビュアーを指名 |
| 受入判定 | 180秒 | Orchestrator がエスカレーション |

### 5.2 リトライ

- 最大3回まで自動リトライ
- リトライ間隔: 10秒、30秒、60秒（指数バックオフ）
- 3回失敗 → Orchestrator にエスカレーション

### 5.3 デッドレター

処理できなかったメッセージはデッドレターキューに格納。
Orchestrator が定期的に確認し、対処を判断。

---

## 6. 監査ログ

全メッセージは以下の形式でログに記録:

```json
{
  "timestamp": "ISO 8601",
  "messageId": "msg-...",
  "from": "agent-id",
  "to": "agent-id",
  "type": "request",
  "action": "action_name",
  "status": "sent | delivered | processed | timeout | error",
  "durationMs": 1234
}
```

ログの用途:
- パフォーマンス分析（どのエージェントが遅いか）
- ボトルネック検出（どの通信パスが詰まっているか）
- ふりかえりの材料（プロセスのどこに問題があるか）
