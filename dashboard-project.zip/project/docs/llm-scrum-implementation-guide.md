# LLM スクラムチーム 実装ガイド v2

> 参考実装: [AIエージェントだけでスクラムを回してみた](https://qiita.com/shyamagu/items/0ff827a1c2deef68ba9a) by @shyamagu
> GitHub Copilot CLI + カスタムエージェント方式で5体AIスクラムを実現した事例を参考に、
> 当プロジェクトのダッシュボードAPI + Claude API構成に適応。

---

## 1. 先行事例からの学びと設計反映

| 学び | 当設計への反映 |
|------|-------------|
| 顧客エージェントが人間の曖昧な指示を要件化 | **Customer Agent** を追加（人間の「部下」として代理行動） |
| 成果物はCSV/mdのファイルベースが効く | ダッシュボードAPI + **scrum/ ディレクトリの構造化ファイル**の併用 |
| スキル定義で各イベントの手順を明確化 | 各イベントを **実行スキル（手順書）** として定義 |
| エージェントに性格をつけると良い結果 | System Promptに**パーソナリティ・行動特性**を追加 |
| AIに「時間」は不適合 | キャパシティを**トークン消費量ベース**で再定義 |
| DoDの日次チェックが品質に直結 | デイリースクラムに**DoDチェック**を組み込み |
| 1スプリント約2時間で完了 | スプリント長を**実時間2-3時間**に設定 |

---

## 2. チーム構成（6体）

```
┌─────────────────────────────────────┐
│       人間（ステークホルダー）         │
│  「お洒落にしてね」レベルの指示でOK    │
└──────────────┬──────────────────────┘
               ▼
┌──────────────────────────────────────┐
│        佐藤（Customer Agent）         │
│  人間の部下。要件の詳細化・受入テスト   │
│  人間の曖昧な指示を構造化要件書に展開   │
└──────────────┬──────────────────────┘
               ▼
┌──────────────────────────────────────┐
│        鈴木（PO Agent）               │
│  バックログ管理・優先度・受入判定       │
└──────┬───────────────────────────────┘
       │
┌──────┴──────────────────────────────┐
│        高橋（SM Agent）              │
│  プロセス管理・デイリー・ふりかえり     │
│  「DoDは交渉材料ではない」が信条       │
└──────┬──────────────────────────────┘
       │
┌──────┴──────────────────────────────┐
│        Dev Agents                    │
│  伊藤（Frontend） - 一次情報重視型     │
│  田中（Backend）  - 慎重派・設計重視   │
└─────────────────────────────────────┘
```

### 各エージェントのパーソナリティ

| 名前 | 役割 | 性格・特徴 |
|------|------|-----------|
| 佐藤 | 顧客代表 | 質問魔。曖昧な指示を詳細要件に展開するのが得意。人間に報告・相談しつつ自律行動 |
| 鈴木 | PO | 表と構造が好き。受入条件を厳密に定義。優先度判断が速い |
| 高橋 | SM | 冷静な分析家。データで語る。DoDの遵守に妥協しない |
| 伊藤 | Dev-FE | 一次情報にあたることを重視。ドキュメント・Web検索を駆使して設計・実装 |
| 田中 | Dev-BE | 慎重派。「本当にそれ要る？」と確認する。設計の整合性を重視 |

---

## 3. プロジェクト構成（ファイルベース成果物）

```
scrum/                              # スクラム成果物
├── order/
│   └── orderXXX.md                 # 顧客依頼書（人間→佐藤が詳細化）
├── product_goal.md                 # プロダクトゴール
├── product_backlog.csv             # PBI一覧（CSV: ID,Title,Description,SP,Priority,Status...）
├── definition_of_done.md           # 完成の定義（DoD）
├── impediment_log.csv              # 障害物ログ
├── velocity.csv                    # ベロシティ記録
└── sprintXXX/                      # スプリント別
    ├── sprint_backlog.md           # スプリントバックログ
    ├── sprint_planning.md          # プランニング記録
    ├── sprint_review.md            # レビュー記録
    ├── sprint_retrospective.md     # レトロ記録
    └── daily_scrum.md              # デイリースクラム記録（日次追記）

project/                            # 実装成果物
├── frontend/                       # フロントエンド
├── backend/                        # バックエンド
├── docs/                           # ドキュメント
└── test/                           # テスト
```

**重要**: ダッシュボードAPIとファイルベース成果物の**二重管理**を行う。

- **ダッシュボードAPI** → リアルタイムのタスク状態管理（カンバン、バーンダウン）
- **ファイルベース** → スクラムプロセスの記録（プランニング議事録、レビュー記録、レトロ記録）

エージェントはAPIでタスクを操作しつつ、プロセスの記録はmdファイルに残す。

---

## 4. スクラムイベント実行スキル

### 4.1 order-create（依頼の明確化）

```
実行者: 佐藤（Customer Agent）
トリガー: 人間からの自然言語指示

手順:
1. 人間の指示を受け取る
2. 不明点があれば質問（最大3往復）
3. 要件を構造化してorder/orderXXX.mdに記録
4. 人間に確認（承認/修正）
5. 承認されたら鈴木（PO）に引き渡し
```

### 4.2 backlog-refinement（バックログリファインメント）

```
参加者: 全員
主催: 鈴木（PO）

手順:
1. 全員起動
2. [事前確認] product_backlog.csv, product_goal.md, definition_of_done.md を読む
3. [ゴール確認] 鈴木がプロダクトゴールを確認/更新、佐藤が顧客視点で妥当性確認
4. [PBI詳細化] 鈴木→佐藤に説明、フィードバック反映
5. [DoD更新] 鈴木が定義、伊藤・田中が技術観点で追加、高橋が確認
6. [PBI分割] 伊藤が主導、田中と合意、鈴木がレビュー
7. [見積もり] 伊藤・田中のみ（SP相対見積もり、velocity.csv参照）
8. [優先度] 鈴木主導、佐藤と協力（Critical > High > Medium > Low）
9. [Ready判定] 鈴木が判定（説明明確、AC定義済、見積もり完了、依存解決）
10. [記録] product_backlog.csv更新、order反映
```

### 4.3 sprint-planning（スプリントプランニング）

```
参加者: 全員
主催: 高橋（SM）

手順:
1. 全員起動
2. [キャパシティ算出]
   - velocity.csvから直近3スプリント平均
   - キャパシティ = ベロシティ × 0.8
   - ※初回は暫定値を設定
3. [PBI選定] 鈴木がReady PBIから優先度順に選定
4. [タスク分解] 伊藤・田中がPBIをタスクに分解
5. [スプリントゴール] 鈴木が設定
6. [API操作]
   - POST /api/sprints — スプリント作成
   - POST /api/sprints/:id/tasks — タスク割当
   - PUT /api/sprints/:id { status: "active" }
7. [記録] sprintXXX/sprint_planning.md, sprint_backlog.md作成
```

### 4.4 one-day-in-scrum（1日の開発）

```
手順:

[デイリースクラム] (高橋が主催、全員参加)
1. 各Dev: 昨日やったこと、今日やること、ブロッカー報告
2. 高橋: ブロッカー解消支援、バーンダウン確認
3. 高橋: DoDチェック（日次で実施！最終日にまとめてではダメ）
4. daily_scrum.mdに追記

[開発作業] (伊藤・田中が並行実行)
1. タスク着手: PATCH /api/tasks/:id/column → "inprogress"
2. ナレッジ検索: GET /api/knowledge/search/query
3. 実装 + テスト作成
4. レビュー依頼: PATCH /api/tasks/:id/column → "review"
5. 相互レビュー（伊藤↔田中）
6. レビューOK → 鈴木に受入依頼
7. 受入OK → PATCH column → "done"
8. 知見をナレッジに記録: POST /api/knowledge
```

### 4.5 sprint-review（スプリントレビュー）

```
参加者: 全員 + 人間
主催: 鈴木（PO）

手順:
1. [完了PBI一覧] GET /api/sprints/:id でタスク状態確認
2. [デモ] 伊藤・田中が成果物を説明
3. [佐藤の評価] 顧客視点でフィードバック
4. [鈴木の受入判定] 受入条件チェックリスト照合（全件pass or 条件付き受入）
5. [人間への報告] 佐藤が簡潔にサマリーを報告、承認を要求
6. [フィードバック反映] 次スプリントのPBIに追加
7. [記録] sprint_review.md作成
```

### 4.6 sprint-retrospective（ふりかえり）

```
参加者: スクラムチーム（佐藤除く）
主催: 高橋（SM）

手順:
1. [データ収集] バーンダウン、ベロシティ、完了率を分析
2. [KPT収集]
   - POST /api/retros — ふりかえり作成
   - 各エージェントがKeep/Problem/Tryを投稿
3. [投票] 重要度の合意
4. [アクション決定] Tryから1-2個に絞る（全部やらない）
5. [DoD更新] 必要に応じてdefinition_of_done.md更新
6. [ナレッジ変換] KPT→ナレッジ自動変換
7. [ベロシティ記録] velocity.csvに追記
8. [記録] sprint_retrospective.md作成
```

### 4.7 execute-sprint（スプリント一括実行）

```
実行者: Orchestrator

手順:
1. sprint-planning を実行
2. one-day-in-scrum を N回繰り返し（N = スプリント日数、通常3-5）
3. sprint-review を実行
4. sprint-retrospective を実行
5. 人間に完了報告
```

---

## 5. AIキャパシティモデル（時間ではなくトークン/コスト）

先行事例で指摘された「AIに時間の概念は不適合」問題への対応。

### 5.1 キャパシティ単位

```
従来（人間）: 1SP ≈ 1人日
AI版:        1SP ≈ 想定トークン消費量 or ツール呼び出し回数
```

### 5.2 スプリント予算

```json
{
  "sprintBudget": {
    "maxTokens": 2000000,
    "maxToolCalls": 500,
    "maxApiCalls": 200,
    "maxDurationMinutes": 180,
    "warningThreshold": 0.8
  }
}
```

### 5.3 ベロシティの再定義

```
AI版ベロシティ = 完了SP / 消費トークン数（効率指標）
```

スプリントごとに「同じトークン量でどれだけSPを消化できたか」を追跡。
効率が上がっている = ナレッジ活用が効いている証拠。

---

## 6. 品質ゲート（DoD日次運用）

先行事例で「最終日にDoD確認では遅い」と判明。日次で運用する。

### デイリーDoDチェックリスト

高橋（SM）がデイリースクラムで毎日確認:

```markdown
## 本日のDoDチェック
- [ ] 新規コードにテストが書かれているか
- [ ] ビルドが通るか
- [ ] Lint/Formatエラーがないか
- [ ] コードレビューが完了しているか（review→doneの間）
- [ ] ナレッジに記録すべき知見がないか
```

違反がある場合、**その日のうちに対処**。翌日に持ち越さない。

---

## 7. 実行方法

### 方式A: Claude API + Orchestratorスクリプト（推奨）

```
orchestrator.js
├── Claude API呼び出しでエージェントを起動
├── 各エージェントのSystem Promptを設定
├── ツール定義（Dashboard API）を提供
├── メッセージを仲介
└── スプリントサイクルをcronで駆動
```

メリット: ダッシュボードAPIと直接連携、カスタマイズ自由
デメリット: 自前実装が必要

### 方式B: GitHub Copilot CLI + カスタムエージェント

```
.github/agents/
├── customer.sato.agent.md
├── product-owner.suzuki.agent.md
├── developer.ito.agent.md
├── developer.tanaka.agent.md
└── scrum-master.takahashi.agent.md

.github/skills/
├── order-create/SKILL.md
├── backlog-refinement/SKILL.md
├── sprint-planning/SKILL.md
├── one-day-in-scrum/SKILL.md
├── sprint-review/SKILL.md
├── sprint-retrospective/SKILL.md
└── execute-sprint/SKILL.md
```

メリット: 先行事例で実証済み、Git連携が自然
デメリット: ダッシュボードAPIとの統合にMCPが必要

### 方式C: ハイブリッド

GitHub Copilot CLIでコード生成・Git操作を行い、
ダッシュボードAPIでタスク管理・ナレッジ管理を行う。
MCP経由でダッシュボードAPIをCopilot CLIから呼び出す。

---

## 8. 次のアクション

### Phase 2a: 実行基盤の選択と構築
- [ ] 方式A/B/Cのいずれかを選択
- [ ] Orchestratorの最小実装
- [ ] エージェント1体（SM）でデイリースクラムを試行

### Phase 2b: 最小スプリントの試行
- [ ] 人間が簡単な要求を投げる
- [ ] 佐藤が要件化 → 鈴木がPBI化 → 伊藤が実装 → 高橋がレビュー
- [ ] 1サイクル完了まで通す

### Phase 3: 本格運用
- [ ] 複数スプリントの連続実行
- [ ] ベロシティの安定化
- [ ] ナレッジの自己成長確認
