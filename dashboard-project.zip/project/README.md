# Dashboard — AI駆動プロジェクト管理プラットフォーム

JIRA風のプロジェクト管理ダッシュボード + LLMスクラムチーム自律運用基盤。
人間がステークホルダーとして方針を出すだけで、AIエージェントがスクラム開発を回す。

## 概要

```
人間「こういうの作って」
  ↓
AIスクラムチーム（5体のエージェント）
  佐藤(顧客代表) → 鈴木(PO) → 高橋(SM) → 伊藤(FE) + 田中(BE)
  ↓
ダッシュボード（タスク・スプリント・ナレッジ・ふりかえり）
  +
Gitea（ブランチ → コード生成 → PR → レビュー → マージ）
```

## 機能一覧

### ダッシュボードUI（React）
| 機能 | 説明 |
|------|------|
| 🏠 ホーム | KPIカード、スプリント進捗、タスク分布、メンバー稼働、ナレッジ最新 |
| 📋 タスク管理 | カンバンボード（D&D） + カレンダービュー切替 |
| 📝 バックログ | 優先度ドラッグ並替、エピック管理、フラット/エピック別/優先度別ビュー |
| 🏃 スプリント | スプリント作成・タスク割当・ストーリーポイント・バーンダウンチャート(SVG) |
| 🔄 ふりかえり | KPTボード（Keep/Problem/Try）、投票、アクション、ナレッジ自動変換 |
| 🎯 目標管理 | 組織方針（会社→本部→部→室→グループ）+ 個人目標（通年/Q1-Q4）+ KR |
| 📖 ナレッジ | Markdown記事、カテゴリ/ステータス/タグ管理、RAG対応構造、関連記事リンク |
| ⚙️ 設定 | プロジェクト管理、メンバー管理、バックアップ&リストア、トークン予算、機能トグル |

### タスク品質機能
- **期限日（dueDate）** — 超過は赤、2日以内は黄で警告表示
- **クイックアサイン** — カンバンカードからワンクリックで担当者変更
- **コメント** — タスクごとのディスカッション
- **履歴** — ステータス変更・担当者変更・コメントの自動記録

### プロジェクト管理
- マルチプロジェクト対応（サイドバー上部で切替）
- プロジェクト固有: タスク、バックログ、スプリント、ふりかえり
- プロジェクト共通: 目標管理、ナレッジ（「共通」バッジ表示）

### AI基盤
| コンポーネント | 説明 |
|-------------|------|
| Orchestrator | スプリントサイクル自動駆動（計画→開発→レビュー→ふりかえり） |
| エージェント5体 | 佐藤(顧客), 鈴木(PO), 高橋(SM), 伊藤(FE), 田中(BE) |
| MCPサーバー | 39ツールをMCPプロトコルで公開（Claude Code / Copilot CLI対応） |
| Gitea連携 | ブランチ作成→コード生成→PR作成→レビュー→マージの全自動化 |
| agent.md | ナレッジ生成エージェントプロンプト |

## プロジェクト構成

```
project/
├── package.json               # ルート — ワンコマンド起動
├── scripts/
│   ├── setup.js               # npm run setup（依存関係 + ビルド）
│   └── dev.js                 # npm run dev（BE + FE同時起動）
│
├── frontend/                  # React + Vite ダッシュボードUI
│   └── src/
│       └── Dashboard.jsx      # メインUI（単体動作可、約2970行）
│
├── backend/                   # Express + SQLite REST API
│   ├── server.js              # APIサーバー（自動バックアップ6時間毎）
│   ├── db.js                  # SQLiteスキーマ + シードデータ
│   ├── mcp-server.js          # MCPサーバー（42ツール、stdio + SSE）
│   └── routes/
│       ├── tasks.js           # タスクCRUD + コメント + 履歴 + クイックアサイン
│       ├── sprints.js         # スプリント + バーンダウン + スナップショット
│       ├── epics.js           # エピック管理
│       ├── goals.js           # 目標管理（組織 + 個人 + KR）
│       ├── knowledge.js       # ナレッジ + 検索 + RAGエクスポート
│       ├── retros.js          # ふりかえりKPT
│       ├── members.js         # メンバー管理
│       ├── projects.js        # プロジェクト管理
│       ├── backup.js          # バックアップ&リストア
│       ├── tokens.js          # トークン使用量追跡
│       ├── ai.js              # AI会話管理
│       └── ai-agent.js        # Claude APIプロキシ（Function Calling）
│
├── orchestrator/              # LLMスクラムチーム駆動エンジン
│   ├── orchestrator.js        # スプリントサイクル制御（CLI）
│   ├── agent-runtime.js       # エージェント実行基盤（15ツール定義）
│   ├── gitea.js               # Gitea API連携（ブランチ/コミット/PR/レビュー/マージ）
│   ├── scrum-files.js         # スクラム成果物ファイルユーティリティ
│   └── QUICKSTART.md
│
├── docs/                      # 設計ドキュメント
│   ├── llm-scrum-architecture.md      # アーキテクチャ設計書v2
│   ├── llm-scrum-implementation-guide.md  # 実装ガイド
│   ├── usecases.md            # ユースケース集（7シナリオ）
│   └── agents/                # エージェント定義
│       ├── customer-agent.md  # 佐藤（顧客代表）
│       ├── po-agent.md        # 鈴木（PO）
│       ├── sm-agent.md        # 高橋（SM）
│       ├── dev-agent.md       # 伊藤/田中（開発者テンプレート）
│       ├── orchestrator.md    # Orchestrator定義
│       └── communication-protocol.md  # 通信プロトコル仕様
│
├── agent.md                   # ナレッジ生成エージェントプロンプト
└── scrum/                     # スプリント成果物（自動生成）
```

## クイックスタート

```bash
npm run setup     # 初回のみ: 依存関係インストール + フロントエンドビルド
npm start         # → http://localhost:3001 で全機能起動
```

## コマンド一覧

| コマンド | 用途 |
|---------|------|
| `npm run setup` | 初回セットアップ（install + build） |
| `npm start` | 本番起動（API + UI、1プロセス） |
| `npm run dev` | 開発モード（BE + FE同時起動、HMR） |
| `npm run mcp` | MCPサーバー（stdio / Claude Code用） |
| `npm run mcp:sse` | MCPサーバー（SSE / Web用、port 3002） |
| `npm run sprint` | LLMスクラムチーム実行 |

### 環境変数

| 変数 | 用途 | 必須 |
|------|------|------|
| `ANTHROPIC_API_KEY` | AIチャット + スプリント自動実行 | AI機能利用時 |
| `GITEA_URL` | GiteaサーバーURL | Git連携時 |
| `GITEA_TOKEN` | Gitea APIトークン | Git連携時 |
| `GITEA_OWNER` | リポジトリオーナー | Git連携時 |
| `GITEA_REPO` | リポジトリ名 | Git連携時 |

### MCP接続設定（Claude Code）

```json
{
  "mcpServers": {
    "dashboard": {
      "command": "node",
      "args": ["/path/to/backend/mcp-server.js"]
    }
  }
}
```

## API エンドポイント一覧

### タスク管理
| Method | Path | 説明 |
|--------|------|------|
| GET | /api/tasks | 全タスク取得（コメント・履歴含む） |
| POST | /api/tasks | タスク作成 |
| PUT | /api/tasks/:id | タスク更新 |
| PATCH | /api/tasks/:id/column | ステータス変更（D&D） |
| PATCH | /api/tasks/:id/assignees | 担当者クイック変更 |
| PATCH | /api/tasks/:id/epic | エピック割当 |
| PUT | /api/tasks/reorder/bulk | 優先度一括並替 |
| POST | /api/tasks/:id/comments | コメント追加 |
| GET | /api/tasks/:id/activity | 履歴取得 |
| DELETE | /api/tasks/:id | タスク削除 |

### スプリント
| Method | Path | 説明 |
|--------|------|------|
| GET | /api/sprints | 全スプリント取得 |
| POST | /api/sprints | スプリント作成 |
| PUT | /api/sprints/:id | スプリント更新 |
| DELETE | /api/sprints/:id | スプリント削除 |
| POST | /api/sprints/:id/tasks | タスク割当 |
| DELETE | /api/sprints/:id/tasks/:taskId | タスク除外 |
| PUT | /api/sprints/:id/tasks/:taskId/points | ポイント更新 |
| GET | /api/sprints/:id/burndown | バーンダウンデータ |

### エピック
| Method | Path | 説明 |
|--------|------|------|
| GET | /api/epics | 全エピック取得 |
| POST | /api/epics | エピック作成 |
| PUT | /api/epics/:id | エピック更新 |
| DELETE | /api/epics/:id | エピック削除 |

### ナレッジ
| Method | Path | 説明 |
|--------|------|------|
| GET | /api/knowledge | 記事一覧（本文除外） |
| GET | /api/knowledge/:id | 記事全文取得 |
| POST | /api/knowledge | 記事作成 |
| PUT | /api/knowledge/:id | 記事更新 |
| DELETE | /api/knowledge/:id | 記事削除 |
| GET | /api/knowledge/search/query | 検索（q, category, tag, status） |
| GET | /api/knowledge/export/rag | RAGエクスポート |

### ふりかえり
| Method | Path | 説明 |
|--------|------|------|
| GET | /api/retros | ふりかえり一覧 |
| POST | /api/retros | ふりかえり作成 |
| PUT | /api/retros/:id | ふりかえり更新 |
| DELETE | /api/retros/:id | ふりかえり削除 |

### 目標管理
| Method | Path | 説明 |
|--------|------|------|
| GET/POST/PUT/DELETE | /api/goals/org[/:id] | 組織目標CRUD |
| GET/POST/PUT/DELETE | /api/goals/personal[/:id] | 個人目標CRUD |

### メンバー・プロジェクト・AI
| Method | Path | 説明 |
|--------|------|------|
| GET/POST/DELETE | /api/members[/:id] | メンバー管理 |
| GET/POST/DELETE | /api/projects[/:id] | プロジェクト管理 |
| GET/POST/DELETE | /api/ai/conversations[/:id] | AI会話管理 |
| GET/POST | /api/ai/conversations/:id/messages | 会話メッセージ |
| POST | /api/ai/agent/chat | AIエージェント呼び出し（Claude APIプロキシ） |
| GET/POST | /api/backup/* | バックアップ&リストア |
| POST/GET | /api/tokens/* | トークン使用量追跡 |
| GET | /api/health | ヘルスチェック |

## 技術スタック

| レイヤー | 技術 |
|---------|------|
| Frontend | React 18 + Vite |
| Backend | Express.js + SQLite (better-sqlite3) |
| AI | Claude API (Opus/Sonnet) + Function Calling |
| MCP | JSON-RPC 2.0 (stdio + SSE) |
| Git | Gitea REST API |
| デザイン | JIRA風UIテーマ（ライトテーマ、Atlassian Blue） |

## ドキュメント

| ドキュメント | 内容 |
|------------|------|
| [アーキテクチャ設計書](docs/llm-scrum-architecture.md) | システム構成、エージェント定義、スプリントサイクル、品質ゲート |
| [実装ガイド](docs/llm-scrum-implementation-guide.md) | イベント実行スキル、AIキャパシティモデル、DoD日次運用 |
| [ユースケース集](docs/usecases.md) | 7シナリオの詳細な使用例 |
| [MCPセットアップ](backend/MCP-SETUP.md) | Claude Code / Copilot連携設定 |
| [Orchestrator QS](orchestrator/QUICKSTART.md) | LLMスクラムチーム起動手順 |
| [エージェント定義](docs/agents/) | 5体のSystem Prompt + 通信プロトコル |
| [agent.md](agent.md) | ナレッジ生成プロンプト |

## ライセンス

MIT
