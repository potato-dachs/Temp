# Dashboard - プロジェクト管理ツール

JIRA風のプロジェクト管理ダッシュボード。タスク管理（カンバン/カレンダー）と目標管理（組織方針/個人目標）を統合。

## 構成

```
project/
├── backend/
│   ├── server.js          # Express APIサーバー
│   ├── db.js              # SQLite DB初期化 & シード
│   ├── routes/
│   │   ├── tasks.js       # タスク CRUD API
│   │   ├── goals.js       # 目標 CRUD API (組織 + 個人)
│   │   └── members.js     # メンバー API
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── main.jsx       # React エントリポイント
│   │   ├── App.jsx        # API連携ラッパー
│   │   ├── Dashboard.jsx  # メインUI (単体動作可)
│   │   └── api.js         # APIクライアント
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
└── README.md
```

## セットアップ

### 必要環境
- Node.js 18+
- npm

### インストール & 起動

```bash
# バックエンド
cd backend
npm install
npm start          # http://localhost:3001

# フロントエンド (別ターミナル)
cd frontend
npm install
npm run dev        # http://localhost:3000
```

### 本番ビルド

```bash
cd frontend
npm run build      # frontend/build/ に出力

cd ../backend
npm start          # APIサーバーが frontend/build を静的配信
# → http://localhost:3001 で全機能利用可
```

## API エンドポイント

### タスク管理
| Method | Path | 説明 |
|--------|------|------|
| GET    | /api/tasks | 全タスク取得 |
| POST   | /api/tasks | タスク作成 |
| PUT    | /api/tasks/:id | タスク更新 |
| PATCH  | /api/tasks/:id/column | ステータス変更 (D&D用) |
| DELETE | /api/tasks/:id | タスク削除 |

### 目標管理 (組織)
| Method | Path | 説明 |
|--------|------|------|
| GET    | /api/goals/org | 組織目標一覧 |
| POST   | /api/goals/org | 組織目標作成 |
| PUT    | /api/goals/org/:id | 組織目標更新 |
| DELETE | /api/goals/org/:id | 組織目標削除 |

### 目標管理 (個人)
| Method | Path | 説明 |
|--------|------|------|
| GET    | /api/goals/personal | 個人目標一覧 |
| POST   | /api/goals/personal | 個人目標作成 |
| PUT    | /api/goals/personal/:id | 個人目標更新 |
| DELETE | /api/goals/personal/:id | 個人目標削除 |

### メンバー
| Method | Path | 説明 |
|--------|------|------|
| GET    | /api/members | メンバー一覧 |
| POST   | /api/members | メンバー追加 |

## 技術スタック

- **Frontend**: React 18 + Vite
- **Backend**: Express.js
- **Database**: SQLite (better-sqlite3)
- **デザイン**: JIRA風UIテーマ
